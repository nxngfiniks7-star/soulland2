package com.soulland.mod;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ModItems {
    public static final List<Item> ALL = new ArrayList<>();

    public static final CreativeTabs TAB = new CreativeTabs("soulland") {
        public String getTranslatedTabLabel() { return Tr.t("itemGroup.soulland"); }

        @Override @SideOnly(Side.CLIENT)
        public ItemStack createIcon() { return new ItemStack(ModItems.HAMMER); }
    };

    public static final Item.ToolMaterial HAOTIAN = EnumHelper.addToolMaterial("HAOTIAN", 3, 3000, 8.0F, 9.0F, 15);

    public static final Item HAMMER = reg(new ItemHammer(HAOTIAN), "hao_tian_hammer");
    public static final String[] RING_NAMES = {"white", "yellow", "purple", "black", "red"};
    public static final Item[] RINGS = new Item[5];

    static {
        for (int i = 0; i < 5; i++) RINGS[i] = reg(new ItemSoulRing(i), "ring_" + RING_NAMES[i]);
    }

    private static Item reg(Item item, String name) {
        item.setRegistryName(SoulLand.MODID, name);
        item.setTranslationKey(SoulLand.MODID + "." + name);
        item.setCreativeTab(TAB);
        ALL.add(item);
        return item;
    }
}

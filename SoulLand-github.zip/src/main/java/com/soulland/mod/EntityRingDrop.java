package com.soulland.mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;

/**
 * วงแหวนวิญญาณที่ลอยอยู่ตรงที่มอนสเตอร์ตาย: ไม่ถูกดูดเข้าตัวเอง คลิกซ้าย/ขวาเพื่อเก็บเข้ากระเป๋า และหายเองหลัง 1 นาที
 * (ไม่ใช้ EntityItem เพราะเซิร์ฟเวอร์ของ Minecraft จะเตะผู้เล่นที่โจมตี EntityItem ทำให้เกมค้าง)
 */
public class EntityRingDrop extends Entity {
    private static final DataParameter<Integer> TIER = EntityDataManager.createKey(EntityRingDrop.class, DataSerializers.VARINT);
    public static final int LIFE = 1200;
    private int age;

    public EntityRingDrop(World w) {
        super(w);
        this.setSize(0.6F, 0.6F);
        this.setNoGravity(true);
    }

    public EntityRingDrop(World w, double x, double y, double z, int tier) {
        this(w);
        this.setPosition(x, y, z);
        this.dataManager.set(TIER, tier);
    }

    @Override protected void entityInit() { this.dataManager.register(TIER, 0); }

    public int getTier() { return Math.max(0, Math.min(4, this.dataManager.get(TIER))); }

    @Override protected void readEntityFromNBT(NBTTagCompound c) {
        this.dataManager.set(TIER, c.getInteger("tier"));
        this.age = c.getInteger("age");
    }

    @Override protected void writeEntityToNBT(NBTTagCompound c) {
        c.setInteger("tier", getTier());
        c.setInteger("age", age);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (!world.isRemote && ++age >= LIFE) setDead();
    }

    @Override public boolean canBeCollidedWith() { return true; }

    @Override public float getCollisionBorderSize() { return 0.3F; }

    @Override public boolean attackEntityFrom(DamageSource s, float a) { return false; }

    /** เก็บวงแหวนเข้ากระเป๋า (ยังไม่ดูดซับ) */
    public boolean collect(EntityPlayerMP p) {
        ItemStack st = new ItemStack(ModItems.RINGS[getTier()]);
        if (p.inventory.addItemStackToInventory(st)) {
            p.inventoryContainer.detectAndSendChanges();
            p.world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.5F, 1.3F);
            return true;
        }
        p.sendStatusMessage(Tr.c("msg.soulland.invfull"), true);
        return false;
    }

    @Override
    public boolean processInitialInteract(EntityPlayer player, EnumHand hand) {
        if (!world.isRemote && player instanceof EntityPlayerMP) {
            if (collect((EntityPlayerMP) player)) setDead();
        }
        return true;
    }
}

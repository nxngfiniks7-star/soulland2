package com.soulland.mod;

import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

/** วงแหวนวิญญาณที่ดรอปบนพื้น: เก็บเข้ากระเป๋าไม่ได้ ต้องคลิกซ้ายเพื่อดูดซับ และหายไปเองหลัง 1 นาที (กันเกมค้าง) */
public class EntityRingDrop extends EntityItem {
    public static final int LIFE = 1200;

    public EntityRingDrop(World w) { super(w); this.lifespan = LIFE; }

    public EntityRingDrop(World w, double x, double y, double z, ItemStack s) { super(w, x, y, z, s); this.lifespan = LIFE; }

    @Override public void onCollideWithPlayer(EntityPlayer p) {}

    @Override public boolean canBeCollidedWith() { return true; }

    @Override public float getCollisionBorderSize() { return 0.5F; }
}

package com.soulland.mod;

import java.util.List;

import javax.annotation.Nullable;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** วงแหวนวิญญาณ: 0 ขาว(10ปี) 1 เหลือง(100) 2 ม่วง(1000) 3 ดำ(10000) 4 แดง(100000) */
public class ItemSoulRing extends Item {
    public final int tier;

    public ItemSoulRing(int tier) { this.tier = tier; setMaxStackSize(16); }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World w, EntityPlayer p, EnumHand h) {
        ItemStack s = p.getHeldItem(h);
        if (w.isRemote) return new ActionResult<>(EnumActionResult.SUCCESS, s);
        if (!Absorb.start((EntityPlayerMP) p, tier)) return new ActionResult<>(EnumActionResult.FAIL, s);
        if (!p.capabilities.isCreativeMode) s.shrink(1);
        return new ActionResult<>(EnumActionResult.SUCCESS, s);
    }

    public String getItemStackDisplayName(ItemStack stack) { return Tr.t("item.soulland.ring_" + ModItems.RING_NAMES[tier] + ".name"); }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World w, List<String> tip, ITooltipFlag f) {
        tip.add(Tr.t("tooltip.soulland.age." + tier));
        tip.add(Tr.t("tooltip.soulland.ring"));
    }
}

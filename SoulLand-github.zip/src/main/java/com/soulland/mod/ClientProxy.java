package com.soulland.mod;

import net.minecraft.client.renderer.entity.RenderPolarBear;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.renderer.entity.RenderWolf;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        Tr.lookup = (k, a) -> I18n.hasKey(k) ? I18n.format(k, a) : null;
        ClientRegistry.registerKeyBinding(ClientHandler.CAST);
        ClientRegistry.registerKeyBinding(ClientHandler.CYCLE);
        ClientRegistry.registerKeyBinding(ClientHandler.RELEASE);
        ClientRegistry.registerKeyBinding(ClientHandler.AWAKEN);
        ClientRegistry.registerKeyBinding(ClientHandler.REROLL);
        RenderingRegistry.registerEntityRenderingHandler(EntitySoulBear.class, m -> new RenderPolarBear(m));
        RenderingRegistry.registerEntityRenderingHandler(EntitySoulWolf.class, m -> new RenderWolf(m));
    }
}

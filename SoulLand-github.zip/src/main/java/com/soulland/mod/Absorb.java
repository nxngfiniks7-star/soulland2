package com.soulland.mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.WorldServer;

/** ระบบดูดซับวงแหวนวิญญาณ: ตัวละครนั่งสมาธิ ยิ่งวงแหวนอายุมากยิ่งใช้เวลานาน (2.5-7.5 วินาที) */
public class Absorb {
    public static int durationFor(int tier) { return 50 + Math.max(0, Math.min(4, tier)) * 25; }

    private static final EnumParticleTypes[] PARTS = {
        EnumParticleTypes.END_ROD, EnumParticleTypes.FLAME, EnumParticleTypes.SPELL_WITCH,
        EnumParticleTypes.SMOKE_LARGE, EnumParticleTypes.REDSTONE };

    public static boolean active(EntityPlayerMP p) { return SoulData.tag(p).getBoolean("abOn"); }

    private static void err(EntityPlayerMP p, String k) { p.sendStatusMessage(Tr.c(k), true); }

    public static boolean start(EntityPlayerMP p, int tier) {
        NBTTagCompound t = SoulData.tag(p);
        if (Meditate.active(p)) Meditate.stop(p, false);
        if (active(p) || t.getBoolean("awOn")) return false;
        int rings = SoulData.getRings(p);
        if (SoulData.getSoul(p) == 0) { err(p, "msg.soulland.needawaken"); return false; }
        if (rings >= 9) { err(p, "msg.soulland.maxrings"); return false; }
        if (SoulData.getLevel(p) < 10 * (rings + 1)) { err(p, "msg.soulland.needlevel"); return false; }
        t.setBoolean("abOn", true);
        t.setInteger("abTick", 0);
        t.setInteger("abTier", tier);
        t.setInteger("abDur", durationFor(tier));
        t.setDouble("abX", p.posX); t.setDouble("abY", p.posY); t.setDouble("abZ", p.posZ);
        // เก้าอี้ล่องหน ให้ตัวละครนั่ง
        EntityArmorStand seat = new EntityArmorStand(p.world, p.posX, p.posY - 1.58, p.posZ);
        seat.setInvisible(true);
        seat.setNoGravity(true);
        seat.setEntityInvulnerable(true);
        p.world.spawnEntity(seat);
        seat.getEntityData().setBoolean("sl_seat", true);
        p.startRiding(seat, true);
        t.setInteger("abSeat", seat.getEntityId());
        SoulData.syncVisual(p);
        return true;
    }

    private static void release(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        Entity seat = p.world.getEntityByID(t.getInteger("abSeat"));
        p.dismountRidingEntity();
        if (seat != null) seat.setDead();
        p.setPositionAndUpdate(t.getDouble("abX"), t.getDouble("abY"), t.getDouble("abZ"));
    }

    public static void tick(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        if (p.getHealth() <= 0 || p.isDead) {
            t.setBoolean("abOn", false);
            release(p);
            SoulData.syncVisual(p);
            return;
        }
        Entity seat = p.world.getEntityByID(t.getInteger("abSeat"));
        if (seat != null && !seat.isDead && p.getRidingEntity() != seat) p.startRiding(seat, true);
        int dur = Math.max(1, t.getInteger("abDur"));
        int tick = t.getInteger("abTick") + 1;
        int tier = Math.max(0, Math.min(4, t.getInteger("abTier")));
        t.setInteger("abTick", tick);
        p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 5, 6, false, false));

        WorldServer ws = (WorldServer) p.world;
        float pr = tick / (float) dur;
        double radius = 0.4 + 2.8 * (1 - pr);
        double y = p.posY + 0.6 + pr * 1.0;
        for (int i = 0; i < 4; i++) {
            double a = tick * 0.35 + i * Math.PI / 2;
            ws.spawnParticle(PARTS[tier], p.posX + Math.cos(a) * radius, y, p.posZ + Math.sin(a) * radius, 1, 0, 0, 0, 0.0);
        }
        ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX, p.posY + 0.8 + pr * 1.2, p.posZ, 1, 0.2, 0.3, 0.2, 0.01);
        if (tick % 20 == 0)
            ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, 0.6F + pr);
        if (tick % 2 == 0) SoulData.syncVisual(p);
        if (tick >= dur) finish(p, tier);
    }

    private static void finish(EntityPlayerMP p, int tier) {
        NBTTagCompound t = SoulData.tag(p);
        t.setBoolean("abOn", false);
        t.setInteger("abTick", 0);
        release(p);
        WorldServer ws = (WorldServer) p.world;
        int rings = SoulData.getRings(p);
        int maxTier = Math.min(4, rings / 2 + 1);
        if (tier > maxTier) {
            p.attackEntityFrom(DamageSource.MAGIC, 14.0F);
            p.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 200, 0));
            p.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 400, 1));
            ws.spawnParticle(EnumParticleTypes.SMOKE_LARGE, p.posX, p.posY + 1, p.posZ, 40, 0.5, 0.8, 0.5, 0.05);
            p.sendMessage(Tr.c("msg.soulland.ringfail"));
            SoulData.syncVisual(p);
            return;
        }
        SoulData.addTier(p, tier);
        SoulData.setRings(p, rings + 1);
        SoulData.applyBonuses(p);
        SoulData.setMana(p, SoulData.maxMana(p));
        int soul = SoulData.getSoul(p);
        if (!SoulSkills.available(soul, rings, SoulData.getSelected(p))) {
            int n = SoulSkills.next(soul, rings + 1, SoulData.getSelected(p));
            if (n >= 0) SoulData.setSelected(p, n);
        }
        ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX, p.posY + 1, p.posZ, 80, 0.7, 0.9, 0.7, 0.15);
        ws.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, p.posX, p.posY + 1, p.posZ, 2, 0.3, 0.3, 0.3, 0.0);
        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6F, 1.6F);
        SoulData.sync(p);
        SoulData.syncVisual(p);
        p.sendMessage(Tr.c("msg.soulland.ringok", String.valueOf(rings + 1)));
    }
}

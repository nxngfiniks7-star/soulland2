package com.soulland.mod;

public class CommonProxy {
    public void preInit() {}
}

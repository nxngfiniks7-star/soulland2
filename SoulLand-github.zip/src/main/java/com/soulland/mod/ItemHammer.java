package com.soulland.mod;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

/** ค้อนฮ่าวเทียน */
public class ItemHammer extends ItemSword {
    public ItemHammer(ToolMaterial m) { super(m); }

    public String getItemStackDisplayName(ItemStack stack) { return Tr.t("item.soulland.hao_tian_hammer.name"); }
}

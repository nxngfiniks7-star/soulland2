package com.soulland.mod;

import java.util.UUID;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** ข้อมูลสำหรับเรนเดอร์วงแหวน/วิญญาณยุทธ์/อนิเมชันดูดซับ (ส่งให้ผู้เล่นที่อยู่ใกล้ด้วย) */
public class PacketVisual implements IMessage {
    public UUID id = new UUID(0L, 0L);
    public int soul;
    public boolean released;
    public int[] tiers = new int[0];
    public int abTier = -1;
    public int abProgress;
    public boolean sit;

    public PacketVisual() {}

    public PacketVisual(UUID id, int soul, boolean released, int[] tiers, int abTier, int abProgress, boolean sit) {
        this.sit = sit;
        this.id = id; this.soul = soul; this.released = released; this.tiers = tiers;
        this.abTier = abTier; this.abProgress = abProgress;
    }

    @Override public void fromBytes(ByteBuf b) {
        id = new UUID(b.readLong(), b.readLong());
        soul = b.readInt();
        released = b.readBoolean();
        int n = Math.min(9, b.readByte());
        tiers = new int[n];
        for (int i = 0; i < n; i++) tiers[i] = b.readByte();
        abTier = b.readByte();
        abProgress = b.readByte();
        sit = b.readBoolean();
    }

    @Override public void toBytes(ByteBuf b) {
        b.writeLong(id.getMostSignificantBits());
        b.writeLong(id.getLeastSignificantBits());
        b.writeInt(soul);
        b.writeBoolean(released);
        int n = Math.min(9, tiers.length);
        b.writeByte(n);
        for (int i = 0; i < n; i++) b.writeByte(tiers[i]);
        b.writeByte(abTier);
        b.writeByte(abProgress);
        b.writeBoolean(sit);
    }

    public static class Handler implements IMessageHandler<PacketVisual, IMessage> {
        @Override
        public IMessage onMessage(PacketVisual m, MessageContext ctx) {
            final Minecraft mc = Minecraft.getMinecraft();
            mc.addScheduledTask(() -> {
                ClientState.Visual old = ClientState.visuals.get(m.id);
                long now = mc.world != null ? mc.world.getTotalWorldTime() : 0L;
                long change = old == null ? -100000L : (old.released != m.released ? now : old.changeTick);
                ClientState.visuals.put(m.id, new ClientState.Visual(m.soul, m.released, m.tiers, m.abTier, m.abProgress, change, m.sit));
            });
            return null;
        }
    }
}

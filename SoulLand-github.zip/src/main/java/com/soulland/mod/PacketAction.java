package com.soulland.mod;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** action 0 = ใช้สกิล, 1 = สลับสกิล */
public class PacketAction implements IMessage {
    public int action;

    public PacketAction() {}

    public PacketAction(int action) { this.action = action; }

    @Override public void fromBytes(ByteBuf b) { action = b.readInt(); }

    @Override public void toBytes(ByteBuf b) { b.writeInt(action); }

    public static class Handler implements IMessageHandler<PacketAction, IMessage> {
        @Override
        public IMessage onMessage(PacketAction m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            final int a = m.action;
            p.getServerWorld().addScheduledTask(() -> {
                if (a == 0) SoulSkills.cast(p);
                else if (a == 1) SoulSkills.cycle(p);
                else if (a == 2) SoulSkills.toggleRelease(p);
                else if (a == 3) Awaken.start(p, false);
                else if (a == 4) Awaken.requestReroll(p);
                else if (a == 5) Meditate.toggle(p);
            });
            return null;
        }
    }
}

package com.soulland.mod;

import java.util.Random;
import java.util.UUID;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = SoulLand.MODID)
public class CommonEvents {
    private static final UUID BEAST_HP = UUID.fromString("5b1c2f0e-7d3a-4e6b-8f21-0c9a4d7e3a55");
    private static final UUID BEAST_ATK = UUID.fromString("a41e9d73-2b5c-4c88-9e10-3f6b7a8c2d41");

    private static int tierFor(float h) {
        return h <= 20 ? 0 : h <= 40 ? 1 : h <= 100 ? 2 : h <= 200 ? 3 : 4;
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER) return;
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        if (Absorb.active(p)) Absorb.tick(p);
        if (Meditate.active(p)) Meditate.tick(p);
        if (SoulData.getSoul(p) == 0) return;
        if (p.ticksExisted % 100 == 0) SoulData.syncVisual(p);
        if (p.ticksExisted % 40 == 0) SoulWeapons.ensure(p);
        if (p.ticksExisted % 20 != 0) return;
        if (p.getHealth() > 0 && p.getHealth() < p.getMaxHealth()) p.heal(0.5F + SoulData.getLevel(p) / 40F);
        int max = SoulData.maxMana(p), m = SoulData.getMana(p);
        if (m < max) {
            SoulData.setMana(p, Math.min(max, m + 3 + SoulData.getLevel(p) / 6));
            SoulData.sync(p);
        }
    }

    /** ทักษะ "ว่างเปล่า": ศัตรูโจมตีไม่โดน */
    @SubscribeEvent
    public static void attacked(LivingAttackEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
        NBTTagCompound st = SoulData.tag(p);
        boolean busy = st.getBoolean("medOn") || st.getBoolean("abOn") || st.getBoolean("awOn");
        if (busy && (e.getSource() == DamageSource.IN_WALL || e.getSource() == DamageSource.FALL)) { e.setCanceled(true); return; }
        if (Meditate.active(p)) Meditate.stop(p, true);
        if (SoulData.tag(p).getLong("voidUntil") > p.world.getTotalWorldTime() && e.getSource() != DamageSource.OUT_OF_WORLD)
            e.setCanceled(true);
    }

    @SubscribeEvent
    public static void kill(LivingDeathEvent e) {
        if (!(e.getSource().getTrueSource() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getSource().getTrueSource();
        EntityLivingBase mob = e.getEntityLiving();
        if (SoulData.getSoul(p) == 0 || mob instanceof EntityPlayer) return;
        int gain = Math.max(3, (int) mob.getMaxHealth());
        SoulData.addExp(p, gain);
    }

    /** สัตว์วิญญาณ: มอนสเตอร์ที่เกิดมาพร้อมวงแหวน (แกร่งขึ้น และดรอปวงแหวนแน่นอน) */
    @SubscribeEvent
    public static void join(EntityJoinWorldEvent e) {
        Entity en = e.getEntity();
        if (!e.getWorld().isRemote && en instanceof EntityItem && SoulWeapons.isSpirit(((EntityItem) en).getItem())) { en.setDead(); return; }
        if (!e.getWorld().isRemote && en instanceof EntityArmorStand && en.getEntityData().getBoolean("sl_seat")) { en.setDead(); return; }
        if (e.getWorld().isRemote || !(en instanceof EntityLiving) || !(en instanceof IMob)) return;
        NBTTagCompound d = en.getEntityData();
        if (d.getBoolean("sl_checked")) return;
        d.setBoolean("sl_checked", true);
        EntityLiving mob = (EntityLiving) en;
        if (!mob.isNonBoss()) return;
        boolean beast = en instanceof EntitySoulBear || en instanceof EntitySoulWolf;
        Random r = e.getWorld().rand;
        if (!beast && r.nextDouble() >= 0.15) return;
        // วงแหวน 1 วงต่อตัว = อายุของสัตว์วิญญาณ ยิ่งอายุมากยิ่งอึด
        double x = r.nextDouble();
        int tier = x < 0.60 ? 0 : x < 0.85 ? 1 : x < 0.95 ? 2 : x < 0.99 ? 3 : 4;
        if (en instanceof EntitySoulBear) tier = Math.max(tier, 1);
        if (beast) {
            String[] ages = {"10 ปี", "100 ปี", "1,000 ปี", "10,000 ปี", "100,000 ปี"};
            mob.setCustomNameTag((en instanceof EntitySoulBear ? "หมีหิมะ " : "หมาป่าพายุ ") + ages[tier]);
            mob.setAlwaysRenderNameTag(true);
        }
        d.setIntArray("sl_tiers", new int[]{tier});
        double[] hpBonus = {10, 30, 80, 200, 500};
        double[] atkBonus = {1, 3, 6, 12, 20};
        IAttributeInstance hp = mob.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH);
        if (hp != null) hp.applyModifier(new AttributeModifier(BEAST_HP, "soulland.beast_hp", hpBonus[tier], 0));
        IAttributeInstance atk = mob.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE);
        if (atk != null) atk.applyModifier(new AttributeModifier(BEAST_ATK, "soulland.beast_atk", atkBonus[tier], 0));
        mob.setHealth(mob.getMaxHealth());
    }

    @SubscribeEvent
    public static void track(PlayerEvent.StartTracking e) {
        Entity t = e.getTarget();
        if (!(t instanceof EntityLiving) || !(t instanceof IMob) || !(e.getEntityPlayer() instanceof EntityPlayerMP)) return;
        int[] tiers = t.getEntityData().getIntArray("sl_tiers");
        NetworkHandler.CHANNEL.sendTo(new PacketMobRings(t.getEntityId(), tiers), (EntityPlayerMP) e.getEntityPlayer());
    }

    @SubscribeEvent
    public static void drops(LivingDropsEvent e) {
        if (!(e.getSource().getTrueSource() instanceof EntityPlayer)) return;
        EntityLivingBase mob = e.getEntityLiving();
        if (!(mob instanceof IMob)) return;
        int[] beast = mob.getEntityData().getIntArray("sl_tiers");
        int tier;
        if (beast.length > 0) {
            tier = 0;
            for (int b : beast) tier = Math.max(tier, b);
            mob.world.spawnEntity(new EntityRingDrop(mob.world, mob.posX, mob.posY + 0.3, mob.posZ, tier));
            return;
        }
        float h = mob.getMaxHealth();
        tier = tierFor(h);
        double chance = h >= 200 ? 1.0 : 0.05;
        if (mob.world.rand.nextDouble() < chance) {
            mob.world.spawnEntity(new EntityRingDrop(mob.world, mob.posX, mob.posY + 0.3, mob.posZ, tier));
        }
    }

    /** คลิกซ้ายวงแหวนที่ลอยอยู่เพื่อดูดซับ */
    @SubscribeEvent
    public static void attack(AttackEntityEvent e) {
        if (!(e.getTarget() instanceof EntityRingDrop)) return;
        e.setCanceled(true);
        if (e.getEntityPlayer().world.isRemote) return;
        EntityRingDrop d = (EntityRingDrop) e.getTarget();
        if (d.collect((EntityPlayerMP) e.getEntityPlayer())) d.setDead();
    }

    /** อาวุธวิญญาณไม่หล่นตอนตาย */
    @SubscribeEvent
    public static void dropSpirit(PlayerDropsEvent e) {
        e.getDrops().removeIf(d -> SoulWeapons.isSpirit(d.getItem()));
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        SoulData.tag(e.getEntityPlayer()).merge(SoulData.tag(e.getOriginal()));
    }

    @SubscribeEvent
    public static void login(PlayerLoggedInEvent e) {
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        SoulData.applyBonuses(p);
        SoulData.sync(p);
        SoulData.syncVisual(p);
        SoulWeapons.refresh(p);
    }

    @SubscribeEvent
    public static void respawn(PlayerRespawnEvent e) {
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        SoulData.applyBonuses(p);
        p.setHealth(p.getMaxHealth());
        SoulData.sync(p);
        SoulData.syncVisual(p);
        SoulWeapons.refresh(p);
    }
}

package com.soulland.mod;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = SoulLand.MODID)
public class CommonEvents {

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER) return;
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        if (p.ticksExisted % 20 != 0 || SoulData.getSoul(p) == 0) return;
        int max = SoulData.maxMana(p), m = SoulData.getMana(p);
        if (m < max) {
            SoulData.setMana(p, Math.min(max, m + 2 + SoulData.getLevel(p) / 10));
            SoulData.sync(p);
        }
    }

    @SubscribeEvent
    public static void kill(LivingDeathEvent e) {
        if (!(e.getSource().getTrueSource() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getSource().getTrueSource();
        if (SoulData.getSoul(p) == 0 || e.getEntityLiving() instanceof EntityPlayer) return;
        SoulData.addExp(p, Math.max(1, (int) (e.getEntityLiving().getMaxHealth() / 2)));
    }

    @SubscribeEvent
    public static void drops(LivingDropsEvent e) {
        if (!(e.getSource().getTrueSource() instanceof EntityPlayer)) return;
        EntityLivingBase mob = e.getEntityLiving();
        if (!(mob instanceof IMob)) return;
        float h = mob.getMaxHealth();
        int tier = h <= 20 ? 0 : h <= 40 ? 1 : h <= 100 ? 2 : h <= 200 ? 3 : 4;
        double chance = h >= 200 ? 1.0 : 0.05;
        if (mob.world.rand.nextDouble() < chance) {
            e.getDrops().add(new EntityItem(mob.world, mob.posX, mob.posY, mob.posZ, new ItemStack(ModItems.RINGS[tier])));
        }
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        SoulData.tag(e.getEntityPlayer()).merge(SoulData.tag(e.getOriginal()));
    }

    @SubscribeEvent
    public static void login(PlayerLoggedInEvent e) {
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        SoulData.applyBonuses(p);
        SoulData.sync(p);
    }

    @SubscribeEvent
    public static void respawn(PlayerRespawnEvent e) {
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        SoulData.applyBonuses(p);
        p.setHealth(p.getMaxHealth());
        SoulData.sync(p);
    }
}

package com.soulland.mod;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

/** วิญญาณยุทธ์อาวุธ: เปิดวิญญาณแล้วได้อาวุธใส่กระเป๋า ปิดวิญญาณแล้วอาวุธหายไป */
public class SoulWeapons {
    public static final String TAG = "sl_spirit";

    public static boolean isSpirit(ItemStack s) {
        return s != null && !s.isEmpty() && s.hasTagCompound() && s.getTagCompound().getBoolean(TAG);
    }

    private static ItemStack make(int soul) {
        ItemStack st;
        String name = null;
        if ((soul & 1) != 0) st = new ItemStack(ModItems.HAMMER);
        else if (soul == 16) { st = new ItemStack(Items.IRON_AXE); name = "ขวานวิญญาณ"; }
        else if (soul == 32) { st = new ItemStack(Items.IRON_PICKAXE); name = "ที่ขุดวิญญาณ"; }
        else if (soul == 64) { st = new ItemStack(Items.IRON_SHOVEL); name = "พลั่ววิญญาณ"; }
        else if (soul == 128) { st = new ItemStack(Items.IRON_HOE); name = "จอบวิญญาณ"; }
        else return ItemStack.EMPTY;
        NBTTagCompound tag = new NBTTagCompound();
        tag.setBoolean(TAG, true);
        tag.setByte("Unbreakable", (byte) 1);
        st.setTagCompound(tag);
        if (name != null) st.setStackDisplayName(name);
        return st;
    }

    public static boolean has(EntityPlayerMP p) {
        for (int i = 0; i < p.inventory.getSizeInventory(); i++) if (isSpirit(p.inventory.getStackInSlot(i))) return true;
        return false;
    }

    public static void take(EntityPlayerMP p) {
        boolean any = false;
        for (int i = 0; i < p.inventory.getSizeInventory(); i++) {
            if (isSpirit(p.inventory.getStackInSlot(i))) { p.inventory.setInventorySlotContents(i, ItemStack.EMPTY); any = true; }
        }
        if (any) p.inventoryContainer.detectAndSendChanges();
    }

    public static void give(EntityPlayerMP p) {
        ItemStack st = make(SoulData.getSoul(p));
        if (st.isEmpty()) return;
        int cur = p.inventory.currentItem;
        if (p.inventory.getStackInSlot(cur).isEmpty()) p.inventory.setInventorySlotContents(cur, st);
        else if (!p.inventory.addItemStackToInventory(st)) { p.sendStatusMessage(Tr.c("msg.soulland.invfull"), true); return; }
        p.inventoryContainer.detectAndSendChanges();
    }

    /** ล้างอาวุธวิญญาณเก่า แล้วให้ใหม่ถ้าตอนนี้เปิดวิญญาณอยู่ */
    public static void refresh(EntityPlayerMP p) {
        take(p);
        if (SoulData.getSoul(p) != 0 && SoulData.tag(p).getBoolean("released")) give(p);
    }

    public static void ensure(EntityPlayerMP p) {
        boolean want = SoulData.getSoul(p) != 0 && SoulData.tag(p).getBoolean("released") && !make(SoulData.getSoul(p)).isEmpty();
        boolean has = has(p);
        if (want && !has) give(p);
        else if (!want && has) take(p);
    }
}

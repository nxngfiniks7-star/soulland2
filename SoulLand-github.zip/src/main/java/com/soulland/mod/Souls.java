package com.soulland.mod;

/** ข้อมูลวิญญาณยุทธ์ (id = บิตมาสก์) */
public class Souls {
    public static int accent(int soul) {
        switch (soul) {
            case 1: return 0xFFFFAA33;
            case 2: return 0xFF55DDFF;
            case 4: return 0xFFFFA040;
            case 8: return 0xFFFF88CC;
            case 16: return 0xFFFF8844;
            case 32: return 0xFF88CCFF;
            case 64: return 0xFFE0C060;
            case 128: return 0xFFB0B0B0;
            case 256: return 0xFF66DD66;
            case 512: return 0xFFDDDDDD;
            case 1024: return 0xFF55EE55;
            case 2048: return 0xFFFF5544;
            case 4096: return 0xFFBB66FF;
            case 8192: return 0xFFFFAA22;
            case 16384: return 0xFFFF5522;
            default: return 0xFFFF77FF;
        }
    }
}

package com.soulland.mod;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

/**
 * ตัวแปลข้อความของมอด: ใช้ไฟล์ภาษาของเกมก่อน ถ้าไม่เจอคีย์ (เช่นไฟล์ภาษาไม่ถูกโหลด)
 * จะอ่านข้อความภาษาไทยจากไฟล์ th_th.lang ในตัวมอดเอง กันไม่ให้ขึ้นเป็นชื่อคีย์ดิบๆ
 */
public class Tr {
    public interface Lookup { String get(String key, Object[] args); }

    public static Lookup lookup;
    private static Map<String, String> table;

    private static synchronized Map<String, String> table() {
        if (table == null) {
            table = new HashMap<>();
            try (InputStream in = Tr.class.getResourceAsStream("/assets/soulland/lang/th_th.lang")) {
                if (in != null) {
                    BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                    String line;
                    while ((line = r.readLine()) != null) {
                        if (line.isEmpty() || line.charAt(0) == '#') continue;
                        int i = line.indexOf('=');
                        if (i > 0) table.put(line.substring(0, i), line.substring(i + 1));
                    }
                }
            } catch (Exception e) {
                // ใช้ชื่อคีย์แทน
            }
        }
        return table;
    }

    public static String t(String key, Object... args) {
        Lookup l = lookup;
        if (l != null) {
            String r = null;
            try { r = l.get(key, args); } catch (Throwable e) { r = null; }
            if (r != null) return r;
        }
        String f = table().get(key);
        if (f == null) return key;
        try { return String.format(f, args); } catch (Exception e) { return f; }
    }

    public static ITextComponent c(String key, Object... args) {
        Object[] conv = new Object[args.length];
        for (int i = 0; i < args.length; i++)
            conv[i] = args[i] instanceof ITextComponent ? ((ITextComponent) args[i]).getUnformattedText() : args[i];
        return new TextComponentString(t(key, conv));
    }
}

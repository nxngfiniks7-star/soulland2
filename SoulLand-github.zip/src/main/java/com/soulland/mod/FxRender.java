package com.soulland.mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityRabbit;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * เรนเดอร์ทุกอย่างรวมกัน 2 ดรอว์คอลต่อเฟรม (ลดอาการกระตุก):
 * วงแหวนวิญญาณ, วิญญาณยุทธ์, อนิเมชันดูดซับ, สัตว์วิญญาณ และเอฟเฟกต์สกิล
 */
@Mod.EventBusSubscriber(value = Side.CLIENT, modid = SoulLand.MODID)
public class FxRender {
    private static final float[][] BODY = {{1F, 1F, 1F}, {1F, 0.85F, 0.1F}, {0.7F, 0.25F, 0.95F}, {0.02F, 0.02F, 0.03F}, {1F, 0.1F, 0.1F}};
    private static final float[][] GLOW = {{1F, 1F, 1F}, {1F, 0.8F, 0.2F}, {0.8F, 0.4F, 1F}, {0.35F, 0.35F, 0.42F}, {1F, 0.3F, 0.1F}};
    private static final float[][] RUNE = {{0.35F, 0.35F, 0.5F}, {0.5F, 0.3F, 0F}, {0.95F, 0.7F, 1F}, {0.5F, 0.5F, 0.55F}, {0.1F, 0F, 0F}};
    private static final float[][] EDGE = {{0.6F, 0.6F, 0.7F}, {1F, 0.95F, 0.5F}, {1F, 0.8F, 1F}, {0.8F, 0.8F, 0.9F}, {1F, 0.6F, 0.5F}};
    private static final float[][] PAL = {{1F, 0.85F, 0.5F}, {1F, 0.6F, 0.85F}, {0.3F, 0.9F, 1F}, {1F, 0.55F, 0.15F}, {0.8F, 0.5F, 1F}, {0.4F, 1F, 0.4F}, {0.9F, 0.9F, 0.9F}, {1F, 0.3F, 0.2F}};
    private static final float[] WHITE = {1F, 1F, 1F};
    private static final float[] BLACK = {0.05F, 0.05F, 0.07F};
    private static final float[] PINK = {1F, 0.7F, 0.85F};
    private static final float[] TIGOLD = {1F, 0.7F, 0.25F};
    private static final float[] WOOD = {0.45F, 0.28F, 0.12F};
    private static final float[] STEEL = {0.62F, 0.66F, 0.78F};
    private static final float[] BLUE = {0.3F, 0.6F, 1F};
    private static final float[] CY_CORE = {0.2F, 0.82F, 0.95F};
    private static final float[] CY_GLOW = {0.3F, 0.9F, 1F};
    private static final float[] CY_LIGHT = {0.75F, 1F, 1F};
    private static final float[] CY_SPOT = {0F, 0.35F, 0.6F};
    private static final float[] VINE = {0.12F, 0.75F, 0.85F};
    private static final float[] STEM = {0.55F, 0.95F, 1F};
    private static final float[] ORB = {0.9F, 0.9F, 1F};
    private static final float[] SILVER = {0.8F, 0.92F, 1F};
    private static final float[] VOIDC = {0.5F, 0.9F, 1F};
    private static final float[] MIRC = {0.85F, 0.95F, 1F};

    private static BufferBuilder b;
    private static double ox, oy, oz;
    private static int pass;
    private static float fade = 1F;

    // ================= เหตุการณ์ =================
    @SubscribeEvent
    public static void world(RenderWorldLastEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity cam = mc.getRenderViewEntity();
        if (mc.world == null || cam == null) return;
        boolean any = !ClientFx.LIST.isEmpty() || !ClientState.mobRings.isEmpty();
        if (!any) for (EntityPlayer p : mc.world.playerEntities) if (ClientState.visuals.containsKey(p.getUniqueID())) { any = true; break; }
        if (!any) return;
        float pt = e.getPartialTicks();
        ox = lx(cam, pt); oy = ly(cam, pt); oz = lz(cam, pt);

        try { renderRealSouls(mc, pt); } catch (RuntimeException ex) { /* ห้ามให้เกมล่ม */ }
        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.disableAlpha();
        GlStateManager.enableBlend();
        GlStateManager.depthMask(false);
        Tessellator ts = Tessellator.getInstance();
        for (pass = 0; pass < 2; pass++) {
            if (pass == 0) GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
            else GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            b = ts.getBuffer();
            b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            try { collect(mc, pt, cam); } catch (RuntimeException ex) { /* ห้ามให้เกมล่ม */ }
            fade = 1F;
            ts.draw();
        }
        GlStateManager.depthMask(true);
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.enableAlpha();
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.popMatrix();
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.isGamePaused()) return;
        ClientFx.tick();
        for (EntityPlayer p : mc.world.playerEntities) {
            ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
            if (v == null || !v.released || v.soul == 0 || p.ticksExisted % 2 != 0) continue;
            mc.world.spawnParticle(v.soul == 2 ? EnumParticleTypes.END_ROD : EnumParticleTypes.SPELL_WITCH,
                    p.posX + (mc.world.rand.nextDouble() - 0.5) * 0.9, p.posY + mc.world.rand.nextDouble() * 1.9,
                    p.posZ + (mc.world.rand.nextDouble() - 0.5) * 0.9, 0.0, 0.05, 0.0);
        }
    }

    // ================= รวบรวมสิ่งที่ต้องวาด =================
    private static void collect(Minecraft mc, float pt, Entity view) {
        boolean first = mc.gameSettings.thirdPersonView == 0;
        for (EntityPlayer p : mc.world.playerEntities) {
            ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
            if (v == null) continue;
            double px = lx(p, pt), py = ly(p, pt), pz = lz(p, pt);
            float t = p.ticksExisted + pt;
            if (v.abTier >= 0) absorb(px, py, pz, v.abTier, v.abProgress / 100F, t);
            if (p == view && first) continue;
            double since = (mc.world.getTotalWorldTime() - v.changeTick) + pt;
            boolean closing = !v.released && v.soul != 0 && since < 16;
            if ((v.released && v.soul != 0) || closing) rings(px, py, pz, v.tiers, t, since, v.released);
            if (v.released && v.soul != 0 && formOf(p) == null) {
                double yaw = Math.toRadians(p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt);
                double hyaw = Math.toRadians(p.prevRotationYawHead + (p.rotationYawHead - p.prevRotationYawHead) * pt);
                double fx = -Math.sin(yaw), fz = Math.cos(yaw);
                // วิญญาณยุทธ์ทั้งหมดอยู่ด้านหลังตัวผู้เล่น
                // อาวุธ/ค้อน/หญ้าเงินคราม อยู่ด้านหน้าขวามือ (ถ้าได้สองวิญญาณ ค้อนอยู่ซ้าย)
                double rx = -fz, rz = fx;
                double cx = px + rx * 0.42 + fx * 0.4, cz = pz + rz * 0.42 + fz * 0.4;
                boolean twin = (v.soul & 3) == 3;
                double hbob = 1.35 + 0.06 * Math.sin(t * 0.07);
                if ((v.soul & 2) != 0) plant(cx, py + 1.05, cz, t);
                if ((v.soul & 1) != 0) hammer(twin ? px - rx * 0.42 + fx * 0.4 : cx, py + hbob, twin ? pz - rz * 0.42 + fz * 0.4 : cz, t);
                if ((v.soul & 4) != 0) tigerBody(px - fx * 1.15, py, pz - fz * 1.15, yaw, t, 1.25);
                if ((v.soul & 8) != 0) rabbitGear(px, py, pz, yaw, hyaw, t);
            }
        }
        List<Integer> dead = new ArrayList<>();
        for (Map.Entry<Integer, int[]> en : ClientState.mobRings.entrySet()) {
            Entity m = mc.world.getEntityByID(en.getKey());
            if (m == null) { dead.add(en.getKey()); continue; }
            if (!m.isEntityAlive()) continue;
            int tier = 0;
            for (int x : en.getValue()) tier = Math.max(tier, x);
            tier = Math.min(4, tier);
            double r = 0.3 + m.width * 0.6 + tier * 0.06;
            flatCircle(lx(m, pt), ly(m, pt) + m.height * 0.45, lz(m, pt), r, tier, m.ticksExisted + pt, 0, true, 1.0);
        }
        for (Integer id : dead) ClientState.mobRings.remove(id);
        for (ClientFx.Fx f : new ArrayList<>(ClientFx.LIST)) drawFx(mc, f, pt, view, first);
    }

    // ================= วงแหวน (วงเวทแบนซ้อนกันรอบตัว ระดับกลางขา) =================
    private static double clamp01(double v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    /** วงแหวนเล็กลง + อนิเมชันเปิด/ปิดวง (วงขยายออกทีละวงพร้อมแสงวาบ) */
    private static void rings(double px, double py, double pz, int[] tiers, float t, double since, boolean open) {
        int n = tiers.length;
        for (int i = 0; i < n; i++) {
            double p = open ? clamp01((since - i * 2.5) / 14.0) : 1 - clamp01((since - (n - 1 - i) * 1.5) / 10.0);
            if (p <= 0.001) continue;
            double sc = 0.25 + 0.75 * (p * (2 - p));
            fade = (float) Math.min(1.0, p * 1.4);
            flatCircle(px, py + 0.4 + i * 0.004, pz, (0.55 + 0.17 * i) * sc, tiers[i], t + (float) ((1 - p) * 40), i, i == n - 1, sc);
        }
        fade = 1F;
        if (open && since < 14 && pass == 1) {
            double g = since / 14.0, rr = 0.3 + g * 2.2;
            flatRing(px, py + 0.4, pz, rr - 0.05, rr, WHITE, (float) (0.6 * (1 - g)));
            line(px, py, pz, px, py + 2.2, pz, 0.25 * (1 - g) + 0.05, WHITE, (float) (0.35 * (1 - g)));
        }
    }

    private static void flatCircle(double x, double y, double z, double r, int tier, float t, int i, boolean last, double sc) {
        tier = Math.max(0, Math.min(4, tier));
        double dir = i % 2 == 0 ? 1 : -1, rot = t * 0.012 * dir;
        if (pass == 0) {
            flatRing(x, y, z, r - 0.06, r + 0.06, BODY[tier], 0.92F);
            flatRing(x, y + 0.001, z, r - 0.066, r - 0.056, EDGE[tier], 1F);
            flatRing(x, y + 0.001, z, r + 0.056, r + 0.066, EDGE[tier], 1F);
            int cnt = 12 + i * 2;
            for (int k = 0; k < cnt; k++) glyph(x, y + 0.002, z, r, rot + k * 2 * Math.PI / cnt, RUNE[tier], k, 0.5);
        } else {
            flatRing(x, y + 0.003, z, r - 0.1, r + 0.1, GLOW[tier], 0.2F);
            flatRing(x, y + 0.004, z, r - 0.03, r + 0.03, GLOW[tier], 0.18F);
            for (int k = 0; k < 2; k++) {
                double an = t * 0.05 * dir + k * Math.PI + i;
                double bx = x + Math.cos(an) * r, bz = z + Math.sin(an) * r;
                quad(bx - 0.035, y + 0.005, bz - 0.035, bx + 0.035, y + 0.005, bz - 0.035, bx + 0.035, y + 0.005, bz + 0.035, bx - 0.035, y + 0.005, bz + 0.035, EDGE[tier], 0.9F);
            }
            if (i == 0) flatRing(x, y, z, 0, r - 0.1, GLOW[tier], 0.07F);
            if (last) {
                flatRing(x, y, z, r + 0.1, r + 0.3, GLOW[tier], 0.1F);
                flatRing(x, y, z, r + 0.3, r + 0.55, GLOW[tier], 0.05F);
            }
        }
    }

    private static void flatRing(double cx, double cy, double cz, double rIn, double rOut, float[] c, float a) {
        int n = 40;
        for (int i = 0; i < n; i++) {
            double a0 = i * 2 * Math.PI / n, a1 = (i + 1) * 2 * Math.PI / n;
            double c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
            quad(cx + rIn * c0, cy, cz + rIn * s0, cx + rOut * c0, cy, cz + rOut * s0, cx + rOut * c1, cy, cz + rOut * s1, cx + rIn * c1, cy, cz + rIn * s1, c, a);
        }
    }

    private static void polar(double cx, double cy, double cz, double ang, double r1, double r2, double t1, double t2, float[] c) {
        double ca = Math.cos(ang), sa = Math.sin(ang);
        quad(cx + ca * r1 - sa * t1, cy, cz + sa * r1 + ca * t1, cx + ca * r2 - sa * t1, cy, cz + sa * r2 + ca * t1,
             cx + ca * r2 - sa * t2, cy, cz + sa * r2 + ca * t2, cx + ca * r1 - sa * t2, cy, cz + sa * r1 + ca * t2, c, 1F);
    }

    /** ลายอักขระ (รูปกากบาท) บนวงเวท */
    private static void glyph(double cx, double cy, double cz, double r, double ang, float[] c, int k) { glyph(cx, cy, cz, r, ang, c, k, 1.0); }

    private static void glyph(double cx, double cy, double cz, double r, double ang, float[] c, int k, double sc) {
        polar(cx, cy, cz, ang, r - 0.085 * sc, r + 0.085 * sc, -0.012 * sc, 0.012 * sc, c);
        polar(cx, cy, cz, ang, r - 0.02 * sc, r + 0.02 * sc, -0.06 * sc, 0.06 * sc, c);
        if (k % 3 == 0) polar(cx, cy, cz, ang, r + 0.045 * sc, r + 0.075 * sc, -0.035 * sc, 0.035 * sc, c);
        if (k % 2 == 1) polar(cx, cy, cz, ang, r - 0.075 * sc, r - 0.045 * sc, -0.03 * sc, 0.03 * sc, c);
    }

    private static void ringTube(double cx, double cy, double cz, double r, double w, float[] c, float a) {
        int n = 24;
        double h = 0.025;
        for (int i = 0; i < n; i++) {
            double a0 = i * 2 * Math.PI / n, a1 = (i + 1) * 2 * Math.PI / n;
            double c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
            double ri = r - w, ro = r + w;
            quad(cx + ri * c0, cy + h, cz + ri * s0, cx + ro * c0, cy + h, cz + ro * s0, cx + ro * c1, cy + h, cz + ro * s1, cx + ri * c1, cy + h, cz + ri * s1, c, a);
            quad(cx + ri * c0, cy - h, cz + ri * s0, cx + ro * c0, cy - h, cz + ro * s0, cx + ro * c1, cy - h, cz + ro * s1, cx + ri * c1, cy - h, cz + ri * s1, c, a);
            quad(cx + ro * c0, cy - h, cz + ro * s0, cx + ro * c1, cy - h, cz + ro * s1, cx + ro * c1, cy + h, cz + ro * s1, cx + ro * c0, cy + h, cz + ro * s0, c, a);
        }
    }

    /** อนิเมชันดูดซับ: วงแหวนหดเข้าหาตัวพร้อมลอยขึ้น มีลำแสงพุ่ง */
    private static void absorb(double px, double py, double pz, int tier, float pr, float t) {
        tier = Math.max(0, Math.min(4, tier));
        double r = 0.45 + 2.6 * (1 - pr), y = py + 0.1 + pr * 1.3;
        if (pass == 0) {
            ringTube(px, y, pz, r, 0.05, BODY[tier], 0.95F);
        } else {
            ringTube(px, y, pz, r, 0.12, GLOW[tier], 0.35F);
            for (int k = 0; k < 4; k++) {
                double an = t * 0.5 + k * Math.PI / 2;
                double bx = px + Math.cos(an) * r, bz = pz + Math.sin(an) * r;
                line(bx, y - 0.08, bz, bx, y + 0.08, bz, 0.05, GLOW[tier], 0.9F);
            }
            line(px, py, pz, px, py + 2.3, pz, 0.3, GLOW[tier], 0.06F + 0.3F * pr);
            if (pr > 0.92F) line(px, py, pz, px, py + 2.6, pz, 0.9, GLOW[tier], 0.35F);
        }
    }

    // ================= โมเดลวิญญาณยุทธ์ =================
    private static void hammer(double hx, double hy, double hz, float t) {
        double yaw = t * 0.026, k = 0.55;
        if (pass == 0) {
            boxY(hx, hy, hz, 0.04 * k, 0.6 * k, 0.04 * k, yaw, WOOD, 1F);
            boxY(hx, hy + 0.535 * k, hz, 0.28 * k, 0.185 * k, 0.18 * k, yaw, STEEL, 1F);
            boxY(hx, hy + 0.53 * k, hz, 0.30 * k, 0.03 * k, 0.20 * k, yaw, BLUE, 1F);
        } else {
            boxY(hx, hy, hz, 0.09 * k, 0.62 * k, 0.09 * k, yaw, BLUE, 0.22F);
            boxY(hx, hy + 0.535 * k, hz, 0.34 * k, 0.24 * k, 0.24 * k, yaw, BLUE, 0.28F);
        }
    }

    private static double[] stem(double hx, double hy, double hz, double u, double sway) {
        return new double[]{hx + Math.sin(u * 2.4) * 0.06 + sway * u, hy + 0.05 + u * 0.8, hz + Math.cos(u * 1.8) * 0.03};
    }

    /** หญ้าสีเงินคราม: ต้นอ่อนเรืองแสงลอยเหนือฝ่ามือ (ตามภาพอ้างอิง) */
    private static void plant(double hx, double hy, double hz, float t) {
        double sway = Math.sin(t * 0.05) * 0.03;
        if (pass == 1) {
            line(hx - 0.22, hy + 0.05, hz, hx + 0.22, hy + 0.05, hz, 0.12, ORB, 0.5F);
            line(hx, hy - 0.17, hz, hx, hy + 0.27, hz, 0.12, ORB, 0.5F);
            line(hx, hy + 0.05, hz - 0.22, hx, hy + 0.05, hz + 0.22, 0.12, ORB, 0.5F);
        }
        double[] pv = {hx, hy, hz};
        for (int i = 1; i <= 8; i++) {
            double[] q = stem(hx, hy, hz, i / 8.0, sway);
            seg(pv[0], pv[1], pv[2], q[0], q[1], q[2], 0.014 * (1 - 0.5 * i / 8.0), STEM, CY_GLOW);
            pv = q;
        }
        double[][] lv = {{0.28, 0.4, 0.7, 0.30}, {0.42, 3.4, 0.8, 0.27}, {0.6, 5.6, 0.6, 0.25}, {0.78, 2.4, 0.5, 0.22},
                         {0.15, 1.6, 1.0, 0.18}, {0.2, 4.7, 0.95, 0.18}, {0.52, 1.0, 0.75, 0.17}, {0.92, 0.2, 0.4, 0.15}};
        for (int i = 0; i < lv.length; i++) {
            double[] s = stem(hx, hy, hz, lv[i][0], sway);
            double az = lv[i][1] + Math.sin(t * 0.05 + i) * 0.15, tl = lv[i][2];
            leaf(s[0], s[1], s[2], Math.cos(az) * Math.cos(tl), Math.sin(tl), Math.sin(az) * Math.cos(tl), lv[i][3], lv[i][3] * 0.4);
        }
        double[] a = stem(hx, hy, hz, 0.35, sway);
        curl(a[0], a[1], a[2], -1, 0.45, 0, 0.35, 2.2);
        double[] c = stem(hx, hy, hz, 1.0, sway);
        curl(c[0], c[1], c[2], 0.1, 0.9, 0, 0.12, 1.5);
    }

    private static void curl(double bx, double by, double bz, double dx, double dy, double dz, double len, double turns) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        double px = bx, py = by, pz = bz;
        for (int k = 1; k <= 10; k++) {
            double u = k / 10.0, rad = 0.05 * (1 - u), ang = u * turns * 2 * Math.PI;
            double x = bx + dx * u * len + Math.cos(ang) * rad, y = by + dy * u * len + Math.sin(ang) * rad, z = bz + dz * u * len;
            seg(px, py, pz, x, y, z, 0.008, STEM, CY_GLOW);
            px = x; py = y; pz = z;
        }
    }

    /** ใบไม้มีจุดลายแบบในภาพ */
    private static void leaf(double bx, double by, double bz, double dx, double dy, double dz, double len, double wid) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        double sx = -dz, sz = dx, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        if (pass == 0) {
            kite(bx, by, bz, dx, dy, dz, sx, 0, sz, len, wid, CY_CORE, 0.88F);
            kite(bx + dx * len * 0.05, by + dy * len * 0.05, bz + dz * len * 0.05, dx, dy, dz, sx, 0, sz, len * 0.8, wid * 0.55, CY_LIGHT, 0.5F);
            for (int k = 0; k < 3; k++) {
                double f = 0.28 + k * 0.2, off = (k % 2 == 0 ? 1 : -1) * wid * 0.25;
                kite(bx + dx * len * f + sx * off, by + dy * len * f, bz + dz * len * f + sz * off, dx, dy, dz, sx, 0, sz, len * 0.15, wid * 0.12, CY_SPOT, 0.9F);
            }
        } else {
            kite(bx, by, bz, dx, dy, dz, sx, 0, sz, len * 1.15, wid * 1.5, CY_GLOW, 0.22F);
        }
    }

    // ================= เอฟเฟกต์สกิล =================
    private static void drawFx(Minecraft mc, ClientFx.Fx f, float pt, Entity view, boolean first) {
        float age = f.age + pt, left = f.dur - age;
        fade = left < 8 ? Math.max(0F, left / 8F) : 1F;
        Entity en = f.ent >= 0 ? mc.world.getEntityByID(f.ent) : null;
        if (f.ent >= 0 && en == null) { fade = 1F; return; }
        if (en == view && first && ((f.type >= 6 && f.type <= 8) || f.type == 18)) { fade = 1F; return; }
        switch (f.type) {
            case 1: wrap(f, en, age, pt); break;
            case 2: parasite(en, age, pt); break;
            case 3: web(f, age); break;
            case 4: cage(f, age); break;
            case 5: spear(f, age); break;
            case 6: voidFx(en, age, pt); break;
            case 7: trueForm(en, age, pt); break;
            case 8: mirror(en, age, pt); break;
            case 9: storm(f, age); break;
            case 10: awakenFx(f, en, age, pt); break;
            case 11: slashFx(f, age); break;
            case 12: shockFx(f, age); break;
            case 13: trailFx(f, age); break;
            case 14: auraFx(f, en, age, pt); break;
            case 15: ringFlashFx(f, en, age, pt); break;
            case 16: sphereFx(f, age); break;
            case 17: orbitFx(f, en, age, pt); break;
            case 18: formFx(f, en, age, pt); break;
            default: break;
        }
        fade = 1F;
    }

    /** 1 พันธนาการ */
    private static void wrap(ClientFx.Fx f, Entity en, float age, float pt) {
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt), H = en.height, W = en.width;
        if (age < 10) {
            double g = age / 10.0;
            vine(f.x, f.y, f.z, f.x + (ex - f.x) * g, f.y + (ey + H * 0.5 - f.y) * g, f.z + (ez - f.z) * g, 0.03, 0.2, 1, age, true);
        }
        double g = Math.min(1.0, age / 14.0);
        for (int k = 0; k < 3; k++) {
            double[] pv = null;
            for (int j = 0; j <= 16; j++) {
                double u = j / 16.0 * g, y = ey + u * H, ang = u * 12.0 + k * 2.094 + age * 0.05, r = W * 0.5 + 0.14 + 0.03 * Math.sin(u * 20);
                double x = ex + Math.cos(ang) * r, z = ez + Math.sin(ang) * r;
                if (pv != null) seg(pv[0], pv[1], pv[2], x, y, z, 0.03, VINE, CY_GLOW);
                if (j % 4 == 2) leafSmall(x, y, z, Math.cos(ang), 0.5, Math.sin(ang), 0.14);
                pv = new double[]{x, y, z};
            }
        }
    }

    /** 2 ปรสิต: เถางอกออกจากร่างศัตรู */
    private static void parasite(Entity en, float age, float pt) {
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt), H = en.height, W = en.width;
        double g = Math.min(1.0, age / 20.0), pulse = 1 + 0.1 * Math.sin(age * 0.4);
        for (int k = 0; k < 8; k++) {
            double a = k * 1.085, by = ey + H * (0.15 + 0.7 * ((k * 37 % 10) / 10.0));
            double bx = ex + Math.cos(a) * W * 0.3, bz = ez + Math.sin(a) * W * 0.3;
            double len = (0.5 + 0.4 * ((k * 53 % 7) / 7.0)) * g * pulse * 2;
            double dx = Math.cos(a), dy = 0.55, dz = Math.sin(a), l = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double tx = bx + dx / l * len, ty = by + dy / l * len, tz = bz + dz / l * len;
            vine(bx, by, bz, tx, ty, tz, 0.035, 0.08, k, age, true);
            leafSmall(tx, ty, tz, dx, dy, dz, 0.24);
        }
    }

    /** 3 โซ่ตรวนใยแมงมุม */
    private static void web(ClientFx.Fx f, float age) {
        double g1 = Math.min(1.0, age / 10.0);
        double qx = f.x + (f.x2 - f.x) * g1, qy = f.y + (f.y2 - f.y) * g1, qz = f.z + (f.z2 - f.z) * g1;
        if (pass == 1) {
            line(qx - 0.2, qy, qz, qx + 0.2, qy, qz, 0.12, ORB, 0.5F);
            line(qx, qy - 0.2, qz, qx, qy + 0.2, qz, 0.12, ORB, 0.5F);
            line(qx, qy, qz - 0.2, qx, qy, qz + 0.2, 0.12, ORB, 0.5F);
        }
        vine(f.x, f.y, f.z, qx, qy, qz, 0.025, 0.1, 3, age, false);
        if (age < 10) return;
        double gr = Math.min(1.0, (age - 10) / 12.0);
        int n = 16;
        double[][] ends = new double[n][3];
        for (int k = 0; k < n; k++) {
            double yy = 1 - 2 * (k + 0.5) / n, rr = Math.sqrt(1 - yy * yy), ph = k * 2.39996;
            double L = 4.2 * gr;
            ends[k][0] = f.x2 + Math.cos(ph) * rr * L; ends[k][1] = f.y2 + yy * L; ends[k][2] = f.z2 + Math.sin(ph) * rr * L;
            vine(f.x2, f.y2, f.z2, ends[k][0], ends[k][1], ends[k][2], 0.03, 0.15, k, age, true);
        }
        for (int lv = 0; lv < 2; lv++) {
            double fr = lv == 0 ? 0.45 : 0.85;
            for (int k = 0; k < n; k++) {
                for (int o : new int[]{1, 3}) {
                    int k2 = (k + o) % n;
                    seg(f.x2 + (ends[k][0] - f.x2) * fr, f.y2 + (ends[k][1] - f.y2) * fr, f.z2 + (ends[k][2] - f.z2) * fr,
                        f.x2 + (ends[k2][0] - f.x2) * fr, f.y2 + (ends[k2][1] - f.y2) * fr, f.z2 + (ends[k2][2] - f.z2) * fr, 0.012, VINE, CY_GLOW);
                }
            }
        }
    }

    /** 4 กรงขังหญ้าเงินคราม */
    private static void cage(ClientFx.Fx f, float age) {
        double R = f.x2, H = f.y2, g = Math.min(1.0, age / 10.0);
        double r = R * (1.35 - 0.35 * g), hh = H * g;
        int n = 12;
        for (int k = 0; k < n; k++) {
            double a = k * 2 * Math.PI / n, ca = Math.cos(a), sa = Math.sin(a);
            double[] pv = null;
            for (int j = 0; j <= 8; j++) {
                double u = j / 8.0, y = f.y + u * hh, rr = r * Math.sqrt(1 - u * u * 0.92);
                double x = f.x + ca * rr, z = f.z + sa * rr;
                if (pv != null) seg(pv[0], pv[1], pv[2], x, y, z, 0.04, VINE, CY_GLOW);
                if (j == 3) leafSmall(x, y, z, ca, 0.3, sa, 0.16);
                pv = new double[]{x, y, z};
            }
        }
        for (double fr : new double[]{0.05, 0.3, 0.55, 0.8}) {
            double y = f.y + fr * hh, rr = r * Math.sqrt(1 - fr * fr * 0.92);
            double pxx = f.x + rr, pzz = f.z;
            for (int s = 1; s <= 20; s++) {
                double a = s * 2 * Math.PI / 20, x = f.x + Math.cos(a) * rr, z = f.z + Math.sin(a) * rr;
                seg(pxx, y, pzz, x, y, z, 0.03, VINE, CY_GLOW);
                pxx = x; pzz = z;
            }
        }
    }

    /** 5 หอกเงินคราม (โมเดลหอก) */
    private static void spear(ClientFx.Fx f, float age) {
        double g = Math.min(1.0, age / 8.0);
        double dx = f.x2 - f.x, dy = f.y2 - f.y, dz = f.z2 - f.z, L = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (L < 0.1) return;
        dx /= L; dy /= L; dz /= L;
        double tipx = f.x + (f.x2 - f.x) * g, tipy = f.y + (f.y2 - f.y) * g, tipz = f.z + (f.z2 - f.z) * g;
        double tx = tipx - dx * 1.7, ty = tipy - dy * 1.7, tz = tipz - dz * 1.7;
        double sx = -dz, sz = dx, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        double ux = dy * sz, uy = dz * sx - dx * sz, uz = -dy * sx;
        if (pass == 0) {
            line(tx, ty, tz, tipx - dx * 0.4, tipy - dy * 0.4, tipz - dz * 0.4, 0.022, SILVER, 1F);
            kite(tipx - dx * 0.45, tipy - dy * 0.45, tipz - dz * 0.45, dx, dy, dz, sx, 0, sz, 0.45, 0.08, CY_LIGHT, 1F);
            kite(tipx - dx * 0.45, tipy - dy * 0.45, tipz - dz * 0.45, dx, dy, dz, ux, uy, uz, 0.45, 0.08, CY_LIGHT, 1F);
            kite(tx + dx * 0.05, ty + dy * 0.05, tz + dz * 0.05, dx, dy, dz, sx, 0, sz, 0.25, 0.07, CY_CORE, 0.9F);
            kite(tx + dx * 0.05, ty + dy * 0.05, tz + dz * 0.05, dx, dy, dz, ux, uy, uz, 0.25, 0.07, CY_CORE, 0.9F);
        } else {
            line(tx, ty, tz, tipx, tipy, tipz, 0.09, CY_GLOW, 0.3F);
            kite(tipx - dx * 0.5, tipy - dy * 0.5, tipz - dz * 0.5, dx, dy, dz, sx, 0, sz, 0.6, 0.16, CY_GLOW, 0.3F);
            line(f.x, f.y, f.z, tx, ty, tz, 0.06, CY_GLOW, 0.12F);
        }
    }

    /** 6 ว่างเปล่า */
    private static void voidFx(Entity en, float age, float pt) {
        if (pass != 1) return;
        double cx = lx(en, pt), cy = ly(en, pt) + en.height * 0.5, cz = lz(en, pt);
        double R = 1.0 + 0.08 * Math.sin(age * 0.3);
        for (int axis = 0; axis < 3; axis++) {
            double px = 0, py = 0, pz = 0;
            for (int s = 0; s <= 20; s++) {
                double a = s * 2 * Math.PI / 20, u = Math.cos(a) * R, v = Math.sin(a) * R;
                double x = axis == 0 ? 0 : u, y = axis == 0 ? u : (axis == 1 ? 0 : v), z = axis == 0 ? v : (axis == 1 ? u : 0);
                if (axis == 1) { x = u; y = 0; z = v; }
                if (s > 0) line(cx + px, cy + py, cz + pz, cx + x, cy + y, cz + z, 0.02, VOIDC, 0.55F);
                px = x; py = y; pz = z;
            }
        }
    }

    /** 7 ร่างจริงเงินคราม */
    private static void trueForm(Entity en, float age, float pt) {
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt), H = en.height + 0.3;
        for (int k = 0; k < 4; k++) {
            double[] pv = null;
            for (int j = 0; j <= 20; j++) {
                double u = j / 20.0, y = ey + u * H, ang = u * 10 + k * 1.57 + age * 0.08, r = 0.42 + 0.05 * Math.sin(u * 15);
                double x = ex + Math.cos(ang) * r, z = ez + Math.sin(ang) * r;
                if (pv != null) seg(pv[0], pv[1], pv[2], x, y, z, 0.035, VINE, CY_GLOW);
                if (j % 5 == 2) leafSmall(x, y, z, Math.cos(ang), 0.6, Math.sin(ang), 0.18);
                pv = new double[]{x, y, z};
            }
        }
        double yaw = 0;
        if (en instanceof EntityLivingBase) {
            EntityLivingBase lb = (EntityLivingBase) en;
            yaw = Math.toRadians(lb.prevRenderYawOffset + (lb.renderYawOffset - lb.prevRenderYawOffset) * pt);
        }
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -fz, rz = fx;
        for (int side = -1; side <= 1; side += 2) {
            for (int j = 0; j < 3; j++) {
                double dx = -fx * 0.6 + rx * side * 0.9, dz = -fz * 0.6 + rz * side * 0.9;
                double dy = 0.2 + 0.3 * j + 0.15 * Math.sin(age * 0.15 + j);
                leaf(ex - fx * 0.2, ey + 1.3, ez - fz * 0.2, dx, dy, dz, 0.9 - 0.15 * j, 0.3 - 0.04 * j);
            }
        }
        if (pass == 1) {
            line(ex - fx * 0.3 - 0.4, ey + 1.0, ez - fz * 0.3, ex - fx * 0.3 + 0.4, ey + 1.0, ez - fz * 0.3, 0.2, CY_GLOW, 0.3F);
            line(ex, ey, ez, ex, ey + 2.2, ez, 0.5, CY_GLOW, 0.06F);
        }
    }

    /** 8 ปีศาจเงินครามแห่งกระจกดับสูญ */
    private static void mirror(Entity en, float age, float pt) {
        double cx = lx(en, pt), cy = ly(en, pt), cz = lz(en, pt), inn = Math.min(1.0, age / 8.0);
        for (int layer = 0; layer < 2; layer++) {
            int n = layer == 0 ? 14 : 9;
            double R = (layer == 0 ? 2.4 : 1.4) * (1.6 - 0.6 * inn), sp = (layer == 0 ? 1 : -1) * age * 0.04;
            for (int k = 0; k < n; k++) {
                double a = k * 2 * Math.PI / n + sp, px = cx + Math.cos(a) * R, pz = cz + Math.sin(a) * R;
                double h = (layer == 0 ? 1.7 : 1.1) + 0.3 * Math.sin(k * 1.9), y0 = cy + 0.2 + 0.15 * Math.sin(age * 0.1 + k);
                double tx = -Math.sin(a) * 0.28, tz = Math.cos(a) * 0.28;
                if (pass == 1) quad(px - tx, y0, pz - tz, px + tx, y0, pz + tz, px + tx, y0 + h, pz + tz, px - tx, y0 + h, pz - tz, MIRC, 0.14F);
                seg(px - tx, y0, pz - tz, px + tx, y0, pz + tz, 0.012, MIRC, MIRC);
                seg(px + tx, y0, pz + tz, px + tx, y0 + h, pz + tz, 0.012, MIRC, MIRC);
                seg(px + tx, y0 + h, pz + tz, px - tx, y0 + h, pz - tz, 0.012, MIRC, MIRC);
                seg(px - tx, y0 + h, pz - tz, px - tx, y0, pz - tz, 0.012, MIRC, MIRC);
                seg(px - tx, y0 + h * 0.2, pz - tz, px + tx, y0 + h * 0.8, pz + tz, 0.01, MIRC, MIRC);
            }
        }
    }

    /** 9 จิตฟ้ามรกตเงินคราม: พายุเถาวัลย์ */
    private static void storm(ClientFx.Fx f, float age) {
        double g = Math.min(1.0, age / f.dur);
        double cx = f.x + (f.x2 - f.x) * g, cy = f.y + (f.y2 - f.y) * g, cz = f.z + (f.z2 - f.z) * g;
        for (int L = 0; L < 12; L++) {
            double h = L * 0.34, r = 0.35 + L * 0.26;
            int n = 8;
            double[] pv = null;
            for (int k = 0; k <= n; k++) {
                double a = age * (0.45 + L * 0.02) + L * 0.55 + k * 6.283 / n;
                double x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r, y = cy + h;
                if (k < n) {
                    if (pass == 0) kite(x, y, z, -Math.sin(a), 0.25, Math.cos(a), 0, 1, 0, 0.55, 0.12, CY_CORE, 0.85F);
                    else kite(x, y, z, -Math.sin(a), 0.25, Math.cos(a), 0, 1, 0, 0.7, 0.2, CY_GLOW, 0.25F);
                }
                if (pv != null && pass == 1) line(pv[0], pv[1], pv[2], x, y, z, 0.01, CY_GLOW, 0.2F);
                pv = new double[]{x, y, z};
            }
        }
        if (pass == 1) line(cx, cy, cz, cx, cy + 4.2, cz, 0.7, CY_GLOW, 0.07F);
    }

    // ================= ตัวมอนสเตอร์/เครื่องมือจริงของเกมยืนด้านหลัง =================
    private static final java.util.Map<Integer, EntityLivingBase> DUMMIES = new HashMap<>();
    private static ItemStack toolAxe, toolPick, toolShovel, toolHoe;

    private static EntityLivingBase dummy(Minecraft mc, int soul) {
        EntityLivingBase d = DUMMIES.get(soul);
        if (d == null || d.world != mc.world) {
            switch (soul) {
                case 256: d = new EntityZombie(mc.world); break;
                case 512: d = new EntitySkeleton(mc.world); break;
                case 1024: d = new EntityCreeper(mc.world); break;
                case 2048: d = new EntitySpider(mc.world); break;
                case 4096: d = new EntityEnderman(mc.world); break;
                case 8: { EntityRabbit rb = new EntityRabbit(mc.world); rb.setRabbitType(1); d = rb; break; }
                default: d = new EntityBlaze(mc.world); break;
            }
            DUMMIES.put(soul, d);
        }
        return d;
    }

    /** ร่างจริง (ทักษะที่ 7): วิญญาณยุทธ์มาแทนร่างกายของผู้เล่น */
    private static ClientFx.Fx formOf(Entity p) {
        for (ClientFx.Fx f : ClientFx.LIST) if (f.type == 18 && f.ent == p.getEntityId() && f.age < f.dur) return f;
        return null;
    }

    @SubscribeEvent
    public static void hidePlayer(RenderPlayerEvent.Pre e) {
        if (formOf(e.getEntityPlayer()) != null) e.setCanceled(true);
    }

    private static void renderRealSouls(Minecraft mc, float pt) {
        Entity view = mc.getRenderViewEntity();
        boolean first = mc.gameSettings.thirdPersonView == 0;
        boolean need = false;
        for (EntityPlayer p : mc.world.playerEntities) {
            ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
            if (formOf(p) != null || (v != null && v.released && v.soul >= 16)) { need = true; break; }
        }
        if (!need) return;
        mc.entityRenderer.enableLightmap();
        RenderHelper.enableStandardItemLighting();
        for (EntityPlayer p : mc.world.playerEntities) {
            try {
                ClientFx.Fx form = formOf(p);
                if (form != null) {
                    int soul = (int) form.x2;
                    if (!(p == view && first) && (soul == 8 || soul >= 256)) renderMob(mc, p, soul, pt, true);
                    continue;
                }
                ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
                if (v == null || !v.released || v.soul < 16) continue;
                if (v.soul <= 128) renderTool(mc, p, v.soul, pt);
                else renderMob(mc, p, v.soul, pt, false);
            } catch (RuntimeException ex) { /* ข้าม */ }
        }
        RenderHelper.disableStandardItemLighting();
        mc.entityRenderer.disableLightmap();
    }

    private static void renderTool(Minecraft mc, EntityPlayer p, int soul, float pt) {
        if (toolAxe == null) {
            toolAxe = new ItemStack(Items.IRON_AXE); toolPick = new ItemStack(Items.IRON_PICKAXE);
            toolShovel = new ItemStack(Items.IRON_SHOVEL); toolHoe = new ItemStack(Items.IRON_HOE);
        }
        double yaw = Math.toRadians(p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt);
        double x = lx(p, pt) - Math.cos(yaw) * 0.45 - Math.sin(yaw) * 0.4, z = lz(p, pt) - Math.sin(yaw) * 0.45 + Math.cos(yaw) * 0.4;
        float t = p.ticksExisted + pt;
        double y = ly(p, pt) + 1.4 + 0.06 * Math.sin(t * 0.07);
        ItemStack st = soul == 16 ? toolAxe : soul == 32 ? toolPick : soul == 64 ? toolShovel : toolHoe;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x - ox, y - oy, z - oz);
        GlStateManager.rotate(t * 2F, 0, 1, 0);
        GlStateManager.scale(1.1F, 1.1F, 1.1F);
        mc.getTextureManager().bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        GlStateManager.enableRescaleNormal();
        GlStateManager.enableBlend();
        mc.getRenderItem().renderItem(st, ItemCameraTransforms.TransformType.FIXED);
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
    }

    private static void renderMob(Minecraft mc, EntityPlayer p, int soul, float pt, boolean form) {
        EntityLivingBase d = dummy(mc, soul);
        float yaw = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;
        double yr = Math.toRadians(yaw);
        double dist = form ? 0 : (soul == 2048 ? 1.6 : 1.15);
        double sc = form ? (soul == 8 ? 2.2 : 1.0) : (soul == 2048 ? 1.3 : 1.35);
        double x = lx(p, pt) + Math.sin(yr) * dist, y = ly(p, pt), z = lz(p, pt) - Math.cos(yr) * dist;
        d.setPosition(x, y, z);
        d.prevPosX = d.lastTickPosX = x; d.prevPosY = d.lastTickPosY = y; d.prevPosZ = d.lastTickPosZ = z;
        d.rotationYaw = d.prevRotationYaw = yaw;
        d.renderYawOffset = d.prevRenderYawOffset = yaw;
        d.rotationYawHead = d.prevRotationYawHead = p.prevRotationYawHead + (p.rotationYawHead - p.prevRotationYawHead) * pt;
        d.rotationPitch = d.prevRotationPitch = 0F;
        d.limbSwing = p.limbSwing; d.limbSwingAmount = p.limbSwingAmount; d.prevLimbSwingAmount = p.prevLimbSwingAmount;
        d.ticksExisted = p.ticksExisted;
        d.hurtTime = 0; d.deathTime = 0;
        double cx = x - ox, cy = y - oy, cz = z - oz;
        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, cy, cz);
        GlStateManager.scale(sc, sc, sc);
        GlStateManager.translate(-cx, -cy, -cz);
        mc.getRenderManager().renderEntityStatic(d, pt, false);
        GlStateManager.popMatrix();
    }

    /** 18 ร่างจริงของพยัคฆ์ขาว (ตัวอื่นเรนเดอร์ด้วยโมเดลจริงใน renderRealSouls) */
    private static void formFx(ClientFx.Fx f, Entity en, float age, float pt) {
        if ((int) f.x2 != 4) return;
        double yaw = 0;
        if (en instanceof EntityLivingBase) {
            EntityLivingBase lb = (EntityLivingBase) en;
            yaw = Math.toRadians(lb.prevRenderYawOffset + (lb.renderYawOffset - lb.prevRenderYawOffset) * pt);
        }
        tigerBody(lx(en, pt), ly(en, pt), lz(en, pt), yaw, en.ticksExisted + pt, 1.5);
    }

    /** 16 ระเบิดทรงกลม (วงขยายออก) */
    private static void sphereFx(ClientFx.Fx f, float age) {
        if (pass != 1) return;
        float[] c = pal(f.pal);
        double g = Math.min(1.0, age / f.dur), R = f.x2 * (0.15 + 0.85 * g);
        float a = 0.6F * (1F - (float) g) + 0.1F;
        flatRing(f.x, f.y + 0.05, f.z, R - 0.2, R, c, a * 0.8F);
        for (int axis = 0; axis < 3; axis++) {
            double px = 0, py = 0, pz = 0;
            for (int sIdx = 0; sIdx <= 24; sIdx++) {
                double an = sIdx * 2 * Math.PI / 24, u = Math.cos(an) * R, v = Math.sin(an) * R;
                double x = axis == 0 ? 0 : u, y = axis == 0 ? u : (axis == 1 ? 0 : v), z = axis == 0 ? v : (axis == 1 ? v : 0);
                if (axis == 1) { x = u; y = 0; z = v; }
                if (axis == 2) { x = u; y = v; z = 0; }
                if (sIdx > 0) line(f.x + px, f.y + 0.8 + py, f.z + pz, f.x + x, f.y + 0.8 + y, f.z + z, 0.05, c, a);
                px = x; py = y; pz = z;
            }
        }
        float fl = Math.max(0F, 1F - (float) (age / (f.dur * 0.4)));
        line(f.x - R * 0.5, f.y + 0.8, f.z, f.x + R * 0.5, f.y + 0.8, f.z, 0.3 * fl + 0.01, WHITE, fl);
        line(f.x, f.y + 0.3, f.z, f.x, f.y + 1.3, f.z, 0.3 * fl + 0.01, WHITE, fl);
    }

    /** 17 อาวุธ/ลูกไฟหมุนวนรอบตัว */
    private static void orbitFx(ClientFx.Fx f, Entity en, float age, float pt) {
        float[] c = pal(f.pal);
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt), r = f.x2;
        for (int i = 0; i < 6; i++) {
            double ang = age * 0.5 + i * 1.047, y = ey + 1.0 + 0.2 * Math.sin(age * 0.2 + i);
            double x = ex + Math.cos(ang) * r, z = ez + Math.sin(ang) * r, tx = -Math.sin(ang), tz = Math.cos(ang);
            if (pass == 0) {
                kite(x, y, z, tx, 0, tz, 0, 1, 0, 0.5, 0.15, WHITE, 0.95F);
            } else {
                kite(x, y, z, tx, 0, tz, 0, 1, 0, 0.7, 0.3, c, 0.35F);
                double a2 = ang - 0.5;
                line(ex + Math.cos(a2) * r, y, ez + Math.sin(a2) * r, x, y, z, 0.05, c, 0.3F);
            }
        }
    }

    // ================= อนิเมชันปลุกวิญญาณยุทธ์ + เอฟเฟกต์สายสัตว์ =================
    private static float[] pal(int id) { return PAL[Math.max(0, Math.min(PAL.length - 1, id))]; }

    /** 10 ปลุก/รีวิญญาณยุทธ์: วงเวทที่พื้น เสาแสง เกลียวแสงรวมเข้าหาตัว */
    private static void awakenFx(ClientFx.Fx f, Entity en, float age, float pt) {
        if (pass != 1) return;
        float[] c = pal(f.pal);
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt);
        double prog = Math.min(1.0, age / f.dur), R = 2.0 * Math.min(1.0, age / 15.0), rot = age * 0.05;
        flatRing(ex, ey + 0.03, ez, R - 0.1, R, c, 0.45F);
        flatRing(ex, ey + 0.03, ez, R * 0.62 - 0.08, R * 0.62, c, 0.45F);
        flatRing(ex, ey + 0.03, ez, 0.0, R * 0.62, c, 0.08F);
        for (int k = 0; k < 12; k++) glyph(ex, ey + 0.04, ez, R * 0.81, rot + k * 0.5236, c, k);
        line(ex, ey, ez, ex, ey + 4, ez, 0.15 + 0.4 * prog, c, 0.12F + 0.3F * (float) prog);
        for (int k = 0; k < 6; k++) {
            double[] pv = null;
            for (int j = 0; j <= 14; j++) {
                double u = j / 14.0, y = ey + u * 3, ang = age * 0.25 + u * 8 + k * 1.047, r = 1.6 * (1 - prog * 0.8) * (1 - u * 0.5);
                double x = ex + Math.cos(ang) * r, z = ez + Math.sin(ang) * r;
                if (pv != null) line(pv[0], pv[1], pv[2], x, y, z, 0.03, c, 0.6F);
                pv = new double[]{x, y, z};
            }
        }
        double os = 0.05 + 0.4 * prog, oy = ey + 1.3;
        line(ex - os, oy, ez, ex + os, oy, ez, 0.12, WHITE, 0.6F);
        line(ex, oy - os, ez, ex, oy + os, ez, 0.12, WHITE, 0.6F);
        line(ex, oy, ez - os, ex, oy, ez + os, 0.12, WHITE, 0.6F);
        if (age > f.dur - 6) line(ex, ey, ez, ex, ey + 5, ez, 1.2, WHITE, 0.5F);
    }

    /** 11 รอยกรงเล็บ/รอยฟัน (ทิศทางอยู่ใน x2,z2) */
    private static void slashFx(ClientFx.Fx f, float age) {
        if (pass != 1) return;
        double L = Math.sqrt(f.x2 * f.x2 + f.z2 * f.z2);
        if (L < 1e-4) return;
        double dx = f.x2 / L, dz = f.z2 / L, sxn = -dz, szn = dx, g = Math.min(1.0, age / 4.0), span = Math.max(1.2, L * 0.55);
        float[] c = pal(f.pal);
        for (int k = -1; k <= 1; k++) {
            double[] pv = null;
            for (int j = 0; j <= 10; j++) {
                double u = j / 10.0 * g, bow = Math.sin(u * Math.PI) * 0.4 * span;
                double x = f.x + sxn * (u - 0.5) * 2 * span + dx * bow + sxn * 0.65 * k * 0.2 * span;
                double y = f.y + (0.5 - u) * 1.3 * span + 0.76 * k * 0.2 * span;
                double z = f.z + szn * (u - 0.5) * 2 * span + dz * bow + szn * 0.65 * k * 0.2 * span;
                if (pv != null) {
                    line(pv[0], pv[1], pv[2], x, y, z, 0.12, c, 0.25F);
                    line(pv[0], pv[1], pv[2], x, y, z, 0.05, c, 0.7F);
                    line(pv[0], pv[1], pv[2], x, y, z, 0.02, WHITE, 0.9F);
                }
                pv = new double[]{x, y, z};
            }
        }
    }

    /** 12 คลื่นกระแทก (รัศมีใน x2) */
    private static void shockFx(ClientFx.Fx f, float age) {
        if (pass != 1) return;
        float[] c = pal(f.pal);
        double g = Math.min(1.0, age / f.dur), R = f.x2 * (0.2 + 0.8 * g), h = 0.6 * (1 - g);
        flatRing(f.x, f.y + 0.05, f.z, R - 0.25, R, c, 0.5F * (1F - (float) g) + 0.1F);
        flatRing(f.x, f.y + 0.05, f.z, R * 0.7 - 0.15, R * 0.7, c, 0.3F);
        for (int i = 0; i < 24; i++) {
            double a0 = i * 2 * Math.PI / 24, a1 = (i + 1) * 2 * Math.PI / 24;
            quad(f.x + R * Math.cos(a0), f.y, f.z + R * Math.sin(a0), f.x + R * Math.cos(a1), f.y, f.z + R * Math.sin(a1),
                 f.x + R * Math.cos(a1), f.y + h, f.z + R * Math.sin(a1), f.x + R * Math.cos(a0), f.y + h, f.z + R * Math.sin(a0), c, 0.35F);
        }
    }

    /** 13 ภาพติดตา/ลำแสงพุ่ง */
    private static void trailFx(ClientFx.Fx f, float age) {
        if (pass != 1) return;
        float[] c = pal(f.pal);
        double g = Math.min(1.0, age / f.dur);
        float a = 1F - (float) g;
        line(f.x, f.y, f.z, f.x2, f.y2, f.z2, 0.18 * (1 - g) + 0.02, c, 0.35F * a + 0.05F);
        line(f.x, f.y, f.z, f.x2, f.y2, f.z2, 0.05, WHITE, 0.7F * a);
        for (int i = 0; i <= 5; i++) {
            double u = i / 5.0, x = f.x + (f.x2 - f.x) * u, y = f.y + (f.y2 - f.y) * u, z = f.z + (f.z2 - f.z) * u;
            line(x, y - 0.7, z, x, y + 0.9, z, 0.06 * (1 - g), c, 0.4F * a);
        }
    }

    /** 14 ออร่าร่างสัตว์: เกลียวเปลวรอบตัว */
    private static void auraFx(ClientFx.Fx f, Entity en, float age, float pt) {
        if (pass != 1) return;
        float[] c = pal(f.pal);
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt), H = en.height + 0.2;
        for (int k = 0; k < 3; k++) {
            for (int j = 0; j < 12; j++) {
                double u = j / 12.0, ang = age * 0.2 + u * 9 + k * 2.094;
                kite(ex + Math.cos(ang) * 0.55, ey + u * H, ez + Math.sin(ang) * 0.55, 0, 1, 0, Math.cos(ang), 0, Math.sin(ang), 0.3, 0.08, c, 0.6F);
            }
        }
        flatRing(ex, ey + 0.03, ez, 0.8, 0.95, c, 0.4F);
    }

    /** หูและหางกระต่ายกระดูกอ่อน */
    private static void rabbitGear(double px, double py, double pz, double yaw, double hyaw, float t) {
        double hfx = -Math.sin(hyaw), hfz = Math.cos(hyaw), hrx = -hfz, hrz = hfx;
        for (int s = -1; s <= 1; s += 2) {
            for (int k = 0; k < 4; k++) {
                double cx = px + hrx * s * (0.13 + 0.05 * k) - hfx * 0.04 * k, cz = pz + hrz * s * (0.13 + 0.05 * k) - hfz * 0.04 * k;
                double cy = py + 1.78 + 0.15 * k + Math.sin(t * 0.1 + s) * 0.01 * k;
                if (pass == 0) {
                    boxY(cx, cy, cz, 0.045, 0.09, 0.025, hyaw, WHITE, 1F);
                    boxY(cx + hfx * 0.02, cy, cz + hfz * 0.02, 0.025, 0.08, 0.012, hyaw, PINK, 1F);
                } else {
                    boxY(cx, cy, cz, 0.07, 0.12, 0.05, hyaw, PINK, 0.25F);
                }
            }
        }
        double bfx = -Math.sin(yaw), bfz = Math.cos(yaw), tx = px - bfx * 0.28, tz = pz - bfz * 0.28, ty = py + 0.85;
        if (pass == 0) boxY(tx, ty, tz, 0.11, 0.11, 0.11, yaw, WHITE, 1F);
        else boxY(tx, ty, tz, 0.16, 0.16, 0.16, yaw, PINK, 0.25F);
    }

    /** หูและหางพยัคฆ์ขาว (ลายขาวดำ เรืองทอง) */
    private static void tigerGear(double px, double py, double pz, double yaw, double hyaw, float t) {
        double hfx = -Math.sin(hyaw), hfz = Math.cos(hyaw), hrx = -hfz, hrz = hfx;
        for (int s = -1; s <= 1; s += 2) {
            double cx = px + hrx * s * 0.2, cz = pz + hrz * s * 0.2, cy = py + 1.86;
            if (pass == 0) {
                boxY(cx, cy, cz, 0.06, 0.06, 0.03, hyaw, WHITE, 1F);
                boxY(cx + hfx * 0.02, cy, cz + hfz * 0.02, 0.03, 0.03, 0.015, hyaw, BLACK, 1F);
            } else {
                boxY(cx, cy, cz, 0.09, 0.09, 0.06, hyaw, TIGOLD, 0.25F);
            }
        }
        double bfx = -Math.sin(yaw), bfz = Math.cos(yaw), brx = -bfz, brz = bfx;
        for (int k = 0; k < 8; k++) {
            double d = 0.2 + 0.09 * k, sway = Math.sin(t * 0.1 + k * 0.5) * 0.07 * k / 4;
            double cx = px - bfx * d + brx * sway, cz = pz - bfz * d + brz * sway, cy = py + 0.75 + 0.06 * k + 0.015 * k * k;
            if (pass == 0) boxY(cx, cy, cz, 0.05, 0.05, 0.05, yaw, k % 2 == 0 ? WHITE : BLACK, 1F);
            else boxY(cx, cy, cz, 0.08, 0.08, 0.08, yaw, TIGOLD, 0.22F);
        }
    }

    /** 15 วงแหวนที่ใช้สกิลปรากฏชั่วครู่แล้วจางหาย (x2 = ลำดับวง, pal = ระดับอายุวง) */
    private static void ringFlashFx(ClientFx.Fx f, Entity en, float age, float pt) {
        int idx = (int) f.x2;
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt);
        double p = clamp01(age / 6.0), sc = 0.25 + 0.75 * (p * (2 - p));
        fade = age < 6 ? (float) (age / 6.0) : (age < f.dur - 14 ? 1F : Math.max(0F, (f.dur - age) / 14F));
        double r = 0.55 + 0.17 * idx;
        flatCircle(ex, ey + 0.4 + idx * 0.004, ez, r * sc, f.pal, age, idx, false, sc);
        if (pass == 1 && age < 8) {
            double g = age / 8.0, rr = r * (0.6 + 0.8 * g);
            flatRing(ex, ey + 0.4, ez, rr - 0.04, rr, WHITE, (float) (0.5 * (1 - g)));
        }
    }

    /** กล่องที่ชดเชยตำแหน่งตามการหมุน (พิกัดภายในตัวโมเดล) */
    private static void boxL(double cx, double cy, double cz, double ox, double oy, double oz, double hx, double hy, double hz, double yaw, float[] c, float a) {
        double co = Math.cos(yaw), si = Math.sin(yaw);
        boxY(cx + ox * co - oz * si, cy + oy, cz + ox * si + oz * co, hx, hy, hz, yaw, c, a);
    }

    private static final float[] IRON = {0.78F, 0.8F, 0.85F};
    private static final float[] EYE_RED = {1F, 0.1F, 0.1F};
    private static final float[] EYE_PURPLE = {0.9F, 0.4F, 1F};

    // ---------- โมเดลเต็มตัวด้านหลัง ----------
    private static double MX, MY, MZ, MYAW, MSC = 1.0;

    private static void mctx(double x, double y, double z, double yaw, double sc) { MX = x; MY = y; MZ = z; MYAW = yaw; MSC = sc; }

    /** กล่องในพิกัดของโมเดล (ซ้าย +x, หน้า +z, ขึ้น +y) */
    private static void mb(double ox, double oy, double oz, double hx, double hy, double hz, float[] c, float a) {
        boxL(MX, MY, MZ, ox * MSC, oy * MSC, oz * MSC, hx * MSC, hy * MSC, hz * MSC, MYAW, c, a);
    }

    private static float[] col(float[] c, float[] gl) { return pass == 0 ? c : gl; }

    /** พยัคฆ์ขาวเต็มตัว */
    private static void tigerBody(double ax, double ay, double az, double yaw, float t, double sc) {
        mctx(ax, ay + 0.05 * Math.sin(t * 0.06), az, yaw, sc);
        float a = pass == 0 ? 1F : 0.2F;
        double g = pass == 0 ? 0 : 0.05;
        float[] w = col(WHITE, TIGOLD), k = col(BLACK, TIGOLD);
        mb(0, 0.75, 0, 0.22 + g, 0.22 + g, 0.55 + g, w, a);
        mb(0, 0.95, 0.75, 0.2 + g, 0.18 + g, 0.2 + g, w, a);
        for (int s = -1; s <= 1; s += 2) {
            mb(s * 0.13, 1.17, 0.7, 0.06 + g, 0.06 + g, 0.03 + g, w, a);
            for (int z = -1; z <= 1; z += 2) {
                mb(s * 0.14, 0.3, z * 0.4, 0.07 + g, 0.3 + g, 0.07 + g, w, a);
                if (pass == 0) mb(s * 0.14, 0.03, z * 0.4 + 0.02, 0.08, 0.03, 0.09, k, 1F);
            }
        }
        for (int i = 0; i < 7; i++) {
            double sw = Math.sin(t * 0.1 + i * 0.6) * 0.05 * i;
            mb(sw, 0.8 + 0.05 * i + 0.012 * i * i, -0.62 - 0.08 * i, 0.05 + g, 0.05 + g, 0.05 + g, (pass == 0 && i % 2 == 1) ? BLACK : w, a);
        }
        if (pass == 0) {
            for (int i = -3; i <= 3; i++) mb(0, 0.75, i * 0.15, 0.23, 0.23, 0.03, BLACK, 1F);
            mb(0.09, 1.0, 0.955, 0.04, 0.03, 0.01, TIGOLD, 1F);
            mb(-0.09, 1.0, 0.955, 0.04, 0.03, 0.01, TIGOLD, 1F);
            mb(0, 0.9, 0.955, 0.05, 0.04, 0.01, BLACK, 1F);
            mb(0, 1.1, 0.93, 0.12, 0.015, 0.02, BLACK, 1F);
            mb(0, 1.14, 0.93, 0.05, 0.015, 0.02, BLACK, 1F);
        }
    }

    /** กระต่ายกระดูกอ่อนเต็มตัว */
    private static void rabbitBody(double ax, double ay, double az, double yaw, float t) {
        mctx(ax, ay + 0.05 * Math.sin(t * 0.06), az, yaw, 1.5);
        float a = pass == 0 ? 1F : 0.22F;
        double g = pass == 0 ? 0 : 0.05;
        float[] w = col(WHITE, PINK);
        mb(0, 0.55, 0, 0.2 + g, 0.2 + g, 0.28 + g, w, a);
        mb(0, 0.8, 0.32, 0.16 + g, 0.15 + g, 0.15 + g, w, a);
        mb(0, 0.5, -0.33, 0.1 + g, 0.1 + g, 0.1 + g, w, a);
        for (int s = -1; s <= 1; s += 2) {
            double sway = Math.sin(t * 0.1 + s) * 0.01;
            mb(s * 0.07, 1.1, 0.3, 0.04 + g, 0.16 + g, 0.025 + g, w, a);
            mb(s * 0.08 + sway, 1.38, 0.27, 0.04 + g, 0.14 + g, 0.025 + g, w, a);
            mb(s * 0.1, 0.18, 0.2, 0.05 + g, 0.18 + g, 0.05 + g, w, a);
            mb(s * 0.15, 0.15, -0.15, 0.07 + g, 0.15 + g, 0.17 + g, w, a);
            if (pass == 0) {
                mb(s * 0.07, 1.1, 0.325, 0.022, 0.13, 0.005, PINK, 1F);
                mb(s * 0.07, 0.84, 0.475, 0.03, 0.03, 0.01, new float[]{0.9F, 0.3F, 0.4F}, 1F);
            }
        }
        if (pass == 0) mb(0, 0.78, 0.475, 0.025, 0.02, 0.01, PINK, 1F);
    }

    private static final float[] BONE = {0.85F, 0.85F, 0.85F};
    private static final float[] DARKBONE = {0.25F, 0.25F, 0.25F};

    /** โมเดลเต็มตัวของวิญญาณยุทธ์มอนสเตอร์ */
    private static void mobBody(int soul, double ax, double ay, double az, double yaw, float t) {
        mctx(ax, ay + 0.05 * Math.sin(t * 0.06), az, yaw, 1.0);
        float[] gl = pal(Awaken.palOf(soul));
        float a = pass == 0 ? 1F : 0.18F;
        double g = pass == 0 ? 0 : 0.05;
        switch (soul) {
            case 256: {
                float[] skin = {0.35F, 0.6F, 0.35F}, shirt = {0.2F, 0.45F, 0.7F}, pants = {0.25F, 0.2F, 0.6F};
                mb(0, 1.65, 0, 0.25 + g, 0.25 + g, 0.25 + g, col(skin, gl), a);
                mb(0, 1.0, 0, 0.25 + g, 0.4 + g, 0.125 + g, col(shirt, gl), a);
                for (int s = -1; s <= 1; s += 2) {
                    mb(s * 0.375, 1.25, 0.3, 0.125 + g, 0.125 + g, 0.4 + g, col(skin, gl), a);
                    mb(s * 0.125, 0.4, 0, 0.125 + g, 0.4 + g, 0.125 + g, col(pants, gl), a);
                    if (pass == 0) mb(s * 0.1, 1.7, 0.255, 0.06, 0.04, 0.01, BLACK, 1F);
                }
                break;
            }
            case 512: {
                mb(0, 1.65, 0, 0.25 + g, 0.25 + g, 0.25 + g, col(BONE, gl), a);
                mb(0, 1.1, 0, 0.15 + g, 0.3 + g, 0.08 + g, col(BONE, gl), a);
                for (int s = -1; s <= 1; s += 2) {
                    mb(s * 0.3, 1.1, 0, 0.05 + g, 0.35 + g, 0.05 + g, col(BONE, gl), a);
                    mb(s * 0.1, 0.4, 0, 0.05 + g, 0.4 + g, 0.05 + g, col(BONE, gl), a);
                    if (pass == 0) mb(s * 0.1, 1.7, 0.255, 0.06, 0.05, 0.01, BLACK, 1F);
                }
                if (pass == 0) {
                    for (int i = 0; i < 3; i++) mb(0, 1.0 + 0.1 * i, 0, 0.16, 0.02, 0.09, DARKBONE, 1F);
                    mb(0, 1.62, 0.255, 0.03, 0.02, 0.01, BLACK, 1F);
                }
                break;
            }
            case 1024: {
                float[] gr = {0.3F, 0.75F, 0.3F};
                mb(0, 1.2, 0, 0.25 + g, 0.25 + g, 0.25 + g, col(gr, gl), a);
                mb(0, 0.7, 0, 0.25 + g, 0.3 + g, 0.125 + g, col(gr, gl), a);
                for (int s = -1; s <= 1; s += 2) for (int z = -1; z <= 1; z += 2) mb(s * 0.13, 0.19, z * 0.22, 0.125 + g, 0.19 + g, 0.125 + g, col(gr, gl), a);
                if (pass == 0) {
                    mb(0.1, 1.25, 0.255, 0.07, 0.07, 0.01, BLACK, 1F);
                    mb(-0.1, 1.25, 0.255, 0.07, 0.07, 0.01, BLACK, 1F);
                    mb(0, 1.1, 0.255, 0.05, 0.1, 0.01, BLACK, 1F);
                    mb(0.1, 1.05, 0.255, 0.04, 0.05, 0.01, BLACK, 1F);
                    mb(-0.1, 1.05, 0.255, 0.04, 0.05, 0.01, BLACK, 1F);
                }
                break;
            }
            case 2048: {
                float[] dk = {0.18F, 0.14F, 0.14F};
                mb(0, 0.5, -0.1, 0.3 + g, 0.2 + g, 0.4 + g, col(dk, gl), a);
                mb(0, 0.5, 0.45, 0.22 + g, 0.2 + g, 0.2 + g, col(dk, gl), a);
                for (int s = -1; s <= 1; s += 2) for (int i = 0; i < 4; i++) {
                    double z = 0.15 - 0.2 * i;
                    mb(s * 0.5, 0.45, z, 0.3 + g, 0.03 + g, 0.03 + g, col(dk, gl), a);
                    mb(s * 0.78, 0.25, z, 0.03 + g, 0.22 + g, 0.03 + g, col(dk, gl), a);
                }
                if (pass == 0) {
                    for (int s = -1; s <= 1; s += 2) {
                        mb(s * 0.1, 0.58, 0.655, 0.04, 0.04, 0.01, EYE_RED, 1F);
                        mb(s * 0.05, 0.48, 0.655, 0.025, 0.025, 0.01, EYE_RED, 1F);
                    }
                }
                break;
            }
            case 4096: {
                float[] bl = {0.07F, 0.07F, 0.09F};
                mb(0, 2.35, 0, 0.22 + g, 0.22 + g, 0.22 + g, col(bl, gl), a);
                mb(0, 1.75, 0, 0.22 + g, 0.35 + g, 0.12 + g, col(bl, gl), a);
                for (int s = -1; s <= 1; s += 2) {
                    mb(s * 0.3, 1.5, 0, 0.06 + g, 0.65 + g, 0.06 + g, col(bl, gl), a);
                    mb(s * 0.1, 0.8, 0, 0.06 + g, 0.8 + g, 0.06 + g, col(bl, gl), a);
                    if (pass == 0) mb(s * 0.1, 2.38, 0.225, 0.07, 0.025, 0.01, EYE_PURPLE, 1F);
                }
                break;
            }
            default: {
                float[] yel = {1F, 0.75F, 0.1F}, rod = {1F, 0.55F, 0.1F};
                mb(0, 1.3, 0, 0.2 + g, 0.2 + g, 0.2 + g, col(yel, gl), a);
                for (int i = 0; i < 8; i++) {
                    double ang = t * 0.1 + i * 0.785;
                    mb(Math.cos(ang) * 0.5, 0.4 + (i % 3) * 0.4, Math.sin(ang) * 0.5, 0.05 + g, 0.3 + g, 0.05 + g, col(rod, gl), a);
                }
                if (pass == 0) {
                    mb(0.08, 1.33, 0.205, 0.04, 0.04, 0.01, BLACK, 1F);
                    mb(-0.08, 1.33, 0.205, 0.04, 0.04, 0.01, BLACK, 1F);
                }
                break;
            }
        }
    }

    /** วิญญาณยุทธ์ขยะ (เครื่องมือลอยด้านหลัง) และมอนสเตอร์ (เต็มตัวด้านหลัง) */
    private static void extraSoul(int soul, double px, double py, double pz, double yaw, float t) {
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        if (soul >= 16 && soul <= 128) {
            double hx = px - fx * 1.1, hz = pz - fz * 1.1;
            float[] gl = pal(Awaken.palOf(soul));
            double hy = py + 1.3 + 0.06 * Math.sin(t * 0.07), yw = t * 0.026;
            if (pass == 0) {
                boxL(hx, hy, hz, 0, 0, 0, 0.03, 0.45, 0.03, yw, WOOD, 1F);
                switch (soul) {
                    case 16: boxL(hx, hy, hz, 0.13, 0.35, 0, 0.14, 0.12, 0.03, yw, IRON, 1F); break;
                    case 32:
                        boxL(hx, hy, hz, 0, 0.43, 0, 0.3, 0.04, 0.04, yw, IRON, 1F);
                        boxL(hx, hy, hz, -0.3, 0.35, 0, 0.04, 0.08, 0.04, yw, IRON, 1F);
                        boxL(hx, hy, hz, 0.3, 0.35, 0, 0.04, 0.08, 0.04, yw, IRON, 1F);
                        break;
                    case 64: boxL(hx, hy, hz, 0, 0.43, 0, 0.09, 0.14, 0.02, yw, IRON, 1F); break;
                    default:
                        boxL(hx, hy, hz, 0.1, 0.43, 0, 0.12, 0.03, 0.03, yw, IRON, 1F);
                        boxL(hx, hy, hz, 0.2, 0.37, 0, 0.03, 0.07, 0.03, yw, IRON, 1F);
                        break;
                }
            } else {
                boxL(hx, hy, hz, 0, 0.1, 0, 0.09, 0.55, 0.09, yw, gl, 0.18F);
                boxL(hx, hy, hz, 0, 0.4, 0, 0.3, 0.2, 0.1, yw, gl, 0.2F);
            }
            return;
        }
        mobBody(soul, px - fx * 1.7, py, pz - fz * 1.7, yaw, t);
    }

    // ================= ตัวช่วยวาด =================
    private static double lx(Entity e, float pt) { return e.lastTickPosX + (e.posX - e.lastTickPosX) * pt; }
    private static double ly(Entity e, float pt) { return e.lastTickPosY + (e.posY - e.lastTickPosY) * pt; }
    private static double lz(Entity e, float pt) { return e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt; }

    private static void vtx(double x, double y, double z, float[] c, float a) {
        float al = a * fade;
        b.pos(x - ox, y - oy, z - oz).color(c[0], c[1], c[2], al > 1F ? 1F : al).endVertex();
    }

    private static void quad(double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3,
                             double x4, double y4, double z4, float[] c, float a) {
        vtx(x1, y1, z1, c, a); vtx(x2, y2, z2, c, a); vtx(x3, y3, z3, c, a); vtx(x4, y4, z4, c, a);
    }

    private static void line(double x1, double y1, double z1, double x2, double y2, double z2, double w, float[] c, float a) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1, len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6) return;
        dx /= len; dy /= len; dz /= len;
        double sx = -dz, sy = 0, sz = dx, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        double tx = dy * sz - dz * sy, ty = dz * sx - dx * sz, tz = dx * sy - dy * sx;
        sx *= w; sy *= w; sz *= w; tx *= w; ty *= w; tz *= w;
        quad(x1 - sx, y1 - sy, z1 - sz, x1 + sx, y1 + sy, z1 + sz, x2 + sx, y2 + sy, z2 + sz, x2 - sx, y2 - sy, z2 - sz, c, a);
        quad(x1 - tx, y1 - ty, z1 - tz, x1 + tx, y1 + ty, z1 + tz, x2 + tx, y2 + ty, z2 + tz, x2 - tx, y2 - ty, z2 - tz, c, a);
    }

    /** เส้นเถา: รอบแกนทึบ (pass 0) + แสงเรืองกว้าง (pass 1) */
    private static void seg(double x1, double y1, double z1, double x2, double y2, double z2, double w, float[] core, float[] glow) {
        if (pass == 0) line(x1, y1, z1, x2, y2, z2, w, core, 0.9F);
        else line(x1, y1, z1, x2, y2, z2, w * 2.6, glow, 0.22F);
    }

    private static void kite(double bx, double by, double bz, double dx, double dy, double dz, double sx, double sy, double sz,
                             double len, double wid, float[] c, float a) {
        double mx = bx + dx * len * 0.4, my = by + dy * len * 0.4, mz = bz + dz * len * 0.4;
        quad(bx, by, bz, mx + sx * wid, my + sy * wid, mz + sz * wid, bx + dx * len, by + dy * len, bz + dz * len,
             mx - sx * wid, my - sy * wid, mz - sz * wid, c, a);
    }

    private static void leafSmall(double x, double y, double z, double dx, double dy, double dz, double len) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        double sx = -dz, sz = dx, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        if (pass == 0) kite(x, y, z, dx, dy, dz, sx, 0, sz, len, len * 0.35, CY_CORE, 0.9F);
        else kite(x, y, z, dx, dy, dz, sx, 0, sz, len * 1.4, len * 0.6, CY_GLOW, 0.2F);
    }

    /** เถาวัลย์โค้งงอ */
    private static void vine(double x1, double y1, double z1, double x2, double y2, double z2, double w, double wob, int seed, float t, boolean leaves) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1, len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.05) return;
        double ux = dx / len, uy = dy / len, uz = dz / len;
        double sx = -uz, sy = 0, sz = ux, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        double tx = uy * sz - uz * sy, ty = uz * sx - ux * sz, tz = ux * sy - uy * sx;
        int n = Math.max(4, Math.min(14, (int) (len * 3.5)));
        double px = x1, py = y1, pz = z1;
        for (int i = 1; i <= n; i++) {
            double u = i / (double) n, env = Math.sin(u * Math.PI);
            double o1 = Math.sin(u * 9 + seed * 1.7 + t * 0.08) * wob * env, o2 = Math.cos(u * 7 + seed * 2.3 + t * 0.06) * wob * env;
            double qx = x1 + dx * u + sx * o1 + tx * o2, qy = y1 + dy * u + sy * o1 + ty * o2, qz = z1 + dz * u + sz * o1 + tz * o2;
            seg(px, py, pz, qx, qy, qz, w * (1 - 0.5 * u), VINE, CY_GLOW);
            if (leaves && i % 3 == 1) { double a = seed + i * 2.1; leafSmall(qx, qy, qz, Math.cos(a), 0.5, Math.sin(a), 0.14); }
            px = qx; py = qy; pz = qz;
        }
    }

    private static void boxY(double cx, double cy, double cz, double hx, double hy, double hz, double yaw, float[] c, float a) {
        double co = Math.cos(yaw), si = Math.sin(yaw);
        double[][] p = new double[8][3];
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? -hx : hx, y = (i & 2) == 0 ? -hy : hy, z = (i & 4) == 0 ? -hz : hz;
            p[i][0] = cx + x * co - z * si; p[i][1] = cy + y; p[i][2] = cz + x * si + z * co;
        }
        int[][] f = {{0, 1, 3, 2}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 3, 7, 5}};
        for (int[] q : f)
            quad(p[q[0]][0], p[q[0]][1], p[q[0]][2], p[q[1]][0], p[q[1]][1], p[q[1]][2],
                 p[q[2]][0], p[q[2]][1], p[q[2]][2], p[q[3]][0], p[q[3]][1], p[q[3]][2], c, a);
    }
}

package com.soulland.mod;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = SoulLand.MODID)
public class ClientHandler {
    public static final KeyBinding CAST = new KeyBinding("key.soulland.cast", Keyboard.KEY_R, "key.categories.soulland");
    public static final KeyBinding CYCLE = new KeyBinding("key.soulland.cycle", Keyboard.KEY_V, "key.categories.soulland");
    public static final KeyBinding RELEASE = new KeyBinding("key.soulland.release", Keyboard.KEY_G, "key.categories.soulland");
    public static final KeyBinding AWAKEN = new KeyBinding("key.soulland.awaken", Keyboard.KEY_M, "key.categories.soulland");
    public static final KeyBinding RINGS = new KeyBinding("key.soulland.rings", Keyboard.KEY_H, "key.categories.soulland");
    public static final KeyBinding MEDITATE = new KeyBinding("key.soulland.meditate", Keyboard.KEY_K, "key.categories.soulland");
    public static final KeyBinding REROLL = new KeyBinding("key.soulland.reroll", Keyboard.KEY_N, "key.categories.soulland");

    @SubscribeEvent
    public static void models(ModelRegistryEvent e) {
        for (Item i : ModItems.ALL)
            ModelLoader.setCustomModelResourceLocation(i, 0, new ModelResourceLocation(i.getRegistryName(), "inventory"));
    }

    @SubscribeEvent
    public static void keys(InputEvent.KeyInputEvent e) {
        while (CAST.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(0));
        while (CYCLE.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(1));
        while (RELEASE.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(2));
        while (AWAKEN.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(3));
        while (REROLL.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(4));
        while (MEDITATE.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(5));
        while (RINGS.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(6));
    }

    /** นั่งฝึก/ดูดซับ: ย่อตัวและล็อกการเคลื่อนไหว */
    @SubscribeEvent
    public static void input(InputUpdateEvent e) {
        ClientState.Visual v = ClientState.visuals.get(e.getEntityPlayer().getUniqueID());
        if (v != null && v.sit) {
            e.getMovementInput().moveForward = 0F;
            e.getMovementInput().moveStrafe = 0F;
            e.getMovementInput().jump = false;
            e.getMovementInput().sneak = false;
        }
    }

    @SubscribeEvent
    public static void hud(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.showDebugInfo || mc.player == null) return;
        FontRenderer fr = mc.fontRenderer;
        int x = 6, y = 6;

        if (ClientState.soul == 0) {
            Gui.drawRect(x - 3, y - 3, x + 150, y + 22, 0xA0000000);
            Gui.drawRect(x - 3, y - 3, x + 150, y - 1, 0xFFAAAAAA);
            fr.drawStringWithShadow(Tr.t("hud.soulland.nosoul"), x, y, 0xFFFFFF);
            fr.drawStringWithShadow(Tr.t("hud.soulland.pressm"), x, y + 11, 0xFFDD55);
            return;
        }

        int soul = ClientState.soul;
        int accent = Souls.accent(soul);
        int w = 132, h = 118, bw = w - 6;

        Gui.drawRect(x - 3, y - 3, x + w, y + h, 0xA0000000);
        Gui.drawRect(x - 3, y - 3, x + w, y - 1, accent);

        // วิญญาณยุทธ์: ชื่อ
        fr.drawStringWithShadow(Tr.t("hud.soulland.soullabel"), x, y, 0xAAAAAA);
        fr.drawStringWithShadow(Tr.t("soul.soulland.hud." + soul), x, y + 10, accent & 0xFFFFFF);

        // เลเวล (ตัวใหญ่)
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y + 21, 0);
        GlStateManager.scale(2.0F, 2.0F, 1.0F);
        fr.drawStringWithShadow("Lv." + ClientState.level, 0, 0, 0xFFFFFF);
        GlStateManager.popMatrix();

        // แถบเลือด
        float hp = mc.player.getHealth(), mhp = Math.max(1F, mc.player.getMaxHealth());
        Gui.drawRect(x, y + 41, x + bw, y + 51, 0xFF1A1A1A);
        Gui.drawRect(x, y + 41, x + Math.min(bw, (int) (bw * Math.min(1F, hp / mhp))), y + 51, 0xFFDD2222);
        fr.drawStringWithShadow(Tr.t("hud.soulland.hp") + " " + (int) Math.ceil(hp) + "/" + (int) Math.ceil(mhp), x + 3, y + 42, 0xFFFFFF);

        // พลังวิญญาณ
        int max = 20 + ClientState.level * 6;
        Gui.drawRect(x, y + 54, x + bw, y + 64, 0xFF1A1A1A);
        Gui.drawRect(x, y + 54, x + Math.min(bw, bw * ClientState.mana / Math.max(1, max)), y + 64, 0xFF2E9BFF);
        fr.drawStringWithShadow(ClientState.mana + "/" + max, x + 3, y + 55, 0xFFFFFF);

        // EXP
        int cap = Math.min(99, 10 * (ClientState.rings + 1));
        boolean stuck = ClientState.level >= cap;
        int need = SoulData.expNeeded(ClientState.level);
        Gui.drawRect(x, y + 67, x + bw, y + 71, 0xFF1A1A1A);
        int ew = stuck ? bw : Math.min(bw, bw * ClientState.exp / Math.max(1, need));
        Gui.drawRect(x, y + 67, x + ew, y + 71, stuck ? 0xFFFF8800 : 0xFF55DD55);

        // ทักษะวิญญาณที่ N + ชื่อสกิล
        if (SoulSkills.available(ClientState.soul, ClientState.rings, ClientState.selected)) {
            SoulSkills.Skill sk = SoulSkills.ALL[ClientState.selected];
            fr.drawStringWithShadow(Tr.t("hud.soulland.skillnum", String.valueOf(sk.ring)), x, y + 75, 0xFFDD55);
            fr.drawStringWithShadow(Tr.t("skill.soulland." + sk.key), x, y + 85, 0xFFFFFF);
        } else {
            fr.drawStringWithShadow(Tr.t("hud.soulland.noskill"), x, y + 75, 0xAAAAAA);
        }
        if (stuck && cap < 99) fr.drawStringWithShadow(Tr.t("hud.soulland.bottleneck"), x, y + 95, 0xFF8800);
        fr.drawStringWithShadow(Tr.t("hud.soulland.medhint"), x, y + 107, 0x88CCFF);
    }
}

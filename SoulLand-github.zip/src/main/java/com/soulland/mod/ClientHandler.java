package com.soulland.mod;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = SoulLand.MODID)
public class ClientHandler {
    public static final KeyBinding CAST = new KeyBinding("key.soulland.cast", Keyboard.KEY_R, "key.categories.soulland");
    public static final KeyBinding CYCLE = new KeyBinding("key.soulland.cycle", Keyboard.KEY_V, "key.categories.soulland");

    @SubscribeEvent
    public static void models(ModelRegistryEvent e) {
        for (Item i : ModItems.ALL)
            ModelLoader.setCustomModelResourceLocation(i, 0, new ModelResourceLocation(i.getRegistryName(), "inventory"));
    }

    @SubscribeEvent
    public static void keys(InputEvent.KeyInputEvent e) {
        while (CAST.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(0));
        while (CYCLE.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(1));
    }

    @SubscribeEvent
    public static void hud(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (ClientState.soul == 0 || mc.gameSettings.showDebugInfo) return;
        int x = 6, y = 6;
        mc.fontRenderer.drawStringWithShadow(I18n.format("soul.soulland." + ClientState.soul), x, y, 0x55FFFF);
        mc.fontRenderer.drawStringWithShadow(I18n.format("hud.soulland.level", ClientState.level)
                + "  " + I18n.format("hud.soulland.rings", ClientState.rings), x, y + 11, 0xFFFFFF);
        int max = 20 + ClientState.level * 6;
        int w = 90;
        Gui.drawRect(x, y + 23, x + w, y + 29, 0xFF222222);
        Gui.drawRect(x, y + 23, x + Math.min(w, w * ClientState.mana / Math.max(1, max)), y + 29, 0xFF33AAFF);
        mc.fontRenderer.drawStringWithShadow(ClientState.mana + "/" + max, x + w + 4, y + 22, 0xAADDFF);
        String sk = SoulSkills.available(ClientState.soul, ClientState.rings, ClientState.selected)
                ? I18n.format("skill.soulland." + SoulSkills.ALL[ClientState.selected].key) : "-";
        mc.fontRenderer.drawStringWithShadow(I18n.format("hud.soulland.skill") + ": " + sk, x, y + 33, 0xFFDD55);
    }
}

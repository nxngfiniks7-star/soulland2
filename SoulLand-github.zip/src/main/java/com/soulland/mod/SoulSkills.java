package com.soulland.mod;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.WorldServer;

public class SoulSkills {
    public static final int HAMMER = 1, GRASS = 2, TIGER = 4, RABBIT = 8;
    public static final int AXE = 16, PICK = 32, SHOVEL = 64, HOE = 128, ZOMBIE = 256, SKELETON = 512, CREEPER = 1024, SPIDER = 2048, ENDER = 4096, BLAZE = 8192, PHOENIX = 16384, GOLEM = 32768, WARDEN = 65536, DRAGON = 131072;
    public static final int K_CUSTOM = 0, K_BURST = 1, K_LINE = 2, K_BUFF = 3, K_DASH = 4, K_TP = 5;

    public static final class Skill {
        public final String key;
        public final int mask, ring, cost;
        public int kind, amp, dur, fire, pal;
        public double dmg, reach, self;
        public Potion effect;
        public Op[] ops;
        public EnumParticleTypes part = EnumParticleTypes.CRIT;
        Skill(String key, int mask, int ring, int cost) { this.key = key; this.mask = mask; this.ring = ring; this.cost = cost; }
    }

    private static Skill g(String key, int mask, int ring, int cost, int kind, double dmg, double reach, Potion eff, int amp, int dur,
                           int fire, double self, int pal, EnumParticleTypes part) {
        Skill s = new Skill(key, mask, ring, cost);
        s.kind = kind; s.dmg = dmg; s.reach = reach; s.effect = eff; s.amp = amp; s.dur = dur; s.fire = fire; s.self = self; s.pal = pal; s.part = part;
        return s;
    }

    /** ทักษะวิญญาณที่ N = ปลดล็อกด้วยวงแหวนวงที่ N */
    /** ทักษะวิญญาณที่ N = ปลดล็อกด้วยวงแหวนวงที่ N (หญ้าสีเงินคราม = ชุดทักษะของถังซาน) */
    public static final Skill[] ALL = {
        new Skill("bind", GRASS, 1, 10),      new Skill("smash", HAMMER, 1, 15),
        new Skill("parasite", GRASS, 2, 20),  new Skill("rage", HAMMER, 2, 20),
        new Skill("web", GRASS, 3, 30),       new Skill("quake", HAMMER, 3, 30),
        new Skill("cage", GRASS, 4, 40),      new Skill("leap", HAMMER, 4, 35),
        new Skill("spear", GRASS, 5, 50),     new Skill("wrath", HAMMER, 5, 60),
        new Skill("void", GRASS, 6, 70),      new Skill("thunder", HAMMER, 6, 70),
        new Skill("trueform", GRASS, 7, 90),  new Skill("gravity", HAMMER, 7, 80),
        new Skill("mirror", GRASS, 8, 110),   new Skill("titan", HAMMER, 8, 100),
        new Skill("tianxin", GRASS, 9, 150),  new Skill("judgement", HAMMER, 9, 150),
        // พยัคฆ์ขาว (สายสัตว์)
        R("tiger1", TIGER, 1, 15, 0, EnumParticleTypes.FIREWORKS_SPARK, oBuff(MobEffects.RESISTANCE, 2, 300), oBuff(MobEffects.ABSORPTION, 4, 300)),
        R("tiger2", TIGER, 2, 25, 0, EnumParticleTypes.FIREWORKS_SPARK, oStream(5, 1.6, 5, 40, 2)),
        R("tiger3", TIGER, 3, 40, 0, EnumParticleTypes.FIREWORKS_SPARK, oBuff(MobEffects.STRENGTH, 2, 400), oBuff(MobEffects.RESISTANCE, 2, 400)),
        R("tiger4", TIGER, 4, 60, 0, EnumParticleTypes.FIREWORKS_SPARK, oJump(1.1, 0.3), oMeteors(8, 16, 26, 70, 10, 0, 10)),
        R("tiger5", TIGER, 5, 80, 7, EnumParticleTypes.SMOKE_LARGE, oBuff(MobEffects.STRENGTH, 3, 400), oBuff(MobEffects.SPEED, 2, 400), oBuff(MobEffects.RESISTANCE, 1, 400), oSelf(4)),
        R("tiger6", TIGER, 6, 110, 0, EnumParticleTypes.FIREWORKS_SPARK, oCross(8, 1.6, 70)),
        // ไอร่อนโกเลม (บอส)
        R("gol1", GOLEM, 1, 12, 6, EnumParticleTypes.CRIT, oCone(3, 1.6, 16, 1.5)),
        R("gol2", GOLEM, 2, 20, 6, EnumParticleTypes.SMOKE_LARGE, oLaunch(4, 1.1), oBurst(4, 12, 1)),
        R("gol3", GOLEM, 3, 30, 6, EnumParticleTypes.CRIT, oBuff(MobEffects.RESISTANCE, 2, 300), oBuff(MobEffects.ABSORPTION, 4, 300)),
        R("gol4", GOLEM, 4, 45, 6, EnumParticleTypes.SMOKE_LARGE, oLeap(0.7, 0.3, 6, 35), oDebuff(6, MobEffects.SLOWNESS, 3, 80)),
        R("gol5", GOLEM, 5, 60, 6, EnumParticleTypes.CLOUD, oBurst(5, 20, 3.5), oBuff(MobEffects.RESISTANCE, 3, 100)),
        R("gol6", GOLEM, 6, 75, 5, EnumParticleTypes.HEART, oHeal(20), oBuff(MobEffects.REGENERATION, 2, 200)),
        R("gol7", GOLEM, 7, 110, 6, EnumParticleTypes.CRIT, oVfx(14, 500), oBuff(MobEffects.STRENGTH, 2, 500), oBuff(MobEffects.RESISTANCE, 2, 500), oBuff(MobEffects.REGENERATION, 1, 500)),
        R("gol8", GOLEM, 8, 130, 6, EnumParticleTypes.SMOKE_LARGE, oPull(10, 1.4), oBurst(3, 35, 2)),
        R("gol9", GOLEM, 9, 175, 6, EnumParticleTypes.EXPLOSION_LARGE, oBurst(10, 90, 3), oLaunch(10, 0.9), oDebuff(10, MobEffects.SLOWNESS, 3, 100), oCombo(6, 25, 3, 8)),
        // วอร์เดน (บอส)
        R("war1", WARDEN, 1, 12, 2, EnumParticleTypes.SMOKE_LARGE, oDebuff(10, MobEffects.BLINDNESS, 0, 100), oDebuff(10, MobEffects.WEAKNESS, 1, 100)),
        R("war2", WARDEN, 2, 20, 2, EnumParticleTypes.CRIT_MAGIC, oCone(14, 1.2, 45, 2.5)),
        R("war3", WARDEN, 3, 30, 2, EnumParticleTypes.CRIT_MAGIC, oDebuff(20, MobEffects.GLOWING, 0, 300), oBuff(MobEffects.NIGHT_VISION, 0, 300), oBuff(MobEffects.SPEED, 1, 300)),
        R("war4", WARDEN, 4, 45, 2, EnumParticleTypes.SMOKE_LARGE, oField(6, 10, 10, 100).eff(MobEffects.SLOWNESS, 5, 40)),
        R("war5", WARDEN, 5, 60, 2, EnumParticleTypes.SMOKE_LARGE, oLeap(0.8, 0.6, 5, 45)),
        R("war6", WARDEN, 6, 75, 2, EnumParticleTypes.CLOUD, oInv(40), oBuff(MobEffects.INVISIBILITY, 0, 200), oTp(6)),
        R("war7", WARDEN, 7, 110, 2, EnumParticleTypes.CRIT_MAGIC, oVfx(14, 500), oBuff(MobEffects.STRENGTH, 2, 500), oBuff(MobEffects.RESISTANCE, 2, 500), oBuff(MobEffects.NIGHT_VISION, 0, 500)),
        R("war8", WARDEN, 8, 130, 2, EnumParticleTypes.SMOKE_LARGE, oBurst(10, 35, 2.5).eff(MobEffects.WEAKNESS, 2, 200), oDebuff(10, MobEffects.BLINDNESS, 0, 100)),
        R("war9", WARDEN, 9, 175, 2, EnumParticleTypes.CRIT_MAGIC, oVolley(18, 1.8, 60, 3, 12), oBurst(5, 40, 3)),
        // เอนเดอร์ดราก้อน (บอส)
        R("dra1", DRAGON, 1, 15, 4, EnumParticleTypes.DRAGON_BREATH, oStream(6, 1.6, 6, 40, 2).eff(MobEffects.WITHER, 0, 60)),
        R("dra2", DRAGON, 2, 22, 4, EnumParticleTypes.CLOUD, oBurst(5, 25, 3)),
        R("dra3", DRAGON, 3, 32, 4, EnumParticleTypes.CLOUD, oBurst(8, 10, 3.5), oLaunch(8, 0.7)),
        R("dra4", DRAGON, 4, 48, 4, EnumParticleTypes.DRAGON_BREATH, oFireball(5, 50)),
        R("dra5", DRAGON, 5, 60, 4, EnumParticleTypes.PORTAL, oBuff(MobEffects.RESISTANCE, 3, 300), oBuff(MobEffects.ABSORPTION, 4, 300)),
        R("dra6", DRAGON, 6, 80, 4, EnumParticleTypes.PORTAL, oFirestorm(6, 16, 100)),
        R("dra7", DRAGON, 7, 115, 4, EnumParticleTypes.PORTAL, oVfx(14, 500), oBuff(MobEffects.STRENGTH, 2, 500), oBuff(MobEffects.SPEED, 1, 500), oBuff(MobEffects.RESISTANCE, 1, 500)),
        R("dra8", DRAGON, 8, 130, 4, EnumParticleTypes.PORTAL, oTp(14), oBurst(6, 40, 2)),
        R("dra9", DRAGON, 9, 180, 4, EnumParticleTypes.DRAGON_BREATH, oMeteors(14, 20, 45, 90, 12, 1, 0), oBolts(3, 14, 35)),
        // หงส์อัคคี (สายสัตว์)
        R("phx1", PHOENIX, 1, 15, 3, EnumParticleTypes.FLAME, oStream(6, 1.6, 6, 40, 2).ig(3)),
        R("phx2", PHOENIX, 2, 25, 3, EnumParticleTypes.FLAME, oFireball(5, 45)),
        R("phx3", PHOENIX, 3, 60, 3, EnumParticleTypes.FLAME, oWings(1200)),
        R("phx4", PHOENIX, 4, 50, 3, EnumParticleTypes.FLAME, oPillar(7, 2.2, 8, 120).ig(4)),
        R("phx5", PHOENIX, 5, 80, 3, EnumParticleTypes.FLAME, oMeteors(12, 16, 40, 80, 12, 1, 0).ig(5)),
        R("phx6", PHOENIX, 6, 90, 3, EnumParticleTypes.FLAME, oFirestorm(5, 14, 100).ig(4)),
        R("phx7", PHOENIX, 7, 120, 3, EnumParticleTypes.FLAME, oVfx(14, 500), oBuff(MobEffects.FIRE_RESISTANCE, 0, 500), oBuff(MobEffects.STRENGTH, 2, 500), oBuff(MobEffects.SPEED, 1, 500), oBuff(MobEffects.REGENERATION, 1, 500)),
        R("phx8", PHOENIX, 8, 130, 3, EnumParticleTypes.FLAME, oField(5, 14, 5, 80).ig(4)),
        R("phx9", PHOENIX, 9, 180, 3, EnumParticleTypes.FLAME, oPhoenix(10, 14, 80).ig(5)),
        // กระต่ายอรชร (สายสัตว์)
        R("rabbit1", RABBIT, 1, 12, 1, EnumParticleTypes.CRIT_MAGIC, oLunge(8, 24)),
        R("rabbit2", RABBIT, 2, 20, 1, EnumParticleTypes.HEART, oBurst(8, 4, 0).eff(MobEffects.SLOWNESS, 6, 100), oDebuff(8, MobEffects.WEAKNESS, 1, 100)),
        R("rabbit3", RABBIT, 3, 30, 1, EnumParticleTypes.END_ROD, oTp(10)),
        R("rabbit4", RABBIT, 4, 40, 0, EnumParticleTypes.END_ROD, oInv(100), oBuff(MobEffects.RESISTANCE, 4, 100), oVfx(6, 100)),
        R("rabbit5", RABBIT, 5, 55, 1, EnumParticleTypes.HEART, oChain(4, 10, 14).eff(MobEffects.SLOWNESS, 6, 100)),
        R("rabbit6", RABBIT, 6, 70, 6, EnumParticleTypes.CLOUD, oBuff(MobEffects.INVISIBILITY, 0, 200), oBuff(MobEffects.SPEED, 3, 200), oInv(30)),
        // ---- ขวาน ----
        R("axe1", AXE, 1, 10, 3, EnumParticleTypes.CRIT, oCone(4, 1.8, 10, 0.8)),
        R("axe2", AXE, 2, 16, 3, EnumParticleTypes.CRIT, oOrbit(2.2, 5, 40, 5)),
        R("axe3", AXE, 3, 24, 3, EnumParticleTypes.CRIT, oLeap(0.8, 0.7, 4, 22)),
        R("axe4", AXE, 4, 34, 3, EnumParticleTypes.CRIT, oBuff(MobEffects.STRENGTH, 1, 300), oBuff(MobEffects.SPEED, 0, 300), oSelf(4)),
        R("axe5", AXE, 5, 48, 3, EnumParticleTypes.CRIT, oCone(5, 2.0, 34, 1.0), oDebuff(6, MobEffects.WEAKNESS, 1, 200)),
        R("axe6", AXE, 6, 66, 3, EnumParticleTypes.CRIT, oOrbit(3.2, 9, 80, 4)),
        R("axe7", AXE, 7, 90, 3, EnumParticleTypes.CRIT, oBolts(4, 12, 45)),
        R("axe8", AXE, 8, 120, 3, EnumParticleTypes.CRIT, oCombo(5, 18, 6, 5)),
        R("axe9", AXE, 9, 160, 3, EnumParticleTypes.CRIT, oLeap(1.1, 0.5, 9, 85), oDebuff(9, MobEffects.SLOWNESS, 2, 100)),
        // ---- ที่ขุด ----
        R("pick1", PICK, 1, 9, 2, EnumParticleTypes.CRIT, oCone(5, 0.9, 10, 0.5)),
        R("pick2", PICK, 2, 15, 2, EnumParticleTypes.CRIT, oDash(6, 16)),
        R("pick3", PICK, 3, 22, 2, EnumParticleTypes.CRIT, oBuff(MobEffects.HASTE, 2, 600), oBuff(MobEffects.NIGHT_VISION, 0, 600)),
        R("pick4", PICK, 4, 32, 2, EnumParticleTypes.EXPLOSION_LARGE, oBurst(5, 28, 1.8)),
        R("pick5", PICK, 5, 44, 2, EnumParticleTypes.CRIT, oCone(10, 1.2, 34, 1.5)),
        R("pick6", PICK, 6, 60, 2, EnumParticleTypes.CRIT, oBuff(MobEffects.RESISTANCE, 2, 300), oBuff(MobEffects.ABSORPTION, 3, 300)),
        R("pick7", PICK, 7, 82, 2, EnumParticleTypes.SMOKE_LARGE, oField(6, 14, 10, 80), oDebuff(6, MobEffects.SLOWNESS, 2, 100)),
        R("pick8", PICK, 8, 110, 2, EnumParticleTypes.CRIT, oDebuff(20, MobEffects.GLOWING, 0, 300), oBuff(MobEffects.SPEED, 2, 300), oChain(5, 14, 40)),
        R("pick9", PICK, 9, 150, 2, EnumParticleTypes.SMOKE_LARGE, oLaunch(9, 1.0), oBurst(9, 60, 0.5), oDebuff(9, MobEffects.SLOWNESS, 2, 100)),
        // ---- พลั่ว ----
        R("shov1", SHOVEL, 1, 8, 0, EnumParticleTypes.SMOKE_LARGE, oBurst(3, 6, 0.5).eff(MobEffects.SLOWNESS, 1, 60)),
        R("shov2", SHOVEL, 2, 14, 0, EnumParticleTypes.SMOKE_LARGE, oBurst(4, 10, 0).eff(MobEffects.SLOWNESS, 5, 60)),
        R("shov3", SHOVEL, 3, 22, 0, EnumParticleTypes.CRIT, oCone(4, 1.6, 18, 2.0)),
        R("shov4", SHOVEL, 4, 32, 0, EnumParticleTypes.SMOKE_LARGE, oField(4, 8, 10, 100).eff(MobEffects.SLOWNESS, 4, 40)),
        R("shov5", SHOVEL, 5, 46, 0, EnumParticleTypes.CLOUD, oField(6, 10, 5, 80).eff(MobEffects.BLINDNESS, 0, 40)),
        R("shov6", SHOVEL, 6, 60, 0, EnumParticleTypes.SMOKE_LARGE, oInv(30), oTp(6)),
        R("shov7", SHOVEL, 7, 84, 0, EnumParticleTypes.SMOKE_LARGE, oBuff(MobEffects.RESISTANCE, 3, 200), oBuff(MobEffects.ABSORPTION, 3, 300), oBurst(3, 12, 3)),
        R("shov8", SHOVEL, 8, 110, 0, EnumParticleTypes.PORTAL, oPull(8, 1.4), oDebuff(8, MobEffects.SLOWNESS, 5, 100), oBurst(2.5, 40, 0)),
        R("shov9", SHOVEL, 9, 150, 0, EnumParticleTypes.SMOKE_LARGE, oField(9, 22, 5, 100).eff(MobEffects.SLOWNESS, 6, 40)),
        // ---- จอบ ----
        R("hoe1", HOE, 1, 8, 5, EnumParticleTypes.VILLAGER_HAPPY, oCone(4, 2.0, 8, 1.0)),
        R("hoe2", HOE, 2, 14, 5, EnumParticleTypes.HEART, oHeal(6), oBuff(MobEffects.REGENERATION, 1, 200)),
        R("hoe3", HOE, 3, 22, 5, EnumParticleTypes.CRIT, oBurst(5, 16, 1.0)),
        R("hoe4", HOE, 4, 30, 5, EnumParticleTypes.VILLAGER_HAPPY, oBuff(MobEffects.SPEED, 1, 300), oBuff(MobEffects.REGENERATION, 0, 300)),
        R("hoe5", HOE, 5, 44, 5, EnumParticleTypes.SLIME, oField(6, 6, 5, 100).eff(MobEffects.POISON, 1, 60)),
        R("hoe6", HOE, 6, 62, 5, EnumParticleTypes.HEART, oHeal(12), oBuff(MobEffects.ABSORPTION, 3, 400), oBuff(MobEffects.REGENERATION, 1, 300)),
        R("hoe7", HOE, 7, 86, 5, EnumParticleTypes.CRIT, oCone(8, 3, 36, 1.0), oHeal(6)),
        R("hoe8", HOE, 8, 112, 5, EnumParticleTypes.SLIME, oDebuff(10, MobEffects.WEAKNESS, 2, 200), oDebuff(10, MobEffects.HUNGER, 2, 200), oBurst(10, 20, 0)),
        R("hoe9", HOE, 9, 150, 5, EnumParticleTypes.HEART, oBurst(9, 50, 0.5), oHeal(20), oBuff(MobEffects.STRENGTH, 1, 300)),
        // ---- ซอมบี้ ----
        R("zom1", ZOMBIE, 1, 10, 5, EnumParticleTypes.SLIME, oBurst(3, 12, 1.2)),
        R("zom2", ZOMBIE, 2, 18, 5, EnumParticleTypes.HEART, oHeal(8), oBuff(MobEffects.REGENERATION, 1, 160)),
        R("zom3", ZOMBIE, 3, 26, 5, EnumParticleTypes.SLIME, oBurst(5, 8, 0).eff(MobEffects.POISON, 1, 100), oDebuff(5, MobEffects.HUNGER, 1, 100)),
        R("zom4", ZOMBIE, 4, 36, 5, EnumParticleTypes.SLIME, oField(6, 7, 10, 120).eff(MobEffects.SLOWNESS, 1, 40)),
        R("zom5", ZOMBIE, 5, 50, 5, EnumParticleTypes.SLIME, oDash(5, 28), oHeal(6)),
        R("zom6", ZOMBIE, 6, 68, 5, EnumParticleTypes.SLIME, oBurst(7, 38, 2.0), oDebuff(7, MobEffects.WEAKNESS, 1, 200)),
        R("zom7", ZOMBIE, 7, 100, 5, EnumParticleTypes.SLIME, oVfx(14, 500), oBuff(MobEffects.STRENGTH, 2, 500), oBuff(MobEffects.RESISTANCE, 2, 500), oBuff(MobEffects.REGENERATION, 1, 500)),
        R("zom8", ZOMBIE, 8, 120, 5, EnumParticleTypes.SLIME, oField(9, 12, 10, 200).eff(MobEffects.POISON, 2, 60), oDebuff(9, MobEffects.WEAKNESS, 2, 200)),
        R("zom9", ZOMBIE, 9, 160, 5, EnumParticleTypes.SLIME, oBurst(9, 55, 2), oPull(9, 0.8), oBuff(MobEffects.STRENGTH, 2, 400), oHeal(30)),
        // ---- โครงกระดูก ----
        R("ske1", SKELETON, 1, 10, 6, EnumParticleTypes.CRIT, oCone(12, 0.9, 12, 0.6)),
        R("ske2", SKELETON, 2, 18, 6, EnumParticleTypes.CRIT, oField(8, 9, 5, 60)),
        R("ske3", SKELETON, 3, 24, 6, EnumParticleTypes.CRIT, oBuff(MobEffects.RESISTANCE, 1, 200), oBuff(MobEffects.ABSORPTION, 1, 300)),
        R("ske4", SKELETON, 4, 34, 6, EnumParticleTypes.CRIT, oVolley(14, 1.0, 10, 5, 4)),
        R("ske5", SKELETON, 5, 48, 6, EnumParticleTypes.CRIT, oCone(10, 1.2, 38, 1.0).eff(MobEffects.SLOWNESS, 2, 60)),
        R("ske6", SKELETON, 6, 66, 6, EnumParticleTypes.CRIT, oOrbit(3, 12, 100, 5)),
        R("ske7", SKELETON, 7, 100, 6, EnumParticleTypes.CRIT, oVfx(14, 500), oBuff(MobEffects.SPEED, 2, 500), oBuff(MobEffects.STRENGTH, 1, 500), oBuff(MobEffects.RESISTANCE, 1, 500)),
        R("ske8", SKELETON, 8, 120, 6, EnumParticleTypes.CRIT, oOrbit(4, 18, 120, 4), oPull(6, 0.5)),
        R("ske9", SKELETON, 9, 160, 6, EnumParticleTypes.CRIT, oVolley(16, 1.6, 30, 8, 4), oBuff(MobEffects.STRENGTH, 1, 200)),
        // ---- ครีปเปอร์ ----
        R("cre1", CREEPER, 1, 12, 5, EnumParticleTypes.SMOKE_LARGE, oBurst(3, 12, 1.5)),
        R("cre2", CREEPER, 2, 20, 5, EnumParticleTypes.SMOKE_LARGE, oDelay(5, 24, 30)),
        R("cre3", CREEPER, 3, 28, 5, EnumParticleTypes.CLOUD, oDebuff(7, MobEffects.SLOWNESS, 2, 60), oBurst(7, 18, 3)),
        R("cre4", CREEPER, 4, 38, 5, EnumParticleTypes.EXPLOSION_LARGE, oCone(8, 1.2, 28, 2.0)),
        R("cre5", CREEPER, 5, 52, 5, EnumParticleTypes.SMOKE_LARGE, oMine(4, 40, 300)),
        R("cre6", CREEPER, 6, 70, 5, EnumParticleTypes.SPELL_WITCH, oBolts(3, 12, 30)),
        R("cre7", CREEPER, 7, 100, 5, EnumParticleTypes.SMOKE_LARGE, oVfx(14, 500), oBuff(MobEffects.STRENGTH, 3, 500), oBuff(MobEffects.SPEED, 1, 500), oBuff(MobEffects.RESISTANCE, 1, 500)),
        R("cre8", CREEPER, 8, 125, 5, EnumParticleTypes.EXPLOSION_LARGE, oBurst(9, 70, 2.5), oSelf(8)),
        R("cre9", CREEPER, 9, 165, 5, EnumParticleTypes.EXPLOSION_HUGE, oInv(60), oDelay(12, 120, 50)),
        // ---- แมงมุม ----
        R("spi1", SPIDER, 1, 10, 7, EnumParticleTypes.SLIME, oCone(10, 0.9, 6, 0.2).eff(MobEffects.SLOWNESS, 5, 80)),
        R("spi2", SPIDER, 2, 16, 7, EnumParticleTypes.SLIME, oBurst(5, 10, 0).eff(MobEffects.POISON, 1, 120)),
        R("spi3", SPIDER, 3, 24, 7, EnumParticleTypes.CLOUD, oLeap(0.7, 1.0, 3, 18)),
        R("spi4", SPIDER, 4, 34, 7, EnumParticleTypes.SLIME, oField(5, 4, 10, 120).eff(MobEffects.SLOWNESS, 5, 40)),
        R("spi5", SPIDER, 5, 46, 7, EnumParticleTypes.CLOUD, oBuff(MobEffects.JUMP_BOOST, 3, 300), oBuff(MobEffects.SPEED, 1, 300), oBuff(MobEffects.NIGHT_VISION, 0, 300)),
        R("spi6", SPIDER, 6, 64, 7, EnumParticleTypes.SLIME, oChain(4, 8, 20).eff(MobEffects.SLOWNESS, 6, 100)),
        R("spi7", SPIDER, 7, 100, 7, EnumParticleTypes.SLIME, oVfx(14, 500), oBuff(MobEffects.SPEED, 2, 500), oBuff(MobEffects.JUMP_BOOST, 4, 500), oBuff(MobEffects.STRENGTH, 1, 500), oBuff(MobEffects.NIGHT_VISION, 0, 500)),
        R("spi8", SPIDER, 8, 118, 7, EnumParticleTypes.CRIT, oCombo(5, 14, 8, 3)),
        R("spi9", SPIDER, 9, 160, 7, EnumParticleTypes.SLIME, oPull(10, 0.9), oBurst(4, 60, 0).eff(MobEffects.POISON, 3, 200), oDebuff(10, MobEffects.SLOWNESS, 4, 160)),
        // ---- เอนเดอร์แมน ----
        R("end1", ENDER, 1, 14, 4, EnumParticleTypes.PORTAL, oTp(8)),
        R("end2", ENDER, 2, 20, 4, EnumParticleTypes.PORTAL, oBurst(8, 6, 0).eff(MobEffects.BLINDNESS, 0, 80), oDebuff(8, MobEffects.WEAKNESS, 1, 100)),
        R("end3", ENDER, 3, 30, 4, EnumParticleTypes.PORTAL, oField(6, 10, 10, 100).eff(MobEffects.NAUSEA, 0, 100)),
        R("end4", ENDER, 4, 40, 4, EnumParticleTypes.PORTAL, oBehind(14, 3, 16)),
        R("end5", ENDER, 5, 54, 4, EnumParticleTypes.PORTAL, oPull(9, 1.2), oBurst(3, 30, 0)),
        R("end6", ENDER, 6, 72, 4, EnumParticleTypes.PORTAL, oInv(40), oTp(6), oBuff(MobEffects.SPEED, 2, 200)),
        R("end7", ENDER, 7, 110, 4, EnumParticleTypes.PORTAL, oVfx(14, 500), oBuff(MobEffects.SPEED, 3, 500), oBuff(MobEffects.RESISTANCE, 1, 500), oBuff(MobEffects.STRENGTH, 1, 500), oInv(30)),
        R("end8", ENDER, 8, 126, 4, EnumParticleTypes.PORTAL, oTp(16), oBurst(5, 20, 1)),
        R("end9", ENDER, 9, 165, 4, EnumParticleTypes.PORTAL, oBehind(18, 6, 22), oDebuff(10, MobEffects.BLINDNESS, 0, 100)),
        // ---- เบลซ ----
        R("bla1", BLAZE, 1, 12, 3, EnumParticleTypes.FLAME, oCone(10, 0.9, 10, 0.4).ig(4)),
        R("bla2", BLAZE, 2, 20, 3, EnumParticleTypes.FLAME, oBurst(5, 14, 1).ig(5)),
        R("bla3", BLAZE, 3, 30, 3, EnumParticleTypes.FLAME, oOrbit(3, 10, 80, 5).ig(3)),
        R("bla4", BLAZE, 4, 40, 3, EnumParticleTypes.FLAME, oBuff(MobEffects.FIRE_RESISTANCE, 0, 600), oBurst(3, 14, 1.5).ig(4)),
        R("bla5", BLAZE, 5, 54, 3, EnumParticleTypes.FLAME, oVolley(12, 1.3, 16, 3, 5).ig(4)),
        R("bla6", BLAZE, 6, 72, 3, EnumParticleTypes.FLAME, oField(6, 12, 5, 100).ig(5)),
        R("bla7", BLAZE, 7, 100, 3, EnumParticleTypes.FLAME, oVfx(14, 500), oBuff(MobEffects.FIRE_RESISTANCE, 0, 500), oBuff(MobEffects.STRENGTH, 2, 500), oBuff(MobEffects.SPEED, 1, 500)),
        R("bla8", BLAZE, 8, 128, 3, EnumParticleTypes.FLAME, oChain(5, 8, 26).ig(8)),
        R("bla9", BLAZE, 9, 165, 3, EnumParticleTypes.FLAME, oBurst(10, 60, 1.5).ig(10), oField(8, 15, 5, 100).ig(5)),
        // ---- เพิ่มทักษะพยัคฆ์ขาว/กระต่าย ----
        R("tiger7", TIGER, 7, 120, 0, EnumParticleTypes.FIREWORKS_SPARK, oVfx(14, 500), oBuff(MobEffects.STRENGTH, 2, 500), oBuff(MobEffects.SPEED, 2, 500), oBuff(MobEffects.RESISTANCE, 1, 500), oBuff(MobEffects.JUMP_BOOST, 1, 500)),
        R("tiger8", TIGER, 8, 140, 0, EnumParticleTypes.FIREWORKS_SPARK, oNeedles(9, 55)),
        R("tiger9", TIGER, 9, 180, 0, EnumParticleTypes.FIREWORKS_SPARK, oBurst(12, 80, 3).eff(MobEffects.SLOWNESS, 6, 60), oBolts(4, 14, 30), oCombo(6, 25, 3, 8)),
        R("rabbit7", RABBIT, 7, 120, 1, EnumParticleTypes.END_ROD, oVfx(14, 500), oBuff(MobEffects.SPEED, 4, 500), oBuff(MobEffects.JUMP_BOOST, 3, 500), oBuff(MobEffects.REGENERATION, 1, 500), oBuff(MobEffects.STRENGTH, 1, 500)),
        R("rabbit8", RABBIT, 8, 130, 1, EnumParticleTypes.END_ROD, oClones(4, 12, 18, 5)),
        R("rabbit9", RABBIT, 9, 175, 1, EnumParticleTypes.END_ROD, oSkyBall(12, 120, 50))
    };

    public static boolean available(int soul, int rings, int idx) {
        if (idx < 0 || idx >= ALL.length) return false;
        Skill s = ALL[idx];
        return (soul & s.mask) != 0 && rings >= s.ring;
    }

    public static int next(int soul, int rings, int from) {
        for (int i = 1; i <= ALL.length; i++) {
            int j = (from + i + ALL.length) % ALL.length;
            if (available(soul, rings, j)) return j;
        }
        return -1;
    }

    private static void msg(EntityPlayerMP p, String key) {
        p.sendStatusMessage(Tr.c(key), true);
    }

    public static void cycle(EntityPlayerMP p) {
        int n = next(SoulData.getSoul(p), SoulData.getRings(p), SoulData.getSelected(p));
        if (n < 0) { msg(p, "msg.soulland.noskill"); return; }
        SoulData.setSelected(p, n);
        SoulData.sync(p);
    }

    public static void toggleRelease(EntityPlayerMP p) {
        if (SoulData.getSoul(p) == 0) { msg(p, "msg.soulland.needawaken"); return; }
        NBTTagCompound t = SoulData.tag(p);
        boolean r = !t.getBoolean("released");
        t.setBoolean("released", r);
        WorldServer ws = (WorldServer) p.world;
        if (r) burst(ws, EnumParticleTypes.END_ROD, p.posX, p.posY + 1.0, p.posZ, 50, 0.6, 0.05);
        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, r ? 1.4F : 0.7F);
        SoulData.syncVisual(p);
        SoulWeapons.refresh(p);
    }

    /** เปิด/ปิดวงแหวนที่ลอยรอบตัว (แยกจากการเปิดวิญญาณยุทธ์) */
    public static void toggleRings(EntityPlayerMP p) {
        if (SoulData.getSoul(p) == 0) { msg(p, "msg.soulland.needawaken"); return; }
        NBTTagCompound t = SoulData.tag(p);
        boolean r = !t.getBoolean("ringsOn");
        t.setBoolean("ringsOn", r);
        WorldServer ws = (WorldServer) p.world;
        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, r ? 1.1F : 0.6F);
        SoulData.syncVisual(p);
    }

    // ---------- ตัวช่วยเอฟเฟกต์ ----------
    private static List<EntityLivingBase> nearby(EntityPlayerMP p, double r) {
        return p.world.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(r),
                e -> e != p && e instanceof IMob && e.isEntityAlive());
    }

    private static void hit(EntityPlayerMP p, EntityLivingBase e, float dmg) {
        e.hurtResistantTime = 0;
        e.attackEntityFrom(DamageSource.causePlayerDamage(p), dmg);
    }

    private static void push(EntityPlayerMP p, EntityLivingBase e, float str) {
        e.knockBack(p, str, p.posX - e.posX, p.posZ - e.posZ);
    }

    private static void burst(WorldServer ws, EnumParticleTypes t, double x, double y, double z, int n, double spread, double speed) {
        ws.spawnParticle(t, x, y, z, n, spread, spread, spread, speed);
    }

    private static void circle(WorldServer ws, EnumParticleTypes t, double x, double y, double z, double r, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * 2 * Math.PI / n;
            ws.spawnParticle(t, x + Math.cos(a) * r, y, z + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
        }
    }

    /** วงคลื่นกระจายหลายชั้นบนพื้น */
    private static void waves(WorldServer ws, EnumParticleTypes t, EntityPlayerMP p, double max, double step) {
        for (double r = step; r <= max; r += step) circle(ws, t, p.posX, p.posY + 0.15, p.posZ, r, (int) (r * 9) + 8);
    }

    private static void spiral(WorldServer ws, EnumParticleTypes t, EntityPlayerMP p, double r, double h, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * 0.45;
            ws.spawnParticle(t, p.posX + Math.cos(a) * r, p.posY + h * i / n, p.posZ + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
        }
    }

    private static void bolt(WorldServer ws, double x, double y, double z) {
        ws.addWeatherEffect(new EntityLightningBolt(ws, x, y, z, true));
    }

    private static void fx(WorldServer ws, int type, double x, double y, double z, double x2, double y2, double z2, int dur, int ent) {
        NetworkHandler.CHANNEL.sendToAllAround(new PacketFx(type, x, y, z, x2, y2, z2, dur, ent),
                new NetworkRegistry.TargetPoint(ws.provider.getDimension(), x2 != 0 || y2 != 0 ? (x + x2) / 2 : x, y, z, 80));
    }

    private static void fxAt(WorldServer ws, EntityPlayerMP p, int type, double x, double y, double z, double x2, double y2, double z2, int dur, int ent) {
        NetworkHandler.CHANNEL.sendToAllAround(new PacketFx(type, x, y, z, x2, y2, z2, dur, ent),
                new NetworkRegistry.TargetPoint(ws.provider.getDimension(), p.posX, p.posY, p.posZ, 96));
    }

    public static void fxP(WorldServer ws, EntityPlayerMP p, int type, double x, double y, double z, double x2, double y2, double z2, int dur, int ent, int pal) {
        NetworkHandler.CHANNEL.sendToAllAround(new PacketFx(type, x, y, z, x2, y2, z2, dur, ent, pal),
                new NetworkRegistry.TargetPoint(ws.provider.getDimension(), p.posX, p.posY, p.posZ, 96));
    }

    private static Vec3d handPos(EntityPlayerMP p) {
        double yaw = Math.toRadians(p.rotationYaw);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        return new Vec3d(p.posX - fz * 0.45 + fx * 0.5, p.posY + 1.05, p.posZ + fx * 0.45 + fz * 0.5);
    }

    private static List<EntityLivingBase> nearestEnemies(EntityPlayerMP p, double r) {
        List<EntityLivingBase> l = nearby(p, r);
        l.sort((a, b) -> Double.compare(a.getDistanceSq(p), b.getDistanceSq(p)));
        return l;
    }

    // ---------- ใช้สกิล ----------
    public static void cast(EntityPlayerMP p) {
        int soul = SoulData.getSoul(p), rings = SoulData.getRings(p), idx = SoulData.getSelected(p);
        if (soul == 0) return;
        if (!available(soul, rings, idx)) { msg(p, "msg.soulland.noskill"); return; }
        Skill s = ALL[idx];
        long now = p.world.getTotalWorldTime();
        NBTTagCompound t = SoulData.tag(p);
        if (now < t.getLong("cd")) return;
        int mana = SoulData.getMana(p);
        if (mana < s.cost) { msg(p, "msg.soulland.nomana"); return; }
        SoulData.setMana(p, mana - s.cost);
        t.setLong("cd", now + 15);

        float mult = p.getHeldItemMainhand().getItem() == ModItems.HAMMER ? 1.5F : 1.0F;
        WorldServer ws = (WorldServer) p.world;
        double px = p.posX, py = p.posY, pz = p.posZ;
        // วงแหวนที่ใช้ปรากฏชั่วครู่แล้วจางหาย
        int[] trs = SoulData.getTiers(p);
        int ri = s.ring - 1;
        fxP(ws, p, 15, 0, 0, 0, ri, 0, 0, 34, p.getEntityId(), ri >= 0 && ri < trs.length ? trs[ri] : 0);
        ws.playSound(null, px, py, pz, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.8F, 0.6F);

        switch (s.key) {
            case "bind": {
                Vec3d h = handPos(p);
                int c = 0;
                for (EntityLivingBase e : nearestEnemies(p, 9)) {
                    if (c++ >= 4) break;
                    hit(p, e, 5);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 6));
                    fxAt(ws, p, 1, h.x, h.y, h.z, 0, 0, 0, 60, e.getEntityId());
                }
                break;
            }
            case "parasite": {
                int c = 0;
                for (EntityLivingBase e : nearestEnemies(p, 10)) {
                    if (c++ >= 3) break;
                    final EntityLivingBase tg = e;
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 6));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 100, 1));
                    fxAt(ws, p, 2, 0, 0, 0, 0, 0, 0, 100, e.getEntityId());
                    Tasks.add(new Tasks.Task(100) {
                        @Override public void tick(int a) {
                            if (a % 10 == 5 && tg.isEntityAlive()) { hit(p, tg, 3); p.heal(1); }
                        }
                    });
                }
                break;
            }
            case "web": {
                Vec3d eye = p.getPositionEyes(1.0F), look = p.getLookVec();
                Vec3d to = eye.add(look.x * 14, look.y * 14, look.z * 14);
                RayTraceResult rt = ws.rayTraceBlocks(eye, to, false, true, false);
                Vec3d end = rt != null ? rt.hitVec : to;
                double best = 1e9;
                for (EntityLivingBase e : nearby(p, 14)) {
                    Vec3d ec = new Vec3d(e.posX, e.posY + e.height / 2, e.posZ);
                    Vec3d rel = ec.subtract(eye);
                    double proj = rel.dotProduct(look);
                    if (proj < 0 || proj > 14) continue;
                    Vec3d perp = rel.subtract(look.x * proj, look.y * proj, look.z * proj);
                    if (perp.length() < 1.3 && proj < best) { best = proj; end = ec; }
                }
                final Vec3d ep = end;
                Vec3d h = handPos(p);
                fxAt(ws, p, 3, h.x, h.y, h.z, ep.x, ep.y, ep.z, 60, -1);
                Tasks.add(new Tasks.Task(10) {
                    @Override public void end() {
                        for (EntityLivingBase e : ws.getEntitiesWithinAABB(EntityLivingBase.class,
                                new AxisAlignedBB(ep.x - 5, ep.y - 5, ep.z - 5, ep.x + 5, ep.y + 5, ep.z + 5),
                                en -> en != p && en instanceof IMob && en.isEntityAlive())) {
                            hit(p, e, 8);
                            e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 80, 6));
                        }
                    }
                });
                break;
            }
            case "cage": {
                List<EntityLivingBase> l = nearestEnemies(p, 12);
                double cx, cy, cz;
                if (!l.isEmpty()) { cx = l.get(0).posX; cy = l.get(0).posY; cz = l.get(0).posZ; }
                else { Vec3d look = p.getLookVec(); cx = px + look.x * 6; cy = py; cz = pz + look.z * 6; }
                final double fcx = cx, fcy = cy, fcz = cz, R = 3.0;
                final List<EntityLivingBase> trapped = new ArrayList<>();
                for (EntityLivingBase e : nearby(p, 20))
                    if (Math.hypot(e.posX - fcx, e.posZ - fcz) <= R + 0.8 && Math.abs(e.posY - fcy) < 4) trapped.add(e);
                fxAt(ws, p, 4, fcx, fcy, fcz, R, 3.5, 0, 100, -1);
                Tasks.add(new Tasks.Task(100) {
                    @Override public void tick(int a) {
                        for (EntityLivingBase tg : trapped) {
                            if (!tg.isEntityAlive()) continue;
                            double dx = tg.posX - fcx, dz = tg.posZ - fcz, d = Math.sqrt(dx * dx + dz * dz);
                            if (d > R - 0.5) { double k = (R - 0.6) / d; tg.setPositionAndUpdate(fcx + dx * k, tg.posY, fcz + dz * k); }
                            tg.motionX *= 0.1; tg.motionZ *= 0.1;
                            if (a % 10 == 0) { tg.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, 6)); hit(p, tg, 2); }
                        }
                    }
                });
                break;
            }
            case "spear": {
                Vec3d eye = p.getPositionEyes(1.0F), look = p.getLookVec();
                Vec3d to = eye.add(look.x * 16, look.y * 16, look.z * 16);
                RayTraceResult rt = ws.rayTraceBlocks(eye, to, false, true, false);
                Vec3d end = rt != null ? rt.hitVec : to;
                double len = end.distanceTo(eye);
                for (EntityLivingBase e : nearby(p, 18)) {
                    Vec3d rel = new Vec3d(e.posX - eye.x, e.posY + e.height / 2 - eye.y, e.posZ - eye.z);
                    double proj = rel.dotProduct(look);
                    if (proj < 0 || proj > len + 0.5) continue;
                    Vec3d perp = rel.subtract(look.x * proj, look.y * proj, look.z * proj);
                    if (perp.length() < 1.4) {
                        hit(p, e, 35); push(p, e, 2.0F);
                        burst(ws, EnumParticleTypes.CRIT_MAGIC, e.posX, e.posY + 1, e.posZ, 20, 0.3, 0.1);
                    }
                }
                Vec3d h = handPos(p);
                fxAt(ws, p, 5, h.x, h.y, h.z, end.x, end.y, end.z, 12, -1);
                break;
            }
            case "void":
                t.setLong("voidUntil", now + 100);
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 100, 1));
                fxAt(ws, p, 6, 0, 0, 0, 0, 0, 0, 100, p.getEntityId());
                break;
            case "trueform":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 400, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 400, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 400, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 400, 0));
                p.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 400, 2));
                fxAt(ws, p, 7, 0, 0, 0, 0, 0, 0, 400, p.getEntityId());
                break;
            case "mirror":
                fxAt(ws, p, 8, 0, 0, 0, 0, 0, 0, 80, p.getEntityId());
                Tasks.add(new Tasks.Task(80) {
                    @Override public void tick(int a) {
                        if (a % 5 != 0 || !p.isEntityAlive()) return;
                        for (EntityLivingBase e : nearby(p, 6)) {
                            hit(p, e, 10);
                            e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, 2));
                        }
                    }
                });
                break;
            case "tianxin": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                final double sx = px + lx * 2, sz = pz + lz * 2, ex = sx + lx * 14, ez = sz + lz * 14, sy = py;
                fxAt(ws, p, 9, sx, sy, sz, ex, sy, ez, 60, -1);
                Tasks.add(new Tasks.Task(60) {
                    @Override public void tick(int a) {
                        if (a % 3 != 0) return;
                        double g = a / 60.0, cx = sx + (ex - sx) * g, cz = sz + (ez - sz) * g;
                        for (EntityLivingBase e : ws.getEntitiesWithinAABB(EntityLivingBase.class,
                                new AxisAlignedBB(cx - 4, sy - 1, cz - 4, cx + 4, sy + 5, cz + 4),
                                en -> en != p && en instanceof IMob && en.isEntityAlive())) {
                            hit(p, e, 12);
                            e.motionY = 0.5; e.motionX += (cx - e.posX) * 0.2; e.motionZ += (cz - e.posZ) * 0.2;
                            e.velocityChanged = true;
                            e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, 1));
                        }
                    }
                });
                break;
            }
            case "smash":
                for (EntityLivingBase e : nearby(p, 4)) { hit(p, e, 8 * mult); push(p, e, 1.5F); }
                waves(ws, EnumParticleTypes.CLOUD, p, 4, 1.0);
                burst(ws, EnumParticleTypes.EXPLOSION_LARGE, px, py + 0.3, pz, 4, 1.2, 0.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6F, 1.2F);
                break;
            case "rage":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 600, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 600, 0));
                spiral(ws, EnumParticleTypes.FLAME, p, 0.8, 2.2, 60);
                break;
            case "quake":
                for (EntityLivingBase e : nearby(p, 6)) {
                    hit(p, e, 14 * mult);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 1));
                    e.motionY = 0.6; e.velocityChanged = true;
                }
                waves(ws, EnumParticleTypes.SMOKE_LARGE, p, 6, 1.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 0.7F);
                break;
            case "leap": {
                Vec3d look = p.getLookVec();
                p.motionX = look.x * 1.4; p.motionY = 0.9; p.motionZ = look.z * 1.4;
                p.velocityChanged = true;
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 100, 4));
                waves(ws, EnumParticleTypes.CLOUD, p, 3, 1.0);
                break;
            }
            case "wrath":
                for (EntityLivingBase e : nearby(p, 8)) { hit(p, e, 25 * mult); push(p, e, 2.0F); }
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 200, 2));
                waves(ws, EnumParticleTypes.FLAME, p, 8, 2.0);
                burst(ws, EnumParticleTypes.EXPLOSION_HUGE, px, py + 0.5, pz, 3, 2.0, 0.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.6F);
                break;
            case "thunder": {
                List<EntityLivingBase> l = nearby(p, 14);
                l.sort((a, b) -> Double.compare(a.getDistanceSq(p), b.getDistanceSq(p)));
                int c = 0;
                for (EntityLivingBase e : l) {
                    if (c++ >= 6) break;
                    bolt(ws, e.posX, e.posY, e.posZ);
                    hit(p, e, 22 * mult);
                    burst(ws, EnumParticleTypes.FLAME, e.posX, e.posY + 1, e.posZ, 30, 0.4, 0.05);
                }
                waves(ws, EnumParticleTypes.CRIT_MAGIC, p, 6, 2.0);
                break;
            }
            case "gravity":
                for (EntityLivingBase e : nearby(p, 10)) {
                    hit(p, e, 8 * mult);
                    Vec3d d = new Vec3d(px - e.posX, py - e.posY, pz - e.posZ).normalize();
                    e.motionX += d.x * 1.2; e.motionY += d.y * 0.5 + 0.2; e.motionZ += d.z * 1.2;
                    e.velocityChanged = true;
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 2));
                }
                spiral(ws, EnumParticleTypes.PORTAL, p, 2.5, 3.0, 100);
                waves(ws, EnumParticleTypes.PORTAL, p, 10, 2.5);
                break;
            case "titan":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 400, 3));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 400, 2));
                p.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 400, 4));
                for (EntityLivingBase e : nearby(p, 6)) { hit(p, e, 20 * mult); push(p, e, 2.0F); }
                spiral(ws, EnumParticleTypes.FLAME, p, 1.2, 3.5, 100);
                waves(ws, EnumParticleTypes.CLOUD, p, 6, 1.5);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.5F);
                break;
            case "judgement": {
                List<EntityLivingBase> l = nearby(p, 14);
                int c = 0;
                for (EntityLivingBase e : l) {
                    hit(p, e, 60 * mult);
                    push(p, e, 2.5F);
                    if (c++ < 8) bolt(ws, e.posX, e.posY, e.posZ);
                }
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 200, 3));
                waves(ws, EnumParticleTypes.FLAME, p, 14, 2.0);
                burst(ws, EnumParticleTypes.EXPLOSION_HUGE, px, py + 0.5, pz, 5, 3.0, 0.0);
                spiral(ws, EnumParticleTypes.FLAME, p, 2.0, 6.0, 120);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.2F, 0.5F);
                break;
            }
            case "claw": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                for (EntityLivingBase e : nearby(p, 5)) {
                    Vec3d rel = new Vec3d(e.posX - px, 0, e.posZ - pz);
                    if (rel.length() > 5 || rel.length() < 1e-4) continue;
                    if (rel.normalize().dotProduct(new Vec3d(lx, 0, lz)) > 0.4) { hit(p, e, 12); push(p, e, 0.8F); }
                }
                fxP(ws, p, 11, px + lx * 1.6, py + 1.2, pz + lz * 1.6, lx * 2.2, 0, lz * 2.2, 10, -1, 3);
                break;
            }
            case "dash": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                for (EntityLivingBase e : nearby(p, 9)) {
                    double rx = e.posX - px, rz = e.posZ - pz, proj = rx * lx + rz * lz, perp = Math.abs(-rx * lz + rz * lx);
                    if (proj >= 0 && proj <= 7 && perp < 1.6) { hit(p, e, 15); push(p, e, 1.0F); }
                }
                p.motionX = lx * 2.2; p.motionZ = lz * 2.2; p.motionY = 0.1; p.velocityChanged = true;
                fxP(ws, p, 13, px, py + 0.8, pz, px + lx * 7, py + 0.8, pz + lz * 7, 14, -1, 3);
                break;
            }
            case "roar":
                for (EntityLivingBase e : nearby(p, 8)) {
                    hit(p, e, 10); push(p, e, 1.8F);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 1));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 100, 1));
                }
                fxP(ws, p, 12, px, py, pz, 8, 0, 0, 16, -1, 3);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 0.6F);
                break;
            case "pounce": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                p.motionX = lx * 1.1; p.motionY = 0.9; p.motionZ = lz * 1.1; p.velocityChanged = true;
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 40, 4));
                Tasks.add(new Tasks.Task(16) {
                    @Override public void end() {
                        for (EntityLivingBase e : nearby(p, 5)) { hit(p, e, 30); push(p, e, 1.5F); }
                        fxP(ws, p, 12, p.posX, p.posY, p.posZ, 5, 0, 0, 14, -1, 3);
                        burst(ws, EnumParticleTypes.EXPLOSION_LARGE, p.posX, p.posY + 0.3, p.posZ, 3, 1.2, 0.0);
                        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 0.9F);
                    }
                });
                break;
            }
            case "tigerform":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 500, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 500, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 500, 0));
                p.addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST, 500, 1));
                fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, 500, p.getEntityId(), 3);
                break;
            case "tigerwrath": {
                Vec3d look = p.getLookVec();
                double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
                if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
                final double fx = lx, fz = lz;
                Tasks.add(new Tasks.Task(12) {
                    @Override public void tick(int a) {
                        if (a % 4 != 0) return;
                        fxP(ws, p, 11, p.posX + fx * 3.5, p.posY + 1.3, p.posZ + fz * 3.5, fx * 5.5, 0, fz * 5.5, 12, -1, 3);
                        for (EntityLivingBase e : nearby(p, 13)) {
                            double rx = e.posX - p.posX, rz = e.posZ - p.posZ, proj = rx * fx + rz * fz, perp = Math.abs(-rx * fz + rz * fx);
                            if (proj >= 0 && proj <= 12 && perp < 3.5) { hit(p, e, 20); push(p, e, 1.2F); }
                        }
                        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6F, 1.4F);
                    }
                });
                break;
            }
            case "kick": {
                List<EntityLivingBase> l = nearestEnemies(p, 5);
                if (!l.isEmpty()) {
                    EntityLivingBase e = l.get(0);
                    hit(p, e, 12); push(p, e, 1.5F);
                    fxP(ws, p, 13, px, py + 0.9, pz, e.posX, e.posY + 0.9, e.posZ, 10, -1, 1);
                    fxP(ws, p, 11, e.posX, e.posY + 1.0, e.posZ, 1.6, 0, 0, 8, -1, 1);
                }
                break;
            }
            case "blink": {
                Vec3d eye = p.getPositionEyes(1.0F), look = p.getLookVec();
                Vec3d to = eye.add(look.x * 8, look.y * 8, look.z * 8);
                RayTraceResult rt = ws.rayTraceBlocks(eye, to, false, true, false);
                Vec3d dest = rt != null ? rt.hitVec.subtract(look.x * 0.6, look.y * 0.6, look.z * 0.6) : to;
                fxP(ws, p, 13, px, py + 0.8, pz, dest.x, dest.y - p.getEyeHeight() + 0.8, dest.z, 12, -1, 1);
                burst(ws, EnumParticleTypes.END_ROD, px, py + 1, pz, 25, 0.4, 0.05);
                p.setPositionAndUpdate(dest.x, dest.y - p.getEyeHeight(), dest.z);
                burst(ws, EnumParticleTypes.END_ROD, dest.x, dest.y, dest.z, 25, 0.4, 0.05);
                t.setLong("voidUntil", now + 25);
                break;
            }
            case "charm":
                for (EntityLivingBase e : nearby(p, 8)) {
                    hit(p, e, 5);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 2));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 100, 1));
                    e.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 100, 0));
                    burst(ws, EnumParticleTypes.HEART, e.posX, e.posY + 1.5, e.posZ, 5, 0.3, 0.02);
                }
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 100, 1));
                fxP(ws, p, 12, px, py, pz, 8, 0, 0, 16, -1, 1);
                break;
            case "rabbitrun":
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 120, 3));
                p.addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST, 120, 2));
                fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, 120, p.getEntityId(), 1);
                break;
            case "spinkick":
                Tasks.add(new Tasks.Task(20) {
                    @Override public void tick(int a) {
                        if (a % 4 != 0 || !p.isEntityAlive()) return;
                        for (EntityLivingBase e : nearby(p, 5)) { hit(p, e, 9); push(p, e, 1.2F); }
                        fxP(ws, p, 12, p.posX, p.posY, p.posZ, 5, 0, 0, 8, -1, 1);
                    }
                });
                break;
            case "queen": {
                List<EntityLivingBase> l = nearestEnemies(p, 14);
                if (l.isEmpty()) break;
                final EntityLivingBase tg = l.get(0);
                double dx = tg.posX - px, dz = tg.posZ - pz, dl = Math.sqrt(dx * dx + dz * dz);
                if (dl < 1e-4) { dx = 0; dz = 1; dl = 1; }
                fxP(ws, p, 13, px, py + 0.8, pz, tg.posX, tg.posY + 0.8, tg.posZ, 12, -1, 1);
                p.setPositionAndUpdate(tg.posX + dx / dl * 1.5, tg.posY, tg.posZ + dz / dl * 1.5);
                t.setLong("voidUntil", now + 40);
                Tasks.add(new Tasks.Task(30) {
                    @Override public void tick(int a) {
                        if (a % 5 != 0 || !tg.isEntityAlive()) return;
                        hit(p, tg, 16); push(p, tg, 0.5F);
                        double ang = a * 1.3;
                        fxP(ws, p, 11, tg.posX, tg.posY + 1.0, tg.posZ, Math.cos(ang) * 2.2, 0, Math.sin(ang) * 2.2, 8, -1, 1);
                        for (EntityLivingBase e : ws.getEntitiesWithinAABB(EntityLivingBase.class,
                                new AxisAlignedBB(tg.posX - 4, tg.posY - 2, tg.posZ - 4, tg.posX + 4, tg.posY + 3, tg.posZ + 4),
                                en -> en != p && en != tg && en instanceof IMob && en.isEntityAlive())) hit(p, e, 8);
                    }
                });
                break;
            }
            default:
                if (s.ops != null) runOps(p, s, ws, t, now);
                else if (s.kind != K_CUSTOM) castGeneric(p, s, ws, px, py, pz, t, now);
                break;
        }
        SoulData.sync(p);
    }

    // ---------- ทักษะสำเร็จรูป (เครื่องมือ/มอนสเตอร์) ----------
    private static void applyEff(EntityLivingBase e, Skill s) {
        if (s.effect != null) e.addPotionEffect(new PotionEffect(s.effect, s.dur, s.amp));
        if (s.fire > 0) e.setFire(s.fire);
    }

    private static void castGeneric(EntityPlayerMP p, Skill s, WorldServer ws, double px, double py, double pz, NBTTagCompound t, long now) {
        Vec3d look = p.getLookVec();
        double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
        if (ll < 1e-4) { lx = 0; lz = 1; } else { lx /= ll; lz /= ll; }
        float dmg = (float) s.dmg;
        switch (s.kind) {
            case K_BURST:
                for (EntityLivingBase e : nearby(p, s.reach + 1)) {
                    if (e.getDistance(p) > s.reach + e.width) continue;
                    hit(p, e, dmg); push(p, e, 1.0F); applyEff(e, s);
                }
                fxP(ws, p, 12, px, py, pz, s.reach, 0, 0, 14, -1, s.pal);
                burst(ws, s.part, px, py + 0.8, pz, 30, s.reach * 0.35, 0.05);
                if (s.self > 0) p.attackEntityFrom(DamageSource.MAGIC, (float) s.self);
                break;
            case K_LINE:
                for (EntityLivingBase e : nearby(p, s.reach + 3)) {
                    double rx = e.posX - px, rz = e.posZ - pz, proj = rx * lx + rz * lz, perp = Math.abs(-rx * lz + rz * lx);
                    if (proj >= 0 && proj <= s.reach && perp < 1.6) {
                        hit(p, e, dmg); push(p, e, 0.8F); applyEff(e, s);
                        burst(ws, s.part, e.posX, e.posY + 1, e.posZ, 12, 0.3, 0.05);
                    }
                }
                fxP(ws, p, 13, px, py + 1.2, pz, px + lx * s.reach, py + 1.2, pz + lz * s.reach, 10, -1, s.pal);
                break;
            case K_BUFF:
                if (s.effect != null) p.addPotionEffect(new PotionEffect(s.effect, s.dur, s.amp));
                if (s.dmg > 0) p.heal(dmg);
                fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, Math.max(40, Math.min(200, s.dur)), p.getEntityId(), s.pal);
                break;
            case K_DASH:
                for (EntityLivingBase e : nearby(p, s.reach + 2)) {
                    double rx = e.posX - px, rz = e.posZ - pz, proj = rx * lx + rz * lz, perp = Math.abs(-rx * lz + rz * lx);
                    if (proj >= 0 && proj <= s.reach && perp < 1.6) { hit(p, e, dmg); push(p, e, 1.0F); }
                }
                p.motionX = lx * 2.0; p.motionZ = lz * 2.0; p.motionY = 0.25; p.velocityChanged = true;
                fxP(ws, p, 13, px, py + 0.8, pz, px + lx * s.reach, py + 0.8, pz + lz * s.reach, 14, -1, s.pal);
                break;
            case K_TP: {
                Vec3d eye = p.getPositionEyes(1.0F);
                Vec3d to = eye.add(look.x * s.reach, look.y * s.reach, look.z * s.reach);
                RayTraceResult rt = ws.rayTraceBlocks(eye, to, false, true, false);
                Vec3d dest = rt != null ? rt.hitVec.subtract(look.x * 0.6, look.y * 0.6, look.z * 0.6) : to;
                fxP(ws, p, 13, px, py + 0.8, pz, dest.x, dest.y - p.getEyeHeight() + 0.8, dest.z, 12, -1, s.pal);
                burst(ws, s.part, px, py + 1, pz, 25, 0.4, 0.2);
                p.setPositionAndUpdate(dest.x, dest.y - p.getEyeHeight(), dest.z);
                burst(ws, s.part, dest.x, dest.y, dest.z, 25, 0.4, 0.2);
                t.setLong("voidUntil", now + 20);
                break;
            }
            default: break;
        }
    }

    /** เก็บปีกอัคคี: ยกเลิกการบินในโหมดเอาชีวิตรอด */
    public static void revokeWings(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        if (!t.getBoolean("wingsGiven")) return;
        t.setBoolean("wingsGiven", false);
        t.setLong("noFallUntil", p.world.getTotalWorldTime() + 100);
        if (!p.isCreative() && !p.isSpectator()) {
            p.capabilities.allowFlying = false;
            p.capabilities.isFlying = false;
            p.sendPlayerAbilities();
        }
    }

    // ================= เครื่องยนต์ทักษะแบบประกอบ (ทุกทักษะมีส่วนผสมไม่ซ้ำกัน) =================
    public static final class Op {
        final int k;
        final double a, b, c, d;
        int i, amp, dur, fire, flag, sdelay;
        Potion pot;
        Op(int k, double a, double b, double c, double d) { this.k = k; this.a = a; this.b = b; this.c = c; this.d = d; }
        Op eff(Potion p, int amp, int dur) { this.pot = p; this.amp = amp; this.dur = dur; return this; }
        Op ig(int sec) { this.fire = sec; return this; }
    }

    private static final int O_BURST = 1, O_CONE = 2, O_CHAIN = 3, O_BOLTS = 4, O_DASH = 5, O_LEAP = 6, O_TP = 7, O_BEHIND = 8, O_PULL = 9,
            O_LAUNCH = 10, O_DEBUFF = 11, O_BUFF = 12, O_HEAL = 13, O_INV = 14, O_FIELD = 15, O_COMBO = 16, O_SELF = 17, O_ORBIT = 18,
            O_VOLLEY = 19, O_DELAY = 20, O_MINE = 21, O_SCRAMBLE = 22, O_FORM = 23, O_LUNGE = 24, O_CLONES = 25, O_SKYBALL = 26, O_VFX = 27, O_STREAM = 28, O_FIREBALL = 29, O_WINGS = 30, O_PILLAR = 31, O_METEORS = 32, O_FIRESTORM = 33, O_PHOENIX = 34, O_CROSS = 35, O_NEEDLES = 36, O_JUMP = 37;

    private static Skill R(String key, int mask, int ring, int cost, int pal, EnumParticleTypes part, Op... ops) {
        Skill s = new Skill(key, mask, ring, cost);
        s.pal = pal; s.part = part; s.ops = ops;
        return s;
    }
    private static Op oBurst(double r, double dmg, double kb) { return new Op(O_BURST, r, dmg, kb, 0); }
    private static Op oCone(double len, double half, double dmg, double kb) { return new Op(O_CONE, len, half, dmg, kb); }
    private static Op oChain(double n, double range, double dmg) { return new Op(O_CHAIN, n, range, dmg, 0); }
    private static Op oBolts(double n, double range, double dmg) { return new Op(O_BOLTS, n, range, dmg, 0); }
    private static Op oDash(double dist, double dmg) { return new Op(O_DASH, dist, dmg, 0, 0); }
    private static Op oLeap(double vy, double fwd, double r, double dmg) { return new Op(O_LEAP, vy, fwd, r, dmg); }
    private static Op oTp(double dist) { return new Op(O_TP, dist, 0, 0, 0); }
    private static Op oBehind(double range, double hits, double dmg) { return new Op(O_BEHIND, range, hits, dmg, 0); }
    private static Op oPull(double r, double str) { return new Op(O_PULL, r, str, 0, 0); }
    private static Op oLaunch(double r, double vy) { return new Op(O_LAUNCH, r, vy, 0, 0); }
    private static Op oDebuff(double r, Potion p, int amp, int dur) { return new Op(O_DEBUFF, r, 0, 0, 0).eff(p, amp, dur); }
    private static Op oBuff(Potion p, int amp, int dur) { return new Op(O_BUFF, 0, 0, 0, 0).eff(p, amp, dur); }
    private static Op oHeal(double hp) { return new Op(O_HEAL, hp, 0, 0, 0); }
    private static Op oInv(double ticks) { return new Op(O_INV, ticks, 0, 0, 0); }
    private static Op oField(double r, double dmg, double interval, double dur) { return new Op(O_FIELD, r, dmg, interval, dur); }
    private static Op oCombo(double r, double dmg, double n, double interval) { return new Op(O_COMBO, r, dmg, n, interval); }
    private static Op oSelf(double dmg) { return new Op(O_SELF, dmg, 0, 0, 0); }
    private static Op oOrbit(double r, double dmg, double dur, double interval) { return new Op(O_ORBIT, r, dmg, dur, interval); }
    private static Op oVolley(double len, double half, double dmg, double n, int interval) { Op o = new Op(O_VOLLEY, len, half, dmg, n); o.i = interval; return o; }
    private static Op oDelay(double r, double dmg, double delay) { return new Op(O_DELAY, r, dmg, delay, 0); }
    private static Op oMine(double r, double dmg, double dur) { return new Op(O_MINE, r, dmg, dur, 0); }
    private static Op oScramble(double r, double dist) { return new Op(O_SCRAMBLE, r, dist, 0, 0); }
    private static Op oForm(double dur) { return new Op(O_FORM, dur, 0, 0, 0); }
    private static Op oLunge(double range, double dmg) { return new Op(O_LUNGE, range, dmg, 0, 0); }
    private static Op oClones(double n, double range, double dmg, double hits) { return new Op(O_CLONES, n, range, dmg, hits); }
    private static Op oSkyBall(double r, double dmg, double delay) { return new Op(O_SKYBALL, r, dmg, delay, 0); }
    private static Op oVfx(int type, int dur) { return new Op(O_VFX, type, dur, 0, 0); }
    private static Op oStream(double len, double half, double dmg, double dur, int interval) { Op o = new Op(O_STREAM, len, half, dmg, dur); o.i = interval; return o; }
    private static Op oFireball(double r, double dmg) { return new Op(O_FIREBALL, 0, r, dmg, 0); }
    private static Op oWings(double dur) { return new Op(O_WINGS, dur, 0, 0, 0); }
    private static Op oPillar(double dist, double r, double dmg, double dur) { return new Op(O_PILLAR, dist, r, dmg, dur); }
    private static Op oMeteors(double r, double count, double dmg, double dur, int delay, int flag, int startDelay) {
        Op o = new Op(O_METEORS, r, count, dmg, dur); o.i = delay; o.flag = flag; o.sdelay = startDelay; return o;
    }
    private static Op oFirestorm(double r, double dmg, double dur) { return new Op(O_FIRESTORM, r, dmg, dur, 0); }
    private static Op oPhoenix(double r, double dmg, double dur) { return new Op(O_PHOENIX, r, dmg, dur, 0); }
    private static Op oCross(double len, double half, double dmg) { return new Op(O_CROSS, len, half, dmg, 0); }
    private static Op oNeedles(double r, double dmg) { return new Op(O_NEEDLES, r, dmg, 0, 0); }
    private static Op oJump(double vy, double fwd) { return new Op(O_JUMP, vy, fwd, 0, 0); }

    private static List<EntityLivingBase> near(EntityPlayerMP p, double r) {
        List<EntityLivingBase> out = new ArrayList<>();
        for (EntityLivingBase e : nearby(p, r + 1)) if (e.getDistance(p) <= r + e.width) out.add(e);
        return out;
    }

    private static List<EntityLivingBase> around(WorldServer ws, EntityPlayerMP p, double x, double y, double z, double r) {
        List<EntityLivingBase> out = new ArrayList<>();
        for (EntityLivingBase e : ws.getEntitiesWithinAABB(EntityLivingBase.class, new AxisAlignedBB(x - r, y - 2, z - r, x + r, y + r, z + r),
                en -> en != p && en instanceof IMob && en.isEntityAlive()))
            if (Math.hypot(e.posX - x, e.posZ - z) <= r + e.width) out.add(e);
        return out;
    }

    private static void app(Op o, EntityLivingBase e) {
        if (o.pot != null) e.addPotionEffect(new PotionEffect(o.pot, o.dur, o.amp));
        if (o.fire > 0) e.setFire(o.fire);
    }

    private static void coneHit(EntityPlayerMP p, WorldServer ws, Skill s, Op o, double lx, double lz, double len, double half, double dmg, double kb) {
        for (EntityLivingBase e : nearby(p, len + 3)) {
            double rx = e.posX - p.posX, rz = e.posZ - p.posZ, proj = rx * lx + rz * lz, perp = Math.abs(-rx * lz + rz * lx);
            if (proj >= -0.5 && proj <= len && perp <= half + e.width * 0.5) {
                hit(p, e, (float) dmg); push(p, e, (float) kb); app(o, e);
                burst(ws, s.part, e.posX, e.posY + 1, e.posZ, 10, 0.3, 0.05);
            }
        }
        if (half < 1.0) fxP(ws, p, 13, p.posX, p.posY + 1.2, p.posZ, p.posX + lx * len, p.posY + 1.2, p.posZ + lz * len, 10, -1, s.pal);
        else fxP(ws, p, 11, p.posX + lx * len * 0.5, p.posY + 1.2, p.posZ + lz * len * 0.5,
                lx * Math.max(2.0, len * 0.5), 0, lz * Math.max(2.0, len * 0.5), 10, -1, s.pal);
    }

    private static void explodeAt(WorldServer ws, EntityPlayerMP p, Skill s, Op o, double cx, double cy, double cz, double r, double dmg) {
        for (EntityLivingBase e : around(ws, p, cx, cy, cz, r)) {
            hit(p, e, (float) dmg);
            e.knockBack(p, 1.5F, p.posX - e.posX, p.posZ - e.posZ);
            app(o, e);
        }
        fxP(ws, p, 16, cx, cy, cz, r, 0, 0, 16, -1, s.pal);
        burst(ws, EnumParticleTypes.EXPLOSION_LARGE, cx, cy + 0.5, cz, 3, r * 0.3, 0.0);
        ws.playSound(null, cx, cy, cz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.9F);
    }

    private static void runOps(final EntityPlayerMP p, final Skill s, final WorldServer ws, final NBTTagCompound t, final long now) {
        Vec3d look = p.getLookVec();
        double l0 = Math.sqrt(look.x * look.x + look.z * look.z);
        final double lx = l0 < 1e-4 ? 0 : look.x / l0, lz = l0 < 1e-4 ? 1 : look.z / l0;
        boolean aura = false;
        for (final Op o : s.ops) {
            switch (o.k) {
                case O_BURST:
                    for (EntityLivingBase e : near(p, o.a)) { hit(p, e, (float) o.b); push(p, e, (float) o.c); app(o, e); }
                    fxP(ws, p, 12, p.posX, p.posY, p.posZ, o.a, 0, 0, 14, -1, s.pal);
                    burst(ws, s.part, p.posX, p.posY + 0.8, p.posZ, 30, o.a * 0.35, 0.05);
                    break;
                case O_CONE:
                    coneHit(p, ws, s, o, lx, lz, o.a, o.b, o.c, o.d);
                    break;
                case O_CHAIN: {
                    List<EntityLivingBase> l = nearestEnemies(p, o.b);
                    if (l.isEmpty()) break;
                    EntityLivingBase cur = l.get(0);
                    Set<EntityLivingBase> done = new HashSet<>();
                    double qx = p.posX, qy = p.posY + 1, qz = p.posZ;
                    for (int i = 0; i < (int) o.a && cur != null; i++) {
                        done.add(cur);
                        hit(p, cur, (float) o.c); app(o, cur);
                        fxP(ws, p, 13, qx, qy, qz, cur.posX, cur.posY + 1, cur.posZ, 8, -1, s.pal);
                        burst(ws, s.part, cur.posX, cur.posY + 1, cur.posZ, 12, 0.3, 0.05);
                        qx = cur.posX; qy = cur.posY + 1; qz = cur.posZ;
                        EntityLivingBase next = null;
                        double best = 36;
                        for (EntityLivingBase e : nearby(p, o.b + 6)) {
                            if (done.contains(e)) continue;
                            double d = e.getDistanceSq(cur);
                            if (d < best) { best = d; next = e; }
                        }
                        cur = next;
                    }
                    break;
                }
                case O_BOLTS: {
                    int c = 0;
                    for (EntityLivingBase e : nearestEnemies(p, o.b)) {
                        if (c++ >= (int) o.a) break;
                        bolt(ws, e.posX, e.posY, e.posZ);
                        hit(p, e, (float) o.c); app(o, e);
                        burst(ws, s.part, e.posX, e.posY + 1, e.posZ, 20, 0.4, 0.05);
                    }
                    break;
                }
                case O_DASH:
                    for (EntityLivingBase e : nearby(p, o.a + 2)) {
                        double rx = e.posX - p.posX, rz = e.posZ - p.posZ, proj = rx * lx + rz * lz, perp = Math.abs(-rx * lz + rz * lx);
                        if (proj >= 0 && proj <= o.a && perp < 1.6) { hit(p, e, (float) o.b); push(p, e, 1.0F); app(o, e); }
                    }
                    p.motionX = lx * 2.2; p.motionZ = lz * 2.2; p.motionY = 0.15; p.velocityChanged = true;
                    fxP(ws, p, 13, p.posX, p.posY + 0.8, p.posZ, p.posX + lx * o.a, p.posY + 0.8, p.posZ + lz * o.a, 14, -1, s.pal);
                    break;
                case O_LEAP:
                    p.motionX = lx * o.b; p.motionZ = lz * o.b; p.motionY = o.a; p.velocityChanged = true;
                    p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 40, 4));
                    Tasks.add(new Tasks.Task(18) {
                        @Override public void end() { explodeAt(ws, p, s, o, p.posX, p.posY, p.posZ, o.c, o.d); }
                    });
                    break;
                case O_TP: {
                    Vec3d eye = p.getPositionEyes(1.0F);
                    Vec3d to = eye.add(look.x * o.a, look.y * o.a, look.z * o.a);
                    RayTraceResult rt = ws.rayTraceBlocks(eye, to, false, true, false);
                    Vec3d dest = rt != null ? rt.hitVec.subtract(look.x * 0.6, look.y * 0.6, look.z * 0.6) : to;
                    fxP(ws, p, 13, p.posX, p.posY + 0.8, p.posZ, dest.x, dest.y - p.getEyeHeight() + 0.8, dest.z, 12, -1, s.pal);
                    burst(ws, s.part, p.posX, p.posY + 1, p.posZ, 25, 0.4, 0.2);
                    p.setPositionAndUpdate(dest.x, dest.y - p.getEyeHeight(), dest.z);
                    burst(ws, s.part, dest.x, dest.y, dest.z, 25, 0.4, 0.2);
                    t.setLong("voidUntil", now + 20);
                    break;
                }
                case O_BEHIND: {
                    List<EntityLivingBase> l = nearestEnemies(p, o.a);
                    if (l.isEmpty()) break;
                    final EntityLivingBase tg = l.get(0);
                    double dx = tg.posX - p.posX, dz = tg.posZ - p.posZ, dl = Math.sqrt(dx * dx + dz * dz);
                    if (dl < 1e-4) { dx = 0; dz = 1; dl = 1; }
                    fxP(ws, p, 13, p.posX, p.posY + 0.8, p.posZ, tg.posX, tg.posY + 0.8, tg.posZ, 12, -1, s.pal);
                    p.setPositionAndUpdate(tg.posX + dx / dl * 1.5, tg.posY, tg.posZ + dz / dl * 1.5);
                    int hits = (int) o.b;
                    t.setLong("voidUntil", now + hits * 4 + 10);
                    Tasks.add(new Tasks.Task(hits * 4) {
                        @Override public void tick(int a) {
                            if (a % 4 != 0 || !tg.isEntityAlive()) return;
                            hit(p, tg, (float) o.c); push(p, tg, 0.5F);
                            double ang = a * 1.3;
                            fxP(ws, p, 11, tg.posX, tg.posY + 1.0, tg.posZ, Math.cos(ang) * 2.2, 0, Math.sin(ang) * 2.2, 8, -1, s.pal);
                        }
                    });
                    break;
                }
                case O_PULL:
                    for (EntityLivingBase e : near(p, o.a)) {
                        Vec3d d = new Vec3d(p.posX - e.posX, p.posY - e.posY, p.posZ - e.posZ).normalize();
                        e.motionX += d.x * o.b; e.motionY += d.y * 0.4 + 0.2; e.motionZ += d.z * o.b; e.velocityChanged = true;
                    }
                    fxP(ws, p, 12, p.posX, p.posY, p.posZ, o.a, 0, 0, 14, -1, s.pal);
                    spiral(ws, s.part, p, 2.0, 3.0, 60);
                    break;
                case O_LAUNCH:
                    for (EntityLivingBase e : near(p, o.a)) { e.motionY = o.b; e.velocityChanged = true; }
                    fxP(ws, p, 12, p.posX, p.posY, p.posZ, o.a, 0, 0, 14, -1, s.pal);
                    break;
                case O_DEBUFF:
                    for (EntityLivingBase e : near(p, o.a)) {
                        app(o, e);
                        burst(ws, s.part, e.posX, e.posY + 1, e.posZ, 8, 0.3, 0.05);
                    }
                    break;
                case O_BUFF:
                    p.addPotionEffect(new PotionEffect(o.pot, o.dur, o.amp));
                    if (!aura) { fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, 160, p.getEntityId(), s.pal); aura = true; }
                    break;
                case O_HEAL:
                    p.heal((float) o.a);
                    burst(ws, EnumParticleTypes.HEART, p.posX, p.posY + 1.5, p.posZ, 6, 0.4, 0.02);
                    if (!aura) { fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, 100, p.getEntityId(), s.pal); aura = true; }
                    break;
                case O_INV:
                    t.setLong("voidUntil", now + (long) o.a);
                    break;
                case O_SELF:
                    if (p.getHealth() > o.a + 1) p.attackEntityFrom(DamageSource.MAGIC, (float) o.a);
                    break;
                case O_FIELD: {
                    final double cx = p.posX, cy = p.posY, cz = p.posZ;
                    final int itv = Math.max(1, (int) o.c);
                    Tasks.add(new Tasks.Task((int) o.d) {
                        @Override public void tick(int a) {
                            if (a % itv == 0) for (EntityLivingBase e : around(ws, p, cx, cy, cz, o.a)) { hit(p, e, (float) o.b); app(o, e); }
                            if (a % Math.max(itv, 10) == 0) {
                                fxP(ws, p, 12, cx, cy, cz, o.a, 0, 0, 10, -1, s.pal);
                                circle(ws, s.part, cx, cy + 0.2, cz, o.a, 24);
                            }
                        }
                    });
                    break;
                }
                case O_COMBO: {
                    final int itv = Math.max(1, (int) o.d);
                    Tasks.add(new Tasks.Task((int) o.c * itv) {
                        @Override public void tick(int a) {
                            if (a % itv != 0) return;
                            for (EntityLivingBase e : near(p, o.a)) { hit(p, e, (float) o.b); push(p, e, 0.3F); app(o, e); }
                            double ang = ws.rand.nextDouble() * 6.283;
                            fxP(ws, p, 11, p.posX + Math.cos(ang) * 1.5, p.posY + 1.2, p.posZ + Math.sin(ang) * 1.5, Math.cos(ang) * 2.2, 0, Math.sin(ang) * 2.2, 8, -1, s.pal);
                            burst(ws, s.part, p.posX, p.posY + 1, p.posZ, 14, o.a * 0.2, 0.05);
                        }
                    });
                    break;
                }
                case O_ORBIT: {
                    final int itv = Math.max(1, (int) o.d);
                    fxP(ws, p, 17, 0, 0, 0, o.a, 0, 0, (int) o.c, p.getEntityId(), s.pal);
                    Tasks.add(new Tasks.Task((int) o.c) {
                        @Override public void tick(int a) {
                            if (a % itv != 0 || !p.isEntityAlive()) return;
                            for (EntityLivingBase e : near(p, o.a + 0.8)) { hit(p, e, (float) o.b); app(o, e); }
                        }
                    });
                    break;
                }
                case O_VOLLEY: {
                    final int itv = Math.max(1, o.i);
                    Tasks.add(new Tasks.Task((int) o.d * itv) {
                        @Override public void tick(int a) {
                            if (a % itv != 0 || !p.isEntityAlive()) return;
                            Vec3d lk = p.getLookVec();
                            double q = Math.sqrt(lk.x * lk.x + lk.z * lk.z);
                            double vx = q < 1e-4 ? 0 : lk.x / q, vz = q < 1e-4 ? 1 : lk.z / q;
                            coneHit(p, ws, s, o, vx, vz, o.a, o.b, o.c, 0.3);
                        }
                    });
                    break;
                }
                case O_DELAY: {
                    final double cx = p.posX, cy = p.posY, cz = p.posZ;
                    Tasks.add(new Tasks.Task((int) o.c) {
                        @Override public void tick(int a) {
                            if (a % 5 == 0) circle(ws, EnumParticleTypes.SMOKE_LARGE, cx, cy + 0.3, cz, o.a * (1 - a / o.c), 20);
                        }
                        @Override public void end() { explodeAt(ws, p, s, o, cx, cy, cz, o.a, o.b); }
                    });
                    break;
                }
                case O_MINE: {
                    final double cx = p.posX, cy = p.posY, cz = p.posZ;
                    final boolean[] boom = {false};
                    Tasks.add(new Tasks.Task((int) o.c) {
                        @Override public void tick(int a) {
                            if (boom[0]) return;
                            if (a % 10 == 0) fxP(ws, p, 12, cx, cy, cz, 1.2, 0, 0, 10, -1, s.pal);
                            if (!around(ws, p, cx, cy, cz, 2.2).isEmpty()) { boom[0] = true; explodeAt(ws, p, s, o, cx, cy, cz, o.a, o.b); }
                        }
                    });
                    break;
                }
                case O_SCRAMBLE:
                    for (EntityLivingBase e : near(p, o.a)) {
                        double dx = (ws.rand.nextDouble() - 0.5) * 2 * o.b, dz = (ws.rand.nextDouble() - 0.5) * 2 * o.b;
                        burst(ws, s.part, e.posX, e.posY + 1, e.posZ, 15, 0.3, 0.2);
                        if (ws.getCollisionBoxes(e, e.getEntityBoundingBox().offset(dx, 0, dz)).isEmpty()) e.setPositionAndUpdate(e.posX + dx, e.posY, e.posZ + dz);
                        burst(ws, s.part, e.posX, e.posY + 1, e.posZ, 15, 0.3, 0.2);
                    }
                    break;
                case O_FORM:
                    fxP(ws, p, 18, 0, 0, 0, s.mask, 0, 0, (int) o.a, p.getEntityId(), s.pal);
                    break;
                case O_LUNGE: {
                    List<EntityLivingBase> l = nearestEnemies(p, o.a);
                    if (l.isEmpty()) break;
                    EntityLivingBase tg = l.get(0);
                    double dx = tg.posX - p.posX, dz = tg.posZ - p.posZ, dl = Math.sqrt(dx * dx + dz * dz);
                    if (dl < 1e-4) { dx = 0; dz = 1; dl = 1; }
                    fxP(ws, p, 13, p.posX, p.posY + 0.8, p.posZ, tg.posX, tg.posY + 0.8, tg.posZ, 10, -1, s.pal);
                    p.setPositionAndUpdate(tg.posX - dx / dl * 1.3, tg.posY, tg.posZ - dz / dl * 1.3);
                    hit(p, tg, (float) o.b); push(p, tg, 1.6F); app(o, tg);
                    fxP(ws, p, 11, tg.posX, tg.posY + 1.0, tg.posZ, dx / dl * 2.0, 0, dz / dl * 2.0, 8, -1, s.pal);
                    burst(ws, s.part, tg.posX, tg.posY + 1, tg.posZ, 20, 0.4, 0.05);
                    break;
                }
                case O_CLONES: {
                    final int hits = (int) o.d;
                    t.setLong("voidUntil", now + hits * 4);
                    Tasks.add(new Tasks.Task(hits * 4) {
                        @Override public void tick(int a) {
                            if (a % 4 != 0 || !p.isEntityAlive()) return;
                            int c = 0;
                            for (EntityLivingBase e : nearestEnemies(p, o.b)) {
                                if (c++ >= (int) o.a) break;
                                double ang = ws.rand.nextDouble() * 6.283;
                                double sx = e.posX + Math.cos(ang) * 2.0, sz = e.posZ + Math.sin(ang) * 2.0;
                                hit(p, e, (float) o.c); push(p, e, 0.4F);
                                fxP(ws, p, 13, sx, e.posY + 0.8, sz, e.posX, e.posY + 0.8, e.posZ, 6, -1, s.pal);
                                fxP(ws, p, 11, e.posX, e.posY + 1.0, e.posZ, Math.cos(ang) * 2.0, 0, Math.sin(ang) * 2.0, 8, -1, s.pal);
                            }
                        }
                    });
                    break;
                }
                case O_SKYBALL: {
                    List<EntityLivingBase> l = nearestEnemies(p, 22);
                    final double cx, cy, cz;
                    if (!l.isEmpty()) { cx = l.get(0).posX; cy = l.get(0).posY; cz = l.get(0).posZ; }
                    else { cx = p.posX + lx * 10; cy = p.posY; cz = p.posZ + lz * 10; }
                    fxP(ws, p, 19, cx, cy, cz, o.a, 0, 0, (int) o.c, -1, s.pal);
                    Tasks.add(new Tasks.Task((int) o.c) {
                        @Override public void end() { explodeAt(ws, p, s, o, cx, cy, cz, o.a, o.b); bolt(ws, cx, cy, cz); }
                    });
                    break;
                }
                case O_VFX:
                    fxP(ws, p, (int) o.a, 0, 0, 0, 0, 0, 0, (int) o.b, p.getEntityId(), s.pal);
                    break;
                case O_STREAM: {
                    final int itv = Math.max(1, o.i);
                    Tasks.add(new Tasks.Task((int) o.d) {
                        @Override public void tick(int a) {
                            if (!p.isEntityAlive()) return;
                            Vec3d lk = p.getLookVec();
                            double q = Math.sqrt(lk.x * lk.x + lk.z * lk.z);
                            double vx = q < 1e-4 ? 0 : lk.x / q, vz = q < 1e-4 ? 1 : lk.z / q;
                            if (a % itv == 0) {
                                for (EntityLivingBase e : nearby(p, o.a + 2)) {
                                    double rx = e.posX - p.posX, rz = e.posZ - p.posZ, proj = rx * vx + rz * vz, perp = Math.abs(-rx * vz + rz * vx);
                                    if (proj >= 0 && proj <= o.a && perp <= o.b + e.width * 0.5) { hit(p, e, (float) o.c); app(o, e); }
                                }
                            }
                            for (int i = 0; i < 8; i++) {
                                double d = ws.rand.nextDouble() * o.a, sp = d / o.a * o.b;
                                ws.spawnParticle(s.part, p.posX + vx * d + (ws.rand.nextDouble() - 0.5) * sp * 2, p.posY + 1.2 + (ws.rand.nextDouble() - 0.5) * sp,
                                        p.posZ + vz * d + (ws.rand.nextDouble() - 0.5) * sp * 2, 1, 0, 0.02, 0, 0.02);
                            }
                        }
                    });
                    break;
                }
                case O_FIREBALL: {
                    final Vec3d lk = look;
                    final double[] pos = {p.posX + lk.x, p.posY + p.getEyeHeight() - 0.2 + lk.y, p.posZ + lk.z};
                    final boolean[] done = {false};
                    Tasks.add(new Tasks.Task(24) {
                        @Override public void tick(int a) {
                            if (done[0]) return;
                            pos[0] += lk.x * 1.2; pos[1] += lk.y * 1.2; pos[2] += lk.z * 1.2;
                            burst(ws, s.part, pos[0], pos[1], pos[2], 8, 0.2, 0.02);
                            burst(ws, EnumParticleTypes.SMOKE_LARGE, pos[0], pos[1], pos[2], 2, 0.1, 0.01);
                            boolean boom = !ws.isAirBlock(new BlockPos(pos[0], pos[1], pos[2])) || !around(ws, p, pos[0], pos[1] - 1, pos[2], 1.5).isEmpty() || a >= 22;
                            if (boom) { done[0] = true; explodeAt(ws, p, s, o, pos[0], pos[1], pos[2], o.b, o.c); }
                        }
                    });
                    break;
                }
                case O_WINGS: {
                    int dur = (int) o.a;
                    p.capabilities.allowFlying = true;
                    p.capabilities.isFlying = true;
                    p.sendPlayerAbilities();
                    p.fallDistance = 0F;
                    t.setBoolean("wingsGiven", true);
                    t.setLong("wingsUntil", now + dur);
                    fxP(ws, p, 21, 0, 0, 0, 0, 0, 0, dur, p.getEntityId(), s.pal);
                    Tasks.add(new Tasks.Task(dur) { @Override public void end() { revokeWings(p); } });
                    break;
                }
                case O_PILLAR: {
                    final double cx = p.posX + lx * o.a, cz = p.posZ + lz * o.a, cy = p.posY;
                    fxP(ws, p, 22, cx, cy, cz, o.b, 7, 0, (int) o.d, -1, s.pal);
                    Tasks.add(new Tasks.Task((int) o.d) {
                        @Override public void tick(int a) {
                            if (a % 4 == 0) for (EntityLivingBase e : around(ws, p, cx, cy, cz, o.b)) {
                                hit(p, e, (float) o.c); app(o, e); e.motionY = 0.25; e.velocityChanged = true;
                            }
                            if (a % 2 == 0) ws.spawnParticle(s.part, cx + (ws.rand.nextDouble() - 0.5) * o.b, cy + ws.rand.nextDouble() * 6, cz + (ws.rand.nextDouble() - 0.5) * o.b, 3, 0.2, 0.3, 0.2, 0.02);
                        }
                    });
                    break;
                }
                case O_METEORS: {
                    final double cx, cy, cz;
                    List<EntityLivingBase> ml = o.flag == 1 ? nearestEnemies(p, 20) : new ArrayList<EntityLivingBase>();
                    if (!ml.isEmpty()) { cx = ml.get(0).posX; cy = ml.get(0).posY; cz = ml.get(0).posZ; }
                    else if (o.flag == 1) { cx = p.posX + lx * 8; cy = p.posY; cz = p.posZ + lz * 8; }
                    else { cx = p.posX; cy = p.posY; cz = p.posZ; }
                    final int every = Math.max(1, (int) (o.d / Math.max(1, o.b))), sd = o.sdelay, dl = o.i;
                    Tasks.add(new Tasks.Task((int) o.d + sd) {
                        @Override public void tick(int a) {
                            if (a < sd || (a - sd) % every != 0) return;
                            double ang = ws.rand.nextDouble() * 6.283, rr = Math.sqrt(ws.rand.nextDouble()) * o.a;
                            final double mx = cx + Math.cos(ang) * rr, mz = cz + Math.sin(ang) * rr;
                            fxP(ws, p, 23, mx, cy, mz, 0, 0, 0, dl, -1, s.pal);
                            Tasks.add(new Tasks.Task(dl) { @Override public void end() { explodeAt(ws, p, s, o, mx, cy, mz, 3.0, o.c); } });
                        }
                    });
                    break;
                }
                case O_FIRESTORM:
                    fxP(ws, p, 17, 0, 0, 0, o.a * 0.6, 0, 0, (int) o.c, p.getEntityId(), s.pal);
                    Tasks.add(new Tasks.Task((int) o.c) {
                        @Override public void tick(int a) {
                            if (!p.isEntityAlive()) return;
                            for (int i = 0; i < 6; i++) {
                                double an = a * 0.4 + i * 1.047, hh = (a * 0.2 + i * 0.5) % 3.0, rr = o.a * (0.4 + 0.6 * hh / 3.0);
                                ws.spawnParticle(s.part, p.posX + Math.cos(an) * rr, p.posY + hh, p.posZ + Math.sin(an) * rr, 1, 0, 0, 0, 0.0);
                            }
                            if (a % 5 == 0) for (EntityLivingBase e : near(p, o.a)) { hit(p, e, (float) o.b); app(o, e); e.motionY = 0.2; e.velocityChanged = true; }
                        }
                    });
                    break;
                case O_PHOENIX:
                    fxP(ws, p, 24, 0, 0, 0, o.a * 0.5, 0, 0, (int) o.c, p.getEntityId(), s.pal);
                    Tasks.add(new Tasks.Task((int) o.c) {
                        @Override public void tick(int a) {
                            if (!p.isEntityAlive()) return;
                            if (a % 5 == 0) for (EntityLivingBase e : near(p, o.a)) { hit(p, e, (float) o.b); push(p, e, 0.5F); app(o, e); }
                            if (a % 2 == 0) burst(ws, s.part, p.posX, p.posY + 1.5, p.posZ, 14, o.a * 0.3, 0.04);
                        }
                        @Override public void end() { explodeAt(ws, p, s, o, p.posX, p.posY, p.posZ, o.a, o.b * 1.5); }
                    });
                    break;
                case O_CROSS: {
                    double[][] dirs = {{lx, lz}, {-lx, -lz}, {-lz, lx}, {lz, -lx}};
                    for (double[] d : dirs) {
                        for (EntityLivingBase e : nearby(p, o.a + 3)) {
                            double rx = e.posX - p.posX, rz = e.posZ - p.posZ, proj = rx * d[0] + rz * d[1], perp = Math.abs(-rx * d[1] + rz * d[0]);
                            if (proj >= -0.3 && proj <= o.a && perp <= o.b + e.width * 0.5) { hit(p, e, (float) o.c); push(p, e, 1.2F); app(o, e); }
                        }
                        fxP(ws, p, 13, p.posX, p.posY + 1.0, p.posZ, p.posX + d[0] * o.a, p.posY + 1.0, p.posZ + d[1] * o.a, 12, -1, s.pal);
                        fxP(ws, p, 11, p.posX + d[0] * o.a * 0.5, p.posY + 1.2, p.posZ + d[1] * o.a * 0.5, d[0] * o.a * 0.5, 0, d[1] * o.a * 0.5, 10, -1, s.pal);
                        for (int k = 1; k <= 8; k++) burst(ws, s.part, p.posX + d[0] * o.a * k / 8.0, p.posY + 1.0, p.posZ + d[1] * o.a * k / 8.0, 6, 0.2, 0.02);
                    }
                    break;
                }
                case O_NEEDLES:
                    for (EntityLivingBase e : near(p, o.a)) { hit(p, e, (float) o.b); push(p, e, 1.0F); app(o, e); }
                    fxP(ws, p, 20, p.posX, p.posY, p.posZ, o.a, 0, 0, 14, -1, s.pal);
                    burst(ws, s.part, p.posX, p.posY + 1, p.posZ, 40, o.a * 0.3, 0.1);
                    break;
                case O_JUMP:
                    p.motionX = lx * o.b; p.motionZ = lz * o.b; p.motionY = o.a; p.velocityChanged = true;
                    t.setLong("noFallUntil", now + 120);
                    burst(ws, s.part, p.posX, p.posY + 0.3, p.posZ, 20, 0.5, 0.05);
                    break;
                default: break;
            }
        }
    }
}

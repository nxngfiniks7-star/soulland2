package com.soulland.mod;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.WorldServer;

/** อนิเมชันปลุก/รีวิญญาณยุทธ์ (3 วินาที) แล้วจึงได้วิญญาณยุทธ์ที่สุ่มไว้ */
public class Awaken {
    public static final int DURATION = 60;

    private static void err(EntityPlayerMP p, String k) { p.sendStatusMessage(Tr.c(k), true); }

    /** 0 ทอง 1 ชมพู 2 ฟ้า 3 ส้ม 4 ม่วง */
    public static int palOf(int soul) {
        switch (soul) {
            case 1: return 0; case 2: return 2; case 3: return 4; case 4: return 3; case 8: return 1;
            case 16: return 3; case 32: return 2; case 64: return 0; case 128: return 6;
            case 256: return 5; case 512: return 6; case 1024: return 5; case 2048: return 7; case 4096: return 4; case 8192: return 3; case 16384: return 3; case 32768: return 6; case 65536: return 2; case 131072: return 4;
            default: return 0;
        }
    }

    public static boolean start(final EntityPlayerMP p, final boolean reroll) {
        final NBTTagCompound t = SoulData.tag(p);
        if (Meditate.active(p)) Meditate.stop(p, false);
        if (t.getBoolean("awOn") || Absorb.active(p)) return false;
        int cur = SoulData.getSoul(p);
        if (!reroll && cur != 0) { err(p, "msg.soulland.already"); return false; }
        if (reroll && cur == 0) { err(p, "msg.soulland.needawaken"); return false; }
        final int soul = SoulData.rollSoul(p.world.rand, reroll ? cur : 0);
        t.setBoolean("awOn", true);
        final WorldServer ws = (WorldServer) p.world;
        SoulSkills.fxP(ws, p, 10, 0, 0, 0, 0, 0, 0, DURATION, p.getEntityId(), palOf(soul));
        Tasks.add(new Tasks.Task(DURATION) {
            @Override public void tick(int a) {
                if (!p.isEntityAlive()) return;
                p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 5, 6, false, false));
                double pr = a / (double) DURATION, r = 1.8 * (1 - pr * 0.8);
                for (int i = 0; i < 3; i++) {
                    double ang = a * 0.3 + i * 2.094;
                    ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX + Math.cos(ang) * r, p.posY + 0.2 + pr * 2.0, p.posZ + Math.sin(ang) * r, 1, 0, 0, 0, 0.0);
                }
                if (a % 15 == 0) ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, 0.5F + (float) pr);
            }
            @Override public void end() {
                t.setBoolean("awOn", false);
                if (!p.isEntityAlive()) return;
                if (!reroll) {
                    SoulData.awaken(p, soul);
                } else {
                    SoulData.setSoul(p, soul);
                    SoulData.setLevel(p, 1 + p.world.rand.nextInt(10));
                    SoulData.setExp(p, 0);
                    SoulData.setRings(p, 0);
                    SoulData.tag(p).setIntArray("tiers", new int[0]);
                    SoulData.applyBonuses(p);
                    SoulData.setMana(p, SoulData.maxMana(p));
                    SoulData.setSelected(p, Math.max(0, SoulSkills.next(soul, SoulData.getRings(p), -1)));
                    SoulData.sync(p);
                }
                t.setBoolean("released", true);
                SoulWeapons.refresh(p);
                SoulData.syncVisual(p);
                p.sendMessage(Tr.c(reroll ? "msg.soulland.reroll" : "msg.soulland.awaken",
                        Tr.c("soul.soulland." + soul)));
                p.sendMessage(Tr.c("msg.soulland.startlevel", String.valueOf(SoulData.getLevel(p))));
                if (soul == 3) p.sendMessage(Tr.c("msg.soulland.twin"));
                ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX, p.posY + 1, p.posZ, 100, 0.7, 1.0, 0.7, 0.2);
                ws.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, p.posX, p.posY + 1, p.posZ, 2, 0.3, 0.3, 0.3, 0.0);
                ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 1.5F);
            }
        });
        return true;
    }

    /** กด N ครั้งแรกเพื่อขอรีวิญญาณยุทธ์ ต้องกด N ซ้ำภายใน 4 วินาทีเพื่อยืนยัน */
    public static void requestReroll(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        if (SoulData.getSoul(p) == 0) { err(p, "msg.soulland.needawaken"); return; }
        long now = p.world.getTotalWorldTime();
        if (now <= t.getLong("rrConfirm")) {
            t.setLong("rrConfirm", 0);
            start(p, true);
        } else {
            t.setLong("rrConfirm", now + 80);
            err(p, "msg.soulland.rerollconfirm");
        }
    }
}

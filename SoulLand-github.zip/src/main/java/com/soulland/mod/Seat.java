package com.soulland.mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayerMP;

/** เก้าอี้ล่องหนให้ตัวละครนั่ง (ตอนดูดซับวงแหวน/นั่งฝึก) */
public class Seat {
    public static int spawn(EntityPlayerMP p) {
        EntityArmorStand seat = new EntityArmorStand(p.world, p.posX, p.posY - 1.3, p.posZ);
        seat.setInvisible(true);
        seat.setNoGravity(true);
        seat.setEntityInvulnerable(true);
        p.world.spawnEntity(seat);
        seat.getEntityData().setBoolean("sl_seat", true);
        p.startRiding(seat, true);
        return seat.getEntityId();
    }

    public static void keep(EntityPlayerMP p, int id) {
        Entity seat = p.world.getEntityByID(id);
        if (seat != null && !seat.isDead && p.getRidingEntity() != seat) p.startRiding(seat, true);
    }

    public static void release(EntityPlayerMP p, int id, double x, double y, double z) {
        Entity seat = p.world.getEntityByID(id);
        p.dismountRidingEntity();
        if (seat != null) seat.setDead();
        p.setPositionAndUpdate(x, y, z);
    }
}

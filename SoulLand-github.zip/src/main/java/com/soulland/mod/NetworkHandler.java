package com.soulland.mod;

import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {
    public static final SimpleNetworkWrapper CHANNEL = NetworkRegistry.INSTANCE.newSimpleChannel("soulland");

    public static void init() {
        CHANNEL.registerMessage(PacketAction.Handler.class, PacketAction.class, 0, Side.SERVER);
        CHANNEL.registerMessage(PacketSync.Handler.class, PacketSync.class, 1, Side.CLIENT);
    }
}

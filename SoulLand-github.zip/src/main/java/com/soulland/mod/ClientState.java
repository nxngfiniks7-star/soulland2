package com.soulland.mod;

public class ClientState {
    public static int soul, level, exp, rings, mana, selected;
}

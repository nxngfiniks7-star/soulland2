package com.soulland.mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.WorldServer;

/** นั่งฝึกพลังวิญญาณ (กด K): ได้ EXP ต่อเนื่องโดยไม่ต้องฆ่ามอนสเตอร์ */
public class Meditate {
    public static boolean active(EntityPlayerMP p) { return SoulData.tag(p).getBoolean("medOn"); }

    private static void err(EntityPlayerMP p, String k) { p.sendStatusMessage(Tr.c(k), true); }

    public static void toggle(EntityPlayerMP p) {
        if (active(p)) stop(p, true);
        else start(p);
    }

    public static void start(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        if (SoulData.getSoul(p) == 0) { err(p, "msg.soulland.needawaken"); return; }
        if (Absorb.active(p) || t.getBoolean("awOn")) return;
        if (!p.onGround) { err(p, "msg.soulland.medair"); return; }
        if (SoulData.getLevel(p) >= SoulData.levelCap(SoulData.getRings(p)) && SoulData.getRings(p) < 9) { err(p, "msg.soulland.medcap"); return; }
        t.setBoolean("medOn", true);
        t.setInteger("medTick", 0);
        t.setDouble("mdX", p.posX); t.setDouble("mdY", p.posY); t.setDouble("mdZ", p.posZ);
        EntityArmorStand seat = new EntityArmorStand(p.world, p.posX, p.posY - 1.58, p.posZ);
        seat.setInvisible(true);
        seat.setNoGravity(true);
        seat.setEntityInvulnerable(true);
        p.world.spawnEntity(seat);
        seat.getEntityData().setBoolean("sl_seat", true);
        p.startRiding(seat, true);
        t.setInteger("medSeat", seat.getEntityId());
        err(p, "msg.soulland.medstart");
    }

    public static void stop(EntityPlayerMP p, boolean msg) {
        NBTTagCompound t = SoulData.tag(p);
        if (!t.getBoolean("medOn")) return;
        t.setBoolean("medOn", false);
        Entity seat = p.world.getEntityByID(t.getInteger("medSeat"));
        p.dismountRidingEntity();
        if (seat != null) seat.setDead();
        p.setPositionAndUpdate(t.getDouble("mdX"), t.getDouble("mdY"), t.getDouble("mdZ"));
        if (msg) err(p, "msg.soulland.medstop");
    }

    public static void tick(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        if (p.getHealth() <= 0 || p.isDead) { stop(p, false); return; }
        Entity seat = p.world.getEntityByID(t.getInteger("medSeat"));
        if (seat == null || seat.isDead) { stop(p, false); return; }
        if (p.getRidingEntity() != seat) p.startRiding(seat, true);
        int tick = t.getInteger("medTick") + 1;
        t.setInteger("medTick", tick);
        WorldServer ws = (WorldServer) p.world;
        if (tick % 5 == 0)
            ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX + (ws.rand.nextDouble() - 0.5), p.posY + 0.3 + ws.rand.nextDouble() * 1.5,
                    p.posZ + (ws.rand.nextDouble() - 0.5), 1, 0, 0.05, 0, 0.01);
        if (tick % 60 == 1)
            SoulSkills.fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, 80, p.getEntityId(), Awaken.palOf(SoulData.getSoul(p)));
        if (tick % 20 == 0) {
            int rings = SoulData.getRings(p), level = SoulData.getLevel(p);
            if (level >= SoulData.levelCap(rings) && rings < 9) {
                stop(p, false);
                err(p, "msg.soulland.medcap");
                return;
            }
            SoulData.addExp(p, 1 + level / 8);
            int max = SoulData.maxMana(p), m = SoulData.getMana(p);
            SoulData.setMana(p, Math.min(max, m + 6 + level / 4));
            p.heal(0.5F);
            SoulData.sync(p);
            err(p, "msg.soulland.medrun");
        }
    }
}

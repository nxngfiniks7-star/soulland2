package com.soulland.mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.WorldServer;

/** นั่งฝึกพลังวิญญาณ (กด K): นั่งบนเก้าอี้ล่องหน ได้ EXP คงที่ต่อเนื่องโดยไม่ต้องฆ่ามอนสเตอร์ */
public class Meditate {
    public static boolean active(EntityPlayerMP p) { return SoulData.tag(p).getBoolean("medOn"); }

    private static void err(EntityPlayerMP p, String k) { p.sendStatusMessage(Tr.c(k), true); }

    public static void toggle(EntityPlayerMP p) {
        if (active(p)) stop(p, true);
        else start(p);
    }

    public static void start(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        if (SoulData.getSoul(p) == 0) { err(p, "msg.soulland.needawaken"); return; }
        if (Absorb.active(p) || t.getBoolean("awOn")) return;
        if (!p.onGround) { err(p, "msg.soulland.medair"); return; }
        if (SoulData.getLevel(p) >= SoulData.levelCap(SoulData.getRings(p)) && SoulData.getRings(p) < 9) { err(p, "msg.soulland.medcap"); return; }
        t.setBoolean("medOn", true);
        t.setInteger("medTick", 0);
        t.setDouble("mdX", p.posX); t.setDouble("mdY", p.posY); t.setDouble("mdZ", p.posZ);
        t.setInteger("medSeat", Seat.spawn(p));
        SoulData.syncVisual(p);
        err(p, "msg.soulland.medstart");
    }

    public static void stop(EntityPlayerMP p, boolean msg) {
        NBTTagCompound t = SoulData.tag(p);
        if (!t.getBoolean("medOn")) return;
        t.setBoolean("medOn", false);
        Seat.release(p, t.getInteger("medSeat"), t.getDouble("mdX"), t.getDouble("mdY"), t.getDouble("mdZ"));
        SoulData.syncVisual(p);
        if (msg) err(p, "msg.soulland.medstop");
    }

    public static void tick(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        if (p.getHealth() <= 0 || p.isDead) { stop(p, false); return; }
        Entity seat = p.world.getEntityByID(t.getInteger("medSeat"));
        if (seat == null || seat.isDead) { stop(p, false); return; }
        Seat.keep(p, t.getInteger("medSeat"));
        p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 5, 6, false, false));
        int tick = t.getInteger("medTick") + 1;
        t.setInteger("medTick", tick);
        WorldServer ws = (WorldServer) p.world;
        if (tick % 5 == 0)
            ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX + (ws.rand.nextDouble() - 0.5), p.posY + 0.3 + ws.rand.nextDouble() * 1.2,
                    p.posZ + (ws.rand.nextDouble() - 0.5), 1, 0, 0.05, 0, 0.01);
        if (tick % 60 == 1)
            SoulSkills.fxP(ws, p, 14, 0, 0, 0, 0, 0, 0, 80, p.getEntityId(), Awaken.palOf(SoulData.getSoul(p)));
        if (tick % 20 == 0) {
            int rings = SoulData.getRings(p), level = SoulData.getLevel(p);
            if (level >= SoulData.levelCap(rings) && rings < 9) {
                stop(p, false);
                err(p, "msg.soulland.medcap");
                return;
            }
            SoulData.addExp(p, 2);
            int max = SoulData.maxMana(p), m = SoulData.getMana(p);
            SoulData.setMana(p, Math.min(max, m + 6 + level / 4));
            p.heal(0.5F);
            SoulData.sync(p);
            err(p, "msg.soulland.medrun");
        }
    }
}

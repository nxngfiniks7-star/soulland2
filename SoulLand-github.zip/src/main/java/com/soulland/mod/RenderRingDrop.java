package com.soulland.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** วาดวงแหวนวิญญาณที่ลอยหมุนอยู่ */
@SideOnly(Side.CLIENT)
public class RenderRingDrop extends Render<EntityRingDrop> {
    private static ItemStack[] stacks;

    public RenderRingDrop(RenderManager m) {
        super(m);
        this.shadowSize = 0.0F;
    }

    @Override
    public void doRender(EntityRingDrop e, double x, double y, double z, float yaw, float pt) {
        if (stacks == null) {
            stacks = new ItemStack[5];
            for (int i = 0; i < 5; i++) stacks[i] = new ItemStack(ModItems.RINGS[i]);
        }
        float t = e.ticksExisted + pt;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y + 0.45 + 0.08 * Math.sin(t * 0.1), z);
        GlStateManager.rotate(t * 3F, 0, 1, 0);
        GlStateManager.scale(1.6F, 1.6F, 1.6F);
        this.bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        GlStateManager.enableRescaleNormal();
        Minecraft.getMinecraft().getRenderItem().renderItem(stacks[e.getTier()], ItemCameraTransforms.TransformType.GROUND);
        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityRingDrop e) { return TextureMap.LOCATION_BLOCKS_TEXTURE; }
}

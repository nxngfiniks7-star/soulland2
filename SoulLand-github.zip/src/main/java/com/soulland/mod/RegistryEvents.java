package com.soulland.mod;

import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = SoulLand.MODID)
public class RegistryEvents {
    @SubscribeEvent
    public static void items(RegistryEvent.Register<Item> e) {
        for (Item i : ModItems.ALL) e.getRegistry().register(i);
    }

    @SubscribeEvent
    public static void entities(RegistryEvent.Register<EntityEntry> e) {
        e.getRegistry().register(EntityEntryBuilder.create().entity(EntitySoulBear.class)
                .id(new ResourceLocation(SoulLand.MODID, "soul_bear"), 1).name("soulland.soul_bear")
                .tracker(64, 3, true).egg(0xE8F4FF, 0x5599CC).build());
        e.getRegistry().register(EntityEntryBuilder.create().entity(EntitySoulWolf.class)
                .id(new ResourceLocation(SoulLand.MODID, "soul_wolf"), 2).name("soulland.soul_wolf")
                .tracker(64, 3, true).egg(0x9AA0B0, 0x33CCFF).build());
        e.getRegistry().register(EntityEntryBuilder.create().entity(EntityRingDrop.class)
                .id(new ResourceLocation(SoulLand.MODID, "ring_drop"), 3).name("soulland.ring_drop")
                .tracker(48, 10, false).build());
    }
}
